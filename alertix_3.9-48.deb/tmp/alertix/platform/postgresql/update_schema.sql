--- удаление всех представлений, они будут созданы после миграции с помощью add_views.sql
DO $$
DECLARE
    r RECORD;
BEGIN
    FOR r IN
        SELECT table_name
        FROM information_schema.views
        WHERE table_schema = 'public'
    LOOP
        EXECUTE 'DROP VIEW IF EXISTS public.' || quote_ident(r.table_name) || ' CASCADE';
    END LOOP;
END $$;

ALTER TABLE public.roles
ADD COLUMN IF NOT EXISTS workspace_closing boolean NOT NULL DEFAULT false;

UPDATE public.roles
SET workspace_closing = TRUE
WHERE name = 'Администратор ИБ' AND is_system = TRUE;

--- добавляем идентификаторы по умолчанию
ALTER TABLE public."agentGroups" ALTER COLUMN id SET DEFAULT gen_random_uuid();
ALTER TABLE public.agents ALTER COLUMN guid SET DEFAULT gen_random_uuid();

CREATE TABLE IF NOT EXISTS public.connectors_permissions (
    connector_id uuid NOT NULL,
    permission_id uuid NOT NULL,
    CONSTRAINT connectors_permissions_pk PRIMARY KEY (connector_id, permission_id),
    CONSTRAINT connectors_permissions_connector_fk FOREIGN KEY (connector_id) REFERENCES public.connectors (id) ON DELETE CASCADE,
    CONSTRAINT connectors_permissions_permission_fk FOREIGN KEY (permission_id) REFERENCES public.permissions (id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS connectors_permissions_connector_id_idx ON public.connectors_permissions (connector_id);
CREATE INDEX IF NOT EXISTS connectors_permissions_permission_id_idx ON public.connectors_permissions (permission_id);

CREATE TABLE IF NOT EXISTS public.notepad_lists_permissions (
    notepad_list_id uuid NOT NULL,
    permission_id uuid NOT NULL,
    CONSTRAINT notepad_lists_permissions_pk PRIMARY KEY (notepad_list_id, permission_id),
    CONSTRAINT notepad_lists_permissions_notepad_list_fk FOREIGN KEY (notepad_list_id) REFERENCES public.notepad_lists (id) ON DELETE CASCADE,
    CONSTRAINT notepad_lists_permissions_permission_fk FOREIGN KEY (permission_id) REFERENCES public.permissions (id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS notepad_lists_permissions_notepad_list_id_idx ON public.notepad_lists_permissions (notepad_list_id);
CREATE INDEX IF NOT EXISTS notepad_lists_permissions_permission_id_idx ON public.notepad_lists_permissions (permission_id);

CREATE TABLE IF NOT EXISTS public.agents_permissions (
    agent_id uuid NOT NULL,
    permission_id uuid NOT NULL,
    CONSTRAINT agents_permissions_pk PRIMARY KEY (agent_id, permission_id),
    CONSTRAINT agents_permissions_agent_fk FOREIGN KEY (agent_id) REFERENCES public.agents (guid) ON DELETE CASCADE,
    CONSTRAINT agents_permissions_permission_fk FOREIGN KEY (permission_id) REFERENCES public.permissions (id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS agents_permissions_agent_id_idx ON public.agents_permissions (agent_id);
CREATE INDEX IF NOT EXISTS agents_permissions_permission_id_idx ON public.agents_permissions (permission_id);

CREATE TABLE IF NOT EXISTS public.agent_groups_permissions (
    agent_group_id uuid NOT NULL,
    permission_id uuid NOT NULL,
    CONSTRAINT agent_groups_permissions_pk PRIMARY KEY (agent_group_id, permission_id),
    CONSTRAINT agent_groups_permissions_agent_group_fk FOREIGN KEY (agent_group_id) REFERENCES public."agentGroups" (id) ON DELETE CASCADE,
    CONSTRAINT agent_groups_permissions_permission_fk FOREIGN KEY (permission_id) REFERENCES public.permissions (id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS agent_groups_permissions_agent_group_id_idx ON public.agent_groups_permissions (agent_group_id);
CREATE INDEX IF NOT EXISTS agent_groups_permissions_permission_id_idx ON public.agent_groups_permissions (permission_id);

ALTER TABLE public.notepad_lists DROP COLUMN IF EXISTS public;

--- добавление нового модуля
UPDATE "agentGroups"
SET
    config = jsonb_set(
        jsonb_set(
            config::jsonb,
            '{version}',
            to_jsonb((config::jsonb ->> 'version')::int + 1)
        ),
        '{modules}',
        (config::jsonb -> 'modules')
        || '[{"name": "alertix", "present": true, "config": "forced_termination_modules: false\n"}]'::jsonb
    )
WHERE NOT EXISTS (
    SELECT 1
    FROM jsonb_array_elements(config::jsonb -> 'modules') AS module
    WHERE module ->> 'name' = 'alertix'
);

UPDATE agents
SET
    config = jsonb_set(
        jsonb_set(
            config::jsonb,
            '{version}',
            to_jsonb((config::jsonb ->> 'version')::int + 1)
        ),
        '{modules}',
        (config::jsonb -> 'modules')
        || '[{"name": "alertix", "present": true, "config": "forced_termination_modules: false\n"}]'::jsonb
    )
WHERE config IS NOT NULL AND NOT EXISTS (
    SELECT 1
    FROM jsonb_array_elements(config::jsonb -> 'modules') AS module
    WHERE module ->> 'name' = 'alertix'
);

ALTER TABLE public."agentGroups"
ADD IF NOT EXISTS author uuid DEFAULT get_default_author() NOT NULL,
ADD IF NOT EXISTS editor uuid NULL,
ADD IF NOT EXISTS created bigint DEFAULT (date_part('epoch'::text, now()) * 1000::double precision) NOT NULL,
ADD IF NOT EXISTS updated bigint DEFAULT (date_part('epoch'::text, now()) * 1000::double precision) NOT NULL;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'agentgroups_author_fk') THEN
      ALTER TABLE public."agentGroups" ADD CONSTRAINT agentgroups_author_fk FOREIGN KEY (author)
      REFERENCES public.users (id) ON UPDATE CASCADE ON DELETE CASCADE;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'agentgroups_editor_fk') THEN
      ALTER TABLE public."agentGroups" ADD CONSTRAINT agentgroups_editor_fk FOREIGN KEY (editor)
      REFERENCES public.users (id) ON UPDATE CASCADE ON DELETE SET NULL;
    END IF;
END $$;

ALTER TABLE public.datasets
ADD IF NOT EXISTS tags _varchar DEFAULT ARRAY[]::varchar [] NOT NULL,
ADD IF NOT EXISTS content jsonb DEFAULT '{}'::jsonb NOT NULL;

-- таймстемп updated для объектов прав доступа
ALTER TABLE public.dashboards_permissions
ADD COLUMN IF NOT EXISTS updated int8 NOT NULL DEFAULT (extract(EPOCH FROM now()) * 1000);

ALTER TABLE public.datasets_permissions
ADD COLUMN IF NOT EXISTS updated int8 NOT NULL DEFAULT (extract(EPOCH FROM now()) * 1000);

ALTER TABLE public.charts_permissions
ADD COLUMN IF NOT EXISTS updated int8 NOT NULL DEFAULT (extract(EPOCH FROM now()) * 1000);

ALTER TABLE public.indices_templates_permissions
ADD COLUMN IF NOT EXISTS updated int8 NOT NULL DEFAULT (extract(EPOCH FROM now()) * 1000);

ALTER TABLE public.workspaces_permissions
ADD COLUMN IF NOT EXISTS updated int8 NOT NULL DEFAULT (extract(EPOCH FROM now()) * 1000);

ALTER TABLE public.scripts_permissions
ADD COLUMN IF NOT EXISTS updated int8 NOT NULL DEFAULT (extract(EPOCH FROM now()) * 1000);

ALTER TABLE public.connectors_permissions
ADD COLUMN IF NOT EXISTS updated int8 NOT NULL DEFAULT (extract(EPOCH FROM now()) * 1000);

ALTER TABLE public.notepad_lists_permissions
ADD COLUMN IF NOT EXISTS updated int8 NOT NULL DEFAULT (extract(EPOCH FROM now()) * 1000);

ALTER TABLE public.agents_permissions
ADD COLUMN IF NOT EXISTS updated int8 NOT NULL DEFAULT (extract(EPOCH FROM now()) * 1000);

ALTER TABLE public.agent_groups_permissions
ADD COLUMN IF NOT EXISTS updated int8 NOT NULL DEFAULT (extract(EPOCH FROM now()) * 1000);

-- Создаем новую схему ресурсов

-- Типы ресурсов
CREATE TABLE IF NOT EXISTS public.res_types
(
    id uuid DEFAULT gen_random_uuid() NOT NULL, -- идентификатор
    name character varying(128) NOT NULL, -- название
    CONSTRAINT res_types_pkey PRIMARY KEY (id),
    CONSTRAINT res_types_name_un UNIQUE (name)
);
COMMENT ON TABLE public.res_types IS 'Таблица типов активов';

-- Операционные системы
CREATE TABLE IF NOT EXISTS public.res_os
(
    id uuid NOT NULL DEFAULT gen_random_uuid(),  -- идентификатор
    name citext NOT NULL, -- название
    type text NOT NULL DEFAULT 'Десктопная'::text, -- тип
    version text NOT NULL, -- версия
    hold text NOT NULL DEFAULT 'Корпоративная'::text,  -- владение
    created int8 NOT NULL DEFAULT (date_part('epoch'::text, now()) * 1000::double precision), -- дата создания
    updated int8 NOT NULL DEFAULT (date_part('epoch'::text, now()) * 1000::double precision), -- дата обновления
    author text NULL, -- создатель
    CONSTRAINT res_os_pkey PRIMARY KEY (id),
    CONSTRAINT res_os_name_version_unique UNIQUE (name, version)
);
COMMENT ON TABLE public.res_os IS 'Таблица с операционные системами';

-- Программное обеспечение
CREATE TABLE IF NOT EXISTS public.res_software
(
    id uuid NOT NULL DEFAULT gen_random_uuid(),  -- идентификатор
    name character varying(256) NOT NULL, -- название
    version text, -- версия
    vendor text,  -- производитель
    created int8 NOT NULL DEFAULT (date_part('epoch'::text, now()) * 1000::double precision), -- дата создания
    updated int8 NOT NULL DEFAULT (date_part('epoch'::text, now()) * 1000::double precision), -- дата обновления
    author text NULL, -- создатель
    CONSTRAINT res_software_pkey PRIMARY KEY (id)
);
COMMENT ON TABLE public.res_software IS 'Таблица с ПО';

-- Аппаратное обеспечение
CREATE TABLE IF NOT EXISTS public.res_hardware
(
    id uuid NOT NULL DEFAULT gen_random_uuid(),  -- идентификатор
    name character varying(256) NOT NULL, -- название
    type text, -- тип
    vendor text, -- производитель
    hwind text,  -- идентификатор оборудования
    virtual boolean DEFAULT FALSE, -- виртуальный\физический
    created int8 NOT NULL DEFAULT (date_part('epoch'::text, now()) * 1000::double precision), -- дата создания
    updated int8 NOT NULL DEFAULT (date_part('epoch'::text, now()) * 1000::double precision), -- дата обновления
    author text NULL, -- создатель
    CONSTRAINT res_hardware_pkey PRIMARY KEY (id)
);
COMMENT ON TABLE public.res_hardware IS 'Таблица с АО';


-- Хосты (серверы\раб. станции)
CREATE TABLE IF NOT EXISTS public.res_hosts
(
    id uuid NOT NULL DEFAULT gen_random_uuid(),  -- идентификатор
    name character varying(256) NOT NULL, -- название, в основном должен быть hostname
    domain citext, -- домен хоста
    description text, -- описание
    fqdn citext, -- полное имя хоста с доменом
    active boolean DEFAULT TRUE, -- флаг активности
    fixed_ips inet [], -- набор фиксированных адресов хоста
    fqdn_list citext [], -- набор дополнительных доменных имен
    mac_addresses macaddr [], -- набор мак-адресов
    public boolean DEFAULT FALSE, -- флаг публичного доступа
    virtual boolean DEFAULT FALSE, -- виртуальный\физический
    mobile boolean DEFAULT FALSE, -- флаг мобильности
    type_id uuid NOT NULL, -- тип
    created int8 NOT NULL DEFAULT (date_part('epoch'::text, now()) * 1000::double precision), -- дата создания
    updated int8 NOT NULL DEFAULT (date_part('epoch'::text, now()) * 1000::double precision), -- дата обновления
    author text NULL, -- создатель
    object_sid citext NULL, -- идентификатор в AD
    CONSTRAINT res_hosts_pkey PRIMARY KEY (id),
    CONSTRAINT res_hosts_name_domain_un UNIQUE (name, domain, type_id),
    CONSTRAINT res_hosts_object_sid_un UNIQUE (object_sid),
    CONSTRAINT res_hosts_type_fkey FOREIGN KEY (type_id)
    REFERENCES public.res_types (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE SET NULL
);
COMMENT ON TABLE public.res_hosts IS 'Таблица c известными хостами (серверы и раб. станции)';


-- Учетный записи
CREATE TABLE IF NOT EXISTS public.res_accounts
(
    id uuid NOT NULL DEFAULT gen_random_uuid(),  -- идентификатор
    name character varying(256) NOT NULL, -- название
    domain citext, -- домен учетки
    description text, -- описание
    active boolean DEFAULT TRUE, -- флаг активности
    username citext NOT NULL, -- название учетки
    email citext, -- почта
    purpose text, -- назначение, тестовая\привилегированная
    type_id uuid NOT NULL, -- тип
    created int8 NOT NULL DEFAULT (date_part('epoch'::text, now()) * 1000::double precision),  -- дата создания
    updated int8 NOT NULL DEFAULT (date_part('epoch'::text, now()) * 1000::double precision), -- дата обновления
    author text NULL, -- создатель
    object_sid citext NULL, -- идентификатор в AD
    CONSTRAINT res_accounts_pkey PRIMARY KEY (id),
    CONSTRAINT res_accounts_object_sid_un UNIQUE (object_sid),
    CONSTRAINT res_accounts_type_fkey FOREIGN KEY (type_id) REFERENCES public.res_types (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE SET NULL
);
COMMENT ON TABLE public.res_accounts IS 'Таблица с учетными записями';

CREATE UNIQUE INDEX IF NOT EXISTS res_accounts_username_un
ON public.res_accounts (username)
WHERE domain IS NULL;

CREATE UNIQUE INDEX IF NOT EXISTS res_accounts_username_domain_un
ON public.res_accounts (username, domain)
WHERE domain IS not NULL;

-- Устройства, могут выступать как хосты, но имеют отдельные атрибуты, больше нужно для контроля физических устройв, а не инфры, поэтому отдельно
CREATE TABLE IF NOT EXISTS public.res_devices
(
    id uuid NOT NULL DEFAULT gen_random_uuid(), -- идентификатор
    name character varying(256) NOT NULL, -- название
    domain citext, -- домен
    description text, -- описание
    fqdn citext, -- полное имя
    hold text, -- тип, личное\корпоративное
    fixed_ips inet [],  -- набор фиксированных адресов
    mac_addresses macaddr [], -- набор мак-адресов
    uuid_imei text, -- идентификатор
    type_id uuid NOT NULL, -- тип
    created int8 NOT NULL DEFAULT (date_part('epoch'::text, now()) * 1000::double precision),  -- дата создания
    updated int8 NOT NULL DEFAULT (date_part('epoch'::text, now()) * 1000::double precision), -- дата обновления
    author text NULL, -- создатель
    CONSTRAINT res_devices_pkey PRIMARY KEY (id),
    CONSTRAINT res_devices_name_domain_un UNIQUE (name, domain),
    CONSTRAINT res_devices_type_fkey FOREIGN KEY (type_id) REFERENCES public.res_types (id) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE SET NULL

);
COMMENT ON TABLE public.res_devices IS 'Таблица c устройствами';


-- Сервисы и службы
CREATE TABLE IF NOT EXISTS public.res_services
(
    id uuid NOT NULL DEFAULT gen_random_uuid(), -- идентификатор
    name character varying(256) NOT NULL, -- название
    domain citext, -- домен
    description text, -- описание
    fqdn citext, -- полное имя
    public boolean DEFAULT FALSE, -- флаг публичного доступа
    url_list text [], -- список url
    protocol text,  -- протокол сервиса
    interface text, -- интерфейс управления
    type_id uuid NOT NULL, -- тип
    created int8 NOT NULL DEFAULT (date_part('epoch'::text, now()) * 1000::double precision),  -- дата создания
    updated int8 NOT NULL DEFAULT (date_part('epoch'::text, now()) * 1000::double precision), -- дата обновления
    author text NULL, -- создатель
    CONSTRAINT res_services_pkey PRIMARY KEY (id),
    CONSTRAINT res_services_name_domain_un UNIQUE (name, domain),
    CONSTRAINT res_services_type_fkey FOREIGN KEY (type_id) REFERENCES public.res_types (id) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE SET NULL
);
COMMENT ON TABLE public.res_services IS 'Таблица c сервисами\службами';


-- СЗИ (Средства защиты информации)
CREATE TABLE IF NOT EXISTS public.res_iss
(
    id uuid NOT NULL DEFAULT gen_random_uuid(),  -- идентификатор
    name character varying(256) NOT NULL, -- название
    domain citext, -- домен
    description text, -- описание
    fqdn citext, -- полное имя
    iss_type text,  -- тип сзи
    version text,  -- версия
    model text,  -- модель и производитель
    hsc boolean DEFAULT FALSE, -- ПАК (программно-аппаратный комплекс)
    virtual boolean DEFAULT FALSE, -- виртуальный\физический
    fixed_ips inet [], -- набор фиксированных адресов
    mac_addresses macaddr [], -- набор мак-адресов
    interface text, -- интерфейс управления
    type_id uuid NOT NULL, -- тип
    created int8 NOT NULL DEFAULT (date_part('epoch'::text, now()) * 1000::double precision), -- дата создания
    updated int8 NOT NULL DEFAULT (date_part('epoch'::text, now()) * 1000::double precision), -- дата обновления
    author text NULL, -- создатель
    CONSTRAINT res_iss_pkey PRIMARY KEY (id),
    CONSTRAINT res_iss_name_domain_un UNIQUE (name, domain),
    CONSTRAINT res_iss_type_fkey FOREIGN KEY (type_id) REFERENCES public.res_types (id) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE SET NULL
);
COMMENT ON TABLE public.res_iss IS 'Таблица СЗИ';

-- Оборудование (перифeрийное\сетевое)
CREATE TABLE IF NOT EXISTS public.res_equipment
(
    id uuid NOT NULL DEFAULT gen_random_uuid(),  -- идентификатор
    name character varying(256) NOT NULL, -- название
    domain citext, -- домен
    description text, -- описание
    fqdn citext, -- полное имя
    equipment_type text,  -- тип оборудования
    model text,  -- модель и производитель
    virtual boolean DEFAULT FALSE, -- виртуальный\физический
    version text,  -- версия
    fixed_ips inet [], -- набор фиксированных адресов
    mac_addresses macaddr [], -- набор мак-адресов
    interface text, -- интерфейс управления
    type_id uuid NOT NULL, -- тип оборудования
    created int8 NOT NULL DEFAULT (date_part('epoch'::text, now()) * 1000::double precision), -- дата создания
    updated int8 NOT NULL DEFAULT (date_part('epoch'::text, now()) * 1000::double precision), -- дата обновления
    author text NULL, -- создатель
    CONSTRAINT res_equipment_pkey PRIMARY KEY (id),
    CONSTRAINT res_equipment_name_domain_un UNIQUE (name, domain),
    CONSTRAINT res_equipment_type_fkey FOREIGN KEY (type_id) REFERENCES public.res_types (id) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE SET NULL
);
COMMENT ON TABLE public.res_equipment IS 'Таблица с оборудованием';

-- Связи

-- Хосты - Контакты
CREATE TABLE IF NOT EXISTS public.res_hosts_contacts
(
    rid uuid NOT NULL,
    cid uuid NOT NULL,
    relation character varying(256) NOT NULL,
    CONSTRAINT res_hosts_contacts_pkey PRIMARY KEY (rid, cid),
    CONSTRAINT res_hosts_contacts_cid_fkey FOREIGN KEY (cid) REFERENCES public.contacts (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_hosts_contacts_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_hosts (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_hosts_contacts IS 'Таблица связей между контактами и хостами';

-- Учетки - Контакты
CREATE TABLE IF NOT EXISTS public.res_accounts_contacts
(
    rid uuid NOT NULL,
    cid uuid NOT NULL,
    relation character varying(256) NOT NULL,
    CONSTRAINT res_accounts_contacts_pkey PRIMARY KEY (rid, cid),
    CONSTRAINT res_accounts_contacts_cid_fkey FOREIGN KEY (cid) REFERENCES public.contacts (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_accounts_contacts_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_accounts (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_accounts_contacts IS 'Таблица связей между контактами и учетными записями';

-- Устройства - Контакты
CREATE TABLE IF NOT EXISTS public.res_devices_contacts
(
    rid uuid NOT NULL,
    cid uuid NOT NULL,
    relation character varying(256) NOT NULL,
    CONSTRAINT res_devices_contacts_pkey PRIMARY KEY (rid, cid),
    CONSTRAINT res_devices_contacts_cid_fkey FOREIGN KEY (cid) REFERENCES public.contacts (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_devices_contacts_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_devices (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_devices_contacts IS 'Таблица связей между контактами и устройствами';

-- Сервисы - Контакты
CREATE TABLE IF NOT EXISTS public.res_services_contacts
(
    rid uuid NOT NULL,
    cid uuid NOT NULL,
    relation character varying(256) NOT NULL,
    CONSTRAINT res_services_contacts_pkey PRIMARY KEY (rid, cid),
    CONSTRAINT res_services_contacts_cid_fkey FOREIGN KEY (cid) REFERENCES public.contacts (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_services_contacts_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_services (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_services_contacts IS 'Таблица связей между контактами и сервисами';

-- СЗИ - Контакты
CREATE TABLE IF NOT EXISTS public.res_iss_contacts
(
    rid uuid NOT NULL,
    cid uuid NOT NULL,
    relation character varying(256) NOT NULL,
    CONSTRAINT res_iss_contacts_pkey PRIMARY KEY (rid, cid),
    CONSTRAINT res_iss_contacts_cid_fkey FOREIGN KEY (cid) REFERENCES public.contacts (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_iss_contacts_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_iss (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_iss_contacts IS 'Таблица связей между контактами и сзи';

-- Оборудование - Контакты
CREATE TABLE IF NOT EXISTS public.res_equipment_contacts
(
    rid uuid NOT NULL,
    cid uuid NOT NULL,
    relation character varying(256) NOT NULL,
    CONSTRAINT res_equipment_contacts_pkey PRIMARY KEY (rid, cid),
    CONSTRAINT res_equipment_contacts_cid_fkey FOREIGN KEY (cid) REFERENCES public.contacts (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_equipment_contacts_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_equipment (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_equipment_contacts IS 'Таблица связей между контактами и оборудованием';

-- Хосты - Локации
CREATE TABLE IF NOT EXISTS public.res_hosts_locations
(
    rid uuid NOT NULL,
    lid uuid NOT NULL,
    CONSTRAINT res_hosts_locations_pkey PRIMARY KEY (rid, lid),
    CONSTRAINT res_hosts_locations_lid_fkey FOREIGN KEY (lid) REFERENCES public.locations (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_hosts_locations_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_hosts (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_hosts_locations IS 'Таблица связей между локациями и хостами';

-- Учетки - Локации
CREATE TABLE IF NOT EXISTS public.res_accounts_locations
(
    rid uuid NOT NULL,
    lid uuid NOT NULL,
    CONSTRAINT res_accounts_locations_pkey PRIMARY KEY (rid, lid),
    CONSTRAINT res_accounts_locations_lid_fkey FOREIGN KEY (lid) REFERENCES public.locations (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_accounts_locations_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_accounts (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_accounts_locations IS 'Таблица связей между локациями и учетными записями';

-- Устройства - Локации
CREATE TABLE IF NOT EXISTS public.res_devices_locations
(
    rid uuid NOT NULL,
    lid uuid NOT NULL,
    CONSTRAINT res_devices_locations_pkey PRIMARY KEY (rid, lid),
    CONSTRAINT res_devices_locations_lid_fkey FOREIGN KEY (lid) REFERENCES public.locations (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_devices_locations_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_devices (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_devices_locations IS 'Таблица связей между локациями и устройствами';


-- Сервисы - Локации
CREATE TABLE IF NOT EXISTS public.res_services_locations
(
    rid uuid NOT NULL,
    lid uuid NOT NULL,
    CONSTRAINT res_services_locations_pkey PRIMARY KEY (rid, lid),
    CONSTRAINT res_services_locations_lid_fkey FOREIGN KEY (lid) REFERENCES public.locations (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_services_locations_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_services (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_services_locations IS 'Таблица связей между локациями и сервисами';

-- СЗИ - Локации
CREATE TABLE IF NOT EXISTS public.res_iss_locations
(
    rid uuid NOT NULL,
    lid uuid NOT NULL,
    CONSTRAINT res_iss_locations_pkey PRIMARY KEY (rid, lid),
    CONSTRAINT res_iss_locations_lid_fkey FOREIGN KEY (lid) REFERENCES public.locations (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_iss_locations_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_iss (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_iss_locations IS 'Таблица связей между локациями и сзи';

-- Хосты - Локации
CREATE TABLE IF NOT EXISTS public.res_equipment_locations
(
    rid uuid NOT NULL,
    lid uuid NOT NULL,
    CONSTRAINT res_equipment_locations_pkey PRIMARY KEY (rid, lid),
    CONSTRAINT res_equipment_locations_lid_fkey FOREIGN KEY (lid) REFERENCES public.locations (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_equipment_locations_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_equipment (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_equipment_locations IS 'Таблица связей между локациями и оборудованием';


-- Хосты - Отделы
CREATE TABLE IF NOT EXISTS public.res_hosts_org_units
(
    rid uuid NOT NULL,
    ouid uuid NOT NULL,
    CONSTRAINT res_hosts_org_units_pkey PRIMARY KEY (rid, ouid),
    CONSTRAINT res_hosts_org_units_ouid_fkey FOREIGN KEY (ouid) REFERENCES public.org_units (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_hosts_org_units_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_hosts (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_hosts_org_units IS 'Таблица связей между отделами и хостами';

-- Учетки - Отделы
CREATE TABLE IF NOT EXISTS public.res_accounts_org_units
(
    rid uuid NOT NULL,
    ouid uuid NOT NULL,
    CONSTRAINT res_accounts_org_units_pkey PRIMARY KEY (rid, ouid),
    CONSTRAINT res_accounts_org_units_ouid_fkey FOREIGN KEY (ouid) REFERENCES public.org_units (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_accounts_org_units_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_accounts (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_accounts_org_units IS 'Таблица связей между отделами и учетными записями';

-- Устройства - Отделы
CREATE TABLE IF NOT EXISTS public.res_devices_org_units
(
    rid uuid NOT NULL,
    ouid uuid NOT NULL,
    CONSTRAINT res_devices_org_units_pkey PRIMARY KEY (rid, ouid),
    CONSTRAINT res_devices_org_units_ouid_fkey FOREIGN KEY (ouid) REFERENCES public.org_units (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_devices_org_units_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_devices (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_devices_org_units IS 'Таблица связей между отделами и устройствами';

-- Сервисы - Отделы
CREATE TABLE IF NOT EXISTS public.res_services_org_units
(
    rid uuid NOT NULL,
    ouid uuid NOT NULL,
    CONSTRAINT res_services_org_units_pkey PRIMARY KEY (rid, ouid),
    CONSTRAINT res_services_org_units_ouid_fkey FOREIGN KEY (ouid) REFERENCES public.org_units (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_services_org_units_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_services (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_services_org_units IS 'Таблица связей между отделами и сервисами';

-- СЗИ - Отделы
CREATE TABLE IF NOT EXISTS public.res_iss_org_units
(
    rid uuid NOT NULL,
    ouid uuid NOT NULL,
    CONSTRAINT res_iss_org_units_pkey PRIMARY KEY (rid, ouid),
    CONSTRAINT res_iss_org_units_ouid_fkey FOREIGN KEY (ouid) REFERENCES public.org_units (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_iss_org_units_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_iss (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_iss_org_units IS 'Таблица связей между отделами и сзи';

-- Оборудование - Отделы
CREATE TABLE IF NOT EXISTS public.res_equipment_org_units
(
    rid uuid NOT NULL,
    ouid uuid NOT NULL,
    CONSTRAINT res_equipment_org_units_pkey PRIMARY KEY (rid, ouid),
    CONSTRAINT res_equipment_org_units_ouid_fkey FOREIGN KEY (ouid) REFERENCES public.org_units (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_equipment_org_units_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_equipment (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_equipment_org_units IS 'Таблица связей между отделами и оборудованием';


-- Хосты - Тэги
CREATE TABLE IF NOT EXISTS public.res_hosts_tags
(
    rid uuid NOT NULL,
    tid character varying(512) NOT NULL,
    CONSTRAINT res_hosts_tags_pkey PRIMARY KEY (rid, tid),
    CONSTRAINT res_hosts_tags_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_hosts (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_hosts_tags_tid_fkey FOREIGN KEY (tid) REFERENCES public.tags (name) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_hosts_tags IS 'Таблица связей между хостами и тегами';

-- Учетки - Тэги
CREATE TABLE IF NOT EXISTS public.res_accounts_tags
(
    rid uuid NOT NULL,
    tid character varying(512) NOT NULL,
    CONSTRAINT res_accounts_tags_pkey PRIMARY KEY (rid, tid),
    CONSTRAINT res_accounts_tags_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_accounts (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_accounts_tags_tid_fkey FOREIGN KEY (tid) REFERENCES public.tags (name) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_accounts_tags IS 'Таблица связей между учетными записями и тегами';

-- Устройства - Тэги
CREATE TABLE IF NOT EXISTS public.res_devices_tags
(
    rid uuid NOT NULL,
    tid character varying(512) NOT NULL,
    CONSTRAINT res_devices_tags_pkey PRIMARY KEY (rid, tid),
    CONSTRAINT res_devices_tags_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_devices (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_devices_tags_tid_fkey FOREIGN KEY (tid) REFERENCES public.tags (name) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_devices_tags IS 'Таблица связей между устройствами и тегами';

-- Сервисы - Тэги
CREATE TABLE IF NOT EXISTS public.res_services_tags
(
    rid uuid NOT NULL,
    tid character varying(512) NOT NULL,
    CONSTRAINT res_services_tags_pkey PRIMARY KEY (rid, tid),
    CONSTRAINT res_services_tags_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_services (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_services_tags_tid_fkey FOREIGN KEY (tid) REFERENCES public.tags (name) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_services_tags IS 'Таблица связей между сервисами и тегами';

-- СЗИ - Тэги
CREATE TABLE IF NOT EXISTS public.res_iss_tags
(
    rid uuid NOT NULL,
    tid character varying(512) NOT NULL,
    CONSTRAINT res_iss_tags_pkey PRIMARY KEY (rid, tid),
    CONSTRAINT res_iss_tags_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_iss (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_iss_tags_tid_fkey FOREIGN KEY (tid) REFERENCES public.tags (name) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_iss_tags IS 'Таблица связей между сзи и тегами';

-- Оборудование - Тэги
CREATE TABLE IF NOT EXISTS public.res_equipment_tags
(
    rid uuid NOT NULL,
    tid character varying(512) NOT NULL,
    CONSTRAINT res_equipment_tags_pkey PRIMARY KEY (rid, tid),
    CONSTRAINT res_equipment_tags_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_equipment (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_equipment_tags_tid_fkey FOREIGN KEY (tid) REFERENCES public.tags (name) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_equipment_tags IS 'Таблица связей между оборудованием и тегами';


-- Пока оставляем таблицу хостов цензуса (слишком большой объем переделки)
-- После перехода на раздельные ресурсы, перенесем в ресурсы, плюс подумаем как уложить источники и машины без хостов + активность (модули)
CREATE TABLE IF NOT EXISTS public.census_res_hosts
(
    rhid uuid NOT NULL, -- идентификатор ресурса
    hid uuid NOT NULL, -- идентификатор хоста

    CONSTRAINT census_res_hosts_pkey PRIMARY KEY (rhid, hid),
    CONSTRAINT census_res_hosts_hfkey FOREIGN KEY (hid) REFERENCES public.census_hosts (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT census_res_hosts_rfkey FOREIGN KEY (rhid) REFERENCES public.res_hosts (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.census_res_hosts IS 'Таблица cо связями ресурсов и хостов';


-- Хосты - ПО (Программное обеспечение)
CREATE TABLE IF NOT EXISTS public.res_hosts_software
(
    rid uuid NOT NULL,
    sfid uuid NOT NULL,
    CONSTRAINT res_hosts_software_pkey PRIMARY KEY (rid, sfid),
    CONSTRAINT res_hosts_software_sfid_fkey FOREIGN KEY (sfid) REFERENCES public.res_software (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_hosts_software_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_hosts (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_hosts_software IS 'Таблица связей между по и хостами';


-- Хосты - АО (Аппаратное обеспечение)
CREATE TABLE IF NOT EXISTS public.res_hosts_hardware
(
    rid uuid NOT NULL,
    hfid uuid NOT NULL,
    CONSTRAINT res_hosts_hardware_pkey PRIMARY KEY (rid, hfid),
    CONSTRAINT res_hosts_hardware_hfid_fkey FOREIGN KEY (hfid) REFERENCES public.res_hardware (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_hosts_hardware_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_hosts (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_hosts_hardware IS 'Таблица связей между ао и хостами';

-- Хосты - ОС (Операционные системы)
CREATE TABLE IF NOT EXISTS public.res_hosts_os
(
    rid uuid NOT NULL,
    osid uuid NOT NULL,
    CONSTRAINT res_hosts_os_pkey PRIMARY KEY (rid, osid),
    CONSTRAINT res_hosts_os_osid_fkey FOREIGN KEY (osid) REFERENCES public.res_os (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_hosts_os_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_hosts (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_hosts_os IS 'Таблица связей между ос и хостами';

-- Устройства - ОС (Операционные системы)
CREATE TABLE IF NOT EXISTS public.res_devices_os
(
    rid uuid NOT NULL,
    osid uuid NOT NULL,
    CONSTRAINT res_devices_os_pkey PRIMARY KEY (rid, osid),
    CONSTRAINT res_devices_os_osid_fkey FOREIGN KEY (osid) REFERENCES public.res_os (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_devices_os_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_devices (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_hosts_os IS 'Таблица связей между ос и устройствами';


-- Связи между ресурсами
CREATE TABLE IF NOT EXISTS public.res_hosts_accounts
(
    rid uuid NOT NULL,
    raid uuid NOT NULL,
    CONSTRAINT res_hosts_accounts_pkey PRIMARY KEY (rid, raid),
    CONSTRAINT res_hosts_accounts_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_hosts (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_hosts_accounts_raid_fkey FOREIGN KEY (raid) REFERENCES public.res_accounts (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_hosts_accounts IS 'Таблица связей между хостами и учетками';

CREATE TABLE IF NOT EXISTS public.res_hosts_services
(
    rhid uuid NOT NULL,
    rsid uuid NOT NULL,
    CONSTRAINT res_hosts_services_pkey PRIMARY KEY (rhid, rsid),
    CONSTRAINT res_hosts_services_rhid_fkey FOREIGN KEY (rhid) REFERENCES public.res_hosts (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_hosts_services_rsid_fkey FOREIGN KEY (rsid) REFERENCES public.res_services (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_hosts_services IS 'Таблица связей между хостами и сервисами';

CREATE TABLE IF NOT EXISTS public.res_hosts_iss
(
    rhid uuid NOT NULL,
    riid uuid NOT NULL,
    CONSTRAINT res_hosts_iss_pkey PRIMARY KEY (rhid, riid),
    CONSTRAINT res_hosts_iss_rhid_fkey FOREIGN KEY (rhid) REFERENCES public.res_hosts (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_hosts_iss_riid_fkey FOREIGN KEY (riid) REFERENCES public.res_iss (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_hosts_iss IS 'Таблица связей между хостами и сзи';

CREATE TABLE IF NOT EXISTS public.res_hosts_equipment
(
    rhid uuid NOT NULL,
    reid uuid NOT NULL,
    CONSTRAINT res_hosts_equipment_pkey PRIMARY KEY (rhid, reid),
    CONSTRAINT res_hosts_equipment_rhid_fkey FOREIGN KEY (rhid) REFERENCES public.res_hosts (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_hosts_equipment_reid_fkey FOREIGN KEY (reid) REFERENCES public.res_equipment (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_hosts_equipment IS 'Таблица связей между хостами и оборудованием';

CREATE TABLE IF NOT EXISTS public.res_devices_accounts
(
    rid uuid NOT NULL,
    raid uuid NOT NULL,
    CONSTRAINT res_devices_accounts_pkey PRIMARY KEY (rid, raid),
    CONSTRAINT res_devices_accounts_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_devices (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_devices_accounts_raid_fkey FOREIGN KEY (raid) REFERENCES public.res_accounts (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_devices_accounts IS 'Таблица связей между устройствами и учетками';

CREATE TABLE IF NOT EXISTS public.res_services_accounts
(
    rid uuid NOT NULL,
    raid uuid NOT NULL,
    CONSTRAINT res_services_accounts_pkey PRIMARY KEY (rid, raid),
    CONSTRAINT res_services_accounts_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_services (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_services_accounts_raid_fkey FOREIGN KEY (raid) REFERENCES public.res_accounts (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_services_accounts IS 'Таблица связей между сервисами и учетками';

CREATE TABLE IF NOT EXISTS public.res_iss_accounts
(
    rid uuid NOT NULL,
    raid uuid NOT NULL,
    CONSTRAINT res_iss_accounts_pkey PRIMARY KEY (rid, raid),
    CONSTRAINT res_iss_accounts_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_iss (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_iss_accounts_raid_fkey FOREIGN KEY (raid) REFERENCES public.res_accounts (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_iss_accounts IS 'Таблица связей между сзи и учетками';

CREATE TABLE IF NOT EXISTS public.res_equipment_accounts
(
    rid uuid NOT NULL,
    raid uuid NOT NULL,
    CONSTRAINT res_equipment_accounts_pkey PRIMARY KEY (rid, raid),
    CONSTRAINT res_equipment_accounts_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_equipment (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_equipment_accounts_raid_fkey FOREIGN KEY (raid) REFERENCES public.res_accounts (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE public.res_equipment_accounts IS 'Таблица связей между оборудования и учетками';

-- Новые типы
INSERT INTO public.res_types (name)
VALUES ('account'), -- 'Учетная запись'
('server'), -- 'Сервер'
('workstation'), -- 'Рабочая станция'
('device'), -- 'Мобильное устройство'
('service'), -- 'ИТ Сервис'
('network_equipment'), -- 'Сетевое оборудование'
('peripheral_equipment'), -- 'Периферийное оборудование'
('iss') -- 'Средство защиты информации' (Information Security System)
ON CONFLICT DO NOTHING;


INSERT INTO public.res_os (name, version)
VALUES ('Windows 10', '10'),
('Windows', 'any'),
('Linux', 'any'),
('Ubuntu', '18.04 LTS'),
('Ubuntu 20.04 LTS', '20.04'),
('SUSE SLE 15', '15')
ON CONFLICT DO NOTHING;

-- Перенос ресурсов по таблицам
-- Остальные типы либо новые, либо упразднены
-- resources -> res_hosts\res_accounts\res_devices
DO $$
BEGIN
  IF EXISTS(SELECT * FROM information_schema.tables
    WHERE table_schema = 'public' and table_name  = 'resources')
  THEN

    -- приводим хосты к уникальности по name, domain
    DELETE FROM resources r
    USING resource_types rt
    WHERE r.type = rt.id
    AND r.domain is NOT NULL
    AND rt."name" in ('Виртуальная рабочая станция', 'Рабочая станция', 'Сервер', 'Виртуальный сервер', 'Ноутбук, мобильное устройство')
    AND r.id NOT IN (
        SELECT MIN(id::text)::uuid
        FROM resources
        GROUP BY name, domain
    );

    -- приводим учетки к уникальности по username
    DELETE FROM resources r
    USING resource_types rt
    WHERE r.type = rt.id
    AND r.domain IS NULL
    AND rt.name = 'Учетная запись'
    AND r.id NOT IN (
        SELECT MIN(id::text)::uuid
        FROM resources
        GROUP BY username
    );

    -- переносим хосты
    INSERT INTO res_hosts (id, name, domain, description, fqdn, fixed_ips, fqdn_list, public, virtual, type_id, created, updated, author, object_sid)
    select r.id, r.name, CASE WHEN array_length(string_to_array(r.domain, '.'), 1) > 2 THEN regexp_replace(r.domain, '^[^\.]+\.(.+)$', '\1') ELSE r.domain END AS domain,
    r.info as description, r.domain as fqdn, r.fixed_public_ip_list as fixed_ips, r.public_domains as fqdn_list, r.public_accessible as public,
    CASE WHEN rt.name LIKE 'Виртуал%' THEN true ELSE false END AS virtual,
    CASE WHEN rt.name LIKE '%станция%' THEN (select id from res_types where name = 'workstation' limit 1) ELSE (select id from res_types where name = 'server' limit 1) END AS type_id,
    created_at as created, created_at as updated, created_by as author, object_sid as object_sid
    from resources r join resource_types rt on (r.type = rt.id) where rt."name" in ('Виртуальная рабочая станция', 'Рабочая станция', 'Сервер', 'Виртуальный сервер')
    on CONFLICT DO NOTHING;

    -- переносим учетки
    INSERT INTO res_accounts (id, name, domain, description, username, email, type_id, created, updated, author, object_sid)
    select r.id, r.name, CASE WHEN array_length(string_to_array(r.domain, '.'), 1) > 2 THEN regexp_replace(r.domain, '^[^\.]+\.(.+)$', '\1') ELSE r.domain END AS domain,
    r.info as description, r.username as username, r.email as email,
    (select id from res_types where name = 'account' limit 1) AS type_id,
    created_at as created, created_at as updated, created_by as author, object_sid as object_sid
    from resources r join resource_types rt on (r.type = rt.id) where rt."name" = 'Учетная запись' AND r.username IS NOT NULL on CONFLICT DO NOTHING;

    -- переносим девайсы
    INSERT INTO res_devices (id, name, domain, description, fqdn, fixed_ips, type_id, created, updated, author)
    select r.id, r.name, CASE WHEN array_length(string_to_array(r.domain, '.'), 1) > 2 THEN regexp_replace(r.domain, '^[^\.]+\.(.+)$', '\1') ELSE r.domain END AS domain,
    r.info as description, r.domain as fqdn, r.fixed_public_ip_list as fixed_ips,
    (select id from res_types where name = 'device' limit 1) AS type_id,
    created_at as created, created_at as updated, created_by as author
    from resources r join resource_types rt on (r.type = rt.id) where rt."name" = 'Ноутбук, мобильное устройство' on CONFLICT DO NOTHING;
  END IF;
END $$;

-- Перенос связей
-- resource_contacts -> res_hosts_contacts\res_accounts_contacts\res_devices_contacts
-- resource_locations -> res_hosts_locations\res_accounts_locations\res_devices_locations
-- resource_tags -> res_hosts_tags\res_accounts_tags\res_devices_tags
-- resource_org_units -> res_hosts_org_units\res_accounts_org_units\res_devices_org_units
-- resource_resources -> res_hosts_accounts\res_devices_accounts
DO $$
BEGIN
  IF EXISTS(SELECT * FROM information_schema.tables
    WHERE table_schema = 'public' and table_name  = 'resource_resources')
  THEN

    INSERT INTO res_hosts_contacts (rid, cid, relation)
    select rc.rid, rc.cid, rc.relation
    from resource_contacts rc join resources r on (rc.rid = r.id) join resource_types rt on (r.type = rt.id)
    where rt."name" in ('Виртуальная рабочая станция', 'Рабочая станция', 'Сервер', 'Виртуальный сервер') on CONFLICT DO NOTHING;

    INSERT INTO res_accounts_contacts (rid, cid, relation)
    select rc.rid, rc.cid, rc.relation
    from resource_contacts rc join resources r on (rc.rid = r.id) join resource_types rt on (r.type = rt.id)
    where rt."name" = 'Учетная запись' on CONFLICT DO NOTHING;

    INSERT INTO res_devices_contacts (rid, cid, relation)
    select rc.rid, rc.cid, rc.relation
    from resource_contacts rc join resources r on (rc.rid = r.id) join resource_types rt on (r.type = rt.id)
    where rt."name" = 'Ноутбук, мобильное устройство' on CONFLICT DO NOTHING;

    INSERT INTO res_hosts_locations (rid, lid)
    select rl.rid, rl.lid
    from resource_locations rl join resources r on (rl.rid = r.id) join resource_types rt on (r.type = rt.id) join res_hosts rh on (rl.rid = rh.id)
    where rt."name" in ('Виртуальная рабочая станция', 'Рабочая станция', 'Сервер', 'Виртуальный сервер') on CONFLICT DO NOTHING;

    INSERT INTO res_accounts_locations (rid, lid)
    select rl.rid, rl.lid
    from resource_locations rl join resources r on (rl.rid = r.id) join resource_types rt on (r.type = rt.id)
    where rt."name" = 'Учетная запись' on CONFLICT DO NOTHING;

    INSERT INTO res_devices_locations (rid, lid)
    select rl.rid, rl.lid
    from resource_locations rl join resources r on (rl.rid = r.id) join resource_types rt on (r.type = rt.id)
    where rt."name" = 'Ноутбук, мобильное устройство' on CONFLICT DO NOTHING;

    INSERT INTO res_hosts_tags (rid, tid)
    select rtg.rid, rtg.tid
    from resource_tags rtg join resources r on (rtg.rid = r.id) join resource_types rt on (r.type = rt.id) join res_hosts rh on (rtg.rid = rh.id)
    where rt."name" in ('Виртуальная рабочая станция', 'Рабочая станция', 'Сервер', 'Виртуальный сервер') on CONFLICT DO NOTHING;

    INSERT INTO res_accounts_tags (rid, tid)
    select rtg.rid, rtg.tid
    from resource_tags rtg join resources r on (rtg.rid = r.id) join resource_types rt on (r.type = rt.id) join res_accounts ra on (rtg.rid = ra.id)
    where rt."name" = 'Учетная запись' on CONFLICT DO NOTHING;

    INSERT INTO res_devices_tags (rid, tid)
    select rtg.rid, rtg.tid
    from resource_tags rtg join resources r on (rtg.rid = r.id) join resource_types rt on (r.type = rt.id) join res_devices rd on (rtg.rid = rd.id)
    where rt."name" = 'Ноутбук, мобильное устройство' on CONFLICT DO NOTHING;

    INSERT INTO res_hosts_org_units (rid, ouid)
    select ro.rid, ro.ouid
    from resource_org_units ro join resources r on (ro.rid = r.id) join resource_types rt on (r.type = rt.id) join res_hosts rh on (ro.rid = rh.id)
    where rt."name" in ('Виртуальная рабочая станция', 'Рабочая станция', 'Сервер', 'Виртуальный сервер') on CONFLICT DO NOTHING;

    INSERT INTO res_accounts_org_units (rid, ouid)
    select ro.rid, ro.ouid
    from resource_org_units ro join resources r on (ro.rid = r.id) join resource_types rt on (r.type = rt.id) join res_accounts ra on (ro.rid = ra.id)
    where rt."name" = 'Учетная запись' on CONFLICT DO NOTHING;

    INSERT INTO res_devices_org_units (rid, ouid)
    select ro.rid, ro.ouid
    from resource_org_units ro join resources r on (ro.rid = r.id) join resource_types rt on (r.type = rt.id) join res_devices rd on (ro.rid = rd.id)
    where rt."name" = 'Ноутбук, мобильное устройство' on CONFLICT DO NOTHING;

    INSERT INTO res_hosts_accounts (rid, raid)
    select rr.left_id, rr.right_id
    from resource_resources rr join resources r1 on (rr.left_id = r1.id) join resource_types rt1 on (r1.type = rt1.id)
    join resources r2 on (rr.right_id = r2.id) join resource_types rt2 on (r2.type = rt2.id) join res_hosts rh on (rr.left_id = rh.id) join res_accounts ra on (rr.right_id = ra.id)
    where rt1."name" in ('Виртуальная рабочая станция', 'Рабочая станция', 'Сервер', 'Виртуальный сервер') and rt2."name" = 'Учетная запись'
    UNION
    select rr.right_id, rr.left_id
    from resource_resources rr join resources r1 on (rr.right_id = r1.id) join resource_types rt1 on (r1.type = rt1.id)
    join resources r2 on (rr.left_id = r2.id) join resource_types rt2 on (r2.type = rt2.id) join res_hosts rh on (rr.right_id = rh.id) join res_accounts ra on (rr.left_id = ra.id)
    where rt1."name" in ('Виртуальная рабочая станция', 'Рабочая станция', 'Сервер', 'Виртуальный сервер') and rt2."name" = 'Учетная запись' on CONFLICT DO NOTHING;

    INSERT INTO res_devices_accounts (rid, raid)
    select rr.left_id, rr.right_id
    from resource_resources rr join resources r1 on (rr.left_id = r1.id) join resource_types rt1 on (r1.type = rt1.id)
    join resources r2 on (rr.right_id = r2.id) join resource_types rt2 on (r2.type = rt2.id) join res_devices rd on (rr.left_id = rd.id) join res_accounts ra on (rr.right_id = ra.id)
    where rt1."name" = 'Ноутбук, мобильное устройство' and rt2."name" = 'Учетная запись'
    UNION
    select rr.right_id, rr.left_id
    from resource_resources rr join resources r1 on (rr.right_id = r1.id) join resource_types rt1 on (r1.type = rt1.id)
    join resources r2 on (rr.left_id = r2.id) join resource_types rt2 on (r2.type = rt2.id) join res_devices rd on (rr.right_id = rd.id) join res_accounts ra on (rr.left_id = ra.id)
    where rt1."name" = 'Ноутбук, мобильное устройство' and rt2."name" = 'Учетная запись' on CONFLICT DO NOTHING;

  END IF;
END $$;

-- обновление связей с хостами цензуса
DO $$
BEGIN
  IF EXISTS(SELECT * FROM information_schema.tables
    WHERE table_schema = 'public' and table_name  = 'census_resource_links')
  THEN
    INSERT INTO census_res_hosts (rhid, hid)
    select resource_id, host_id
    from census_resource_links on CONFLICT DO NOTHING;

  END IF;
END $$;

-- добавялем домен в хосты от цензуса
ALTER TABLE public.census_hosts ADD COLUMN IF NOT EXISTS domain public.citext NULL;

-- обновляем внешний ключ для детектов
DO $$
BEGIN
  IF EXISTS(SELECT * FROM information_schema.columns
    WHERE table_name = 'scaner_detection' and column_name  = 'id_resource')
  THEN
    ALTER TABLE public.scaner_detection RENAME COLUMN id_resource TO id_res_host;
    ALTER TABLE public.scaner_detection DROP CONSTRAINT IF EXISTS scaner_detection_resource_fk;
    ALTER TABLE public.scaner_detection ADD CONSTRAINT scaner_detection_res_hosts_fk FOREIGN KEY (id_res_host)
    REFERENCES public.res_hosts(id) ON DELETE CASCADE ON UPDATE CASCADE;

  END IF;
END $$;


-- обновляем внешний ключ для покрытия хостов
DO $$
BEGIN
  IF EXISTS(SELECT * FROM information_schema.columns
    WHERE table_name = 'agentless_hosts' and column_name  = 'id_resource')
  THEN

    DELETE FROM public.agentless_hosts
    WHERE id_resource NOT IN (SELECT id FROM public.res_hosts);

    ALTER TABLE public.agentless_hosts RENAME COLUMN id_resource TO id_res_host;
    ALTER TABLE public.agentless_hosts DROP CONSTRAINT IF EXISTS agentless_hosts_resource_fk;
    ALTER TABLE public.agentless_hosts ADD CONSTRAINT agentless_hosts_res_hosts_fk FOREIGN KEY (id_res_host)
    REFERENCES public.res_hosts(id) ON DELETE SET NULL;

  END IF;
END $$;


-- переносим сети в конфигурацию
DO $$
BEGIN
  IF EXISTS(SELECT id FROM services WHERE type = 'census' AND config IS NOT NULL)
    AND EXISTS (SELECT * FROM information_schema.tables WHERE table_schema = 'public' and table_name  = 'census_user_networks')
  THEN
    UPDATE services
    SET config = jsonb_set(
        config,
        '{host_control_networks}',
        COALESCE(
            (SELECT json_agg(resources.cidr) FROM census_user_networks , resources WHERE census_user_networks.resource_id = resources.id)::jsonb, '[]'::jsonb
        ),
        true
    )
    WHERE type = 'census';

  END IF;
END $$;

-- добавление столбца для определения связанных объектов
ALTER TABLE public.scripts_tasks
ADD COLUMN IF NOT EXISTS "from" jsonb DEFAULT NULL;

-- таблица для связи правил и скриптов
CREATE TABLE IF NOT EXISTS signal_rules_scripts
(
    rid uuid NOT NULL,
    sid uuid NOT NULL,
    priority text NOT NULL,
    CONSTRAINT signal_rules_scripts_pkey PRIMARY KEY (rid, sid),
    CONSTRAINT signal_rules_scripts_sid_fkey FOREIGN KEY (sid) REFERENCES public.scripts_encrypted (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT signal_rules_scripts_rid_fkey FOREIGN KEY (rid) REFERENCES public.signal_rules (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);

-- таблица для связи СЗИ и скриптов
CREATE TABLE IF NOT EXISTS res_iss_scripts
(
    rid uuid NOT NULL,
    sid uuid NOT NULL,
    priority text NOT NULL,
    CONSTRAINT res_iss_scripts_pkey PRIMARY KEY (rid, sid),
    CONSTRAINT res_iss_scripts_sid_fkey FOREIGN KEY (sid) REFERENCES public.scripts_encrypted (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT res_iss_scripts_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_iss (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);

-- таблица для связи воркспейсов и скриптов
CREATE TABLE IF NOT EXISTS workspaces_scripts_encrypted
(
    wid uuid NOT NULL,
    sid uuid NOT NULL,
    args jsonb,
    secrets bytea,
    limits jsonb,
    host text NULL,
    priority text NOT NULL,
    CONSTRAINT workspaces_scripts_pkey PRIMARY KEY (wid, sid),
    CONSTRAINT workspaces_scripts_sid_fkey FOREIGN KEY (sid) REFERENCES public.scripts_encrypted (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT workspaces_scripts_wid_fkey FOREIGN KEY (wid) REFERENCES public.workspaces (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);

-- таблица для связи листов блокнота и скриптов
CREATE TABLE IF NOT EXISTS notepad_lists_scripts_encrypted
(
    nid uuid NOT NULL,
    sid uuid NOT NULL,
    args jsonb,
    secrets bytea,
    limits jsonb,
    host text NULL,
    priority text NOT NULL,
    CONSTRAINT notepad_lists_scripts_pkey PRIMARY KEY (nid, sid),
    CONSTRAINT notepad_lists_scripts_sid_fkey FOREIGN KEY (sid) REFERENCES public.scripts_encrypted (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT notepad_lists_scripts_nid_fkey FOREIGN KEY (nid) REFERENCES public.notepad_lists (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
);

-- таблица для связи листов блокнота и задач запуска скриптов
CREATE TABLE IF NOT EXISTS notepad_lists_scripts_tasks
(
    nid uuid NOT NULL,
    tid uuid NOT NULL,
    CONSTRAINT notepad_lists_scripts_tasks_pkey PRIMARY KEY (nid, tid),
    CONSTRAINT notepad_lists_scripts_tasks_tid FOREIGN KEY (tid) REFERENCES public.scripts_tasks (id) MATCH SIMPLE
    ON UPDATE CASCADE
    ON DELETE CASCADE,
    CONSTRAINT notepad_lists_scripts_tasks_nid FOREIGN KEY (nid) REFERENCES public.notepad_lists (id) MATCH SIMPLE
    ON UPDATE CASCADE
    ON DELETE CASCADE
);

-- таблица для связи воркспейсов и задач запуска скриптов
CREATE TABLE IF NOT EXISTS workspaces_scripts_tasks
(
    wid uuid NOT NULL,
    tid uuid NOT NULL,
    CONSTRAINT workspaces_scripts_tasks_pkey PRIMARY KEY (wid, tid),
    CONSTRAINT workspaces_scripts_tasks_tid FOREIGN KEY (tid) REFERENCES public.scripts_tasks (id) MATCH SIMPLE
    ON UPDATE CASCADE
    ON DELETE CASCADE,
    CONSTRAINT workspaces_scripts_tasks_wid FOREIGN KEY (wid) REFERENCES public.workspaces (id) MATCH SIMPLE
    ON UPDATE CASCADE
    ON DELETE CASCADE
);


DO $$
BEGIN
  IF EXISTS(SELECT * FROM information_schema.tables
    WHERE table_schema = 'public' and table_name  = 'targets')
  THEN
    -- Связи между ресурсами-хостами и инцидентами
    CREATE TABLE IF NOT EXISTS public.ws_targets_hosts
    (
        wid uuid NOT NULL,
        rid uuid NOT NULL,
        way_to_use text COLLATE pg_catalog."default",
        created_at bigint NOT NULL,
        is_threat boolean DEFAULT false NOT NULL,
        CONSTRAINT ws_targets_hosts_pkey PRIMARY KEY (wid, rid),
        CONSTRAINT ws_targets_hosts_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_hosts (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
        CONSTRAINT ws_targets_hosts_wid_fkey FOREIGN KEY (wid) REFERENCES public.workspaces (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
    );
    COMMENT ON TABLE public.ws_targets_hosts IS 'Связи инцидентов с хостами';

    -- Связи между ресурсами-учетками и инцидентами
    CREATE TABLE IF NOT EXISTS public.ws_targets_accounts
    (
        wid uuid NOT NULL,
        rid uuid NOT NULL,
        way_to_use text COLLATE pg_catalog."default",
        created_at bigint NOT NULL,
        is_threat boolean DEFAULT false NOT NULL,
        CONSTRAINT ws_targets_accounts_pkey PRIMARY KEY (wid, rid),
        CONSTRAINT ws_targets_accounts_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_accounts (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
        CONSTRAINT ws_targets_accounts_wid_fkey FOREIGN KEY (wid) REFERENCES public.workspaces (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
    );
    COMMENT ON TABLE public.ws_targets_accounts IS 'Связи инцидентов с учетными записями';

    -- Связи между ресурсами-сзи и инцидентами
    CREATE TABLE IF NOT EXISTS public.ws_targets_iss
    (
        wid uuid NOT NULL,
        rid uuid NOT NULL,
        way_to_use text COLLATE pg_catalog."default",
        created_at bigint NOT NULL,
        is_threat boolean DEFAULT false NOT NULL,
        CONSTRAINT ws_targets_iss_pkey PRIMARY KEY (wid, rid),
        CONSTRAINT ws_targets_iss_rid_fkey FOREIGN KEY (rid) REFERENCES public.res_iss (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE,
        CONSTRAINT ws_targets_iss_wid_fkey FOREIGN KEY (wid) REFERENCES public.workspaces (id) MATCH SIMPLE ON UPDATE CASCADE ON DELETE CASCADE
    );
    COMMENT ON TABLE public.ws_targets_iss IS 'Связи инцидентов с сзи';

    -- перенос таргетов
    INSERT INTO ws_targets_hosts (wid, rid, way_to_use, created_at, is_threat)
    select t.wsid, t.rid, t.way_to_use, t.created_at, t.is_threat
    from targets t join resources r on (t.rid = r.id) join resource_types rt on (r.type = rt.id)
    where rt."name" in ('Виртуальная рабочая станция', 'Рабочая станция', 'Сервер', 'Виртуальный сервер') on CONFLICT DO NOTHING;

    INSERT INTO ws_targets_accounts (wid, rid, way_to_use, created_at, is_threat)
    select t.wsid, t.rid, t.way_to_use, t.created_at, t.is_threat
    from targets t join resources r on (t.rid = r.id) join resource_types rt on (r.type = rt.id)
    where rt."name" = 'Учетная запись' on CONFLICT DO NOTHING;

  END IF;
END $$;


-- удаление старых таблиц
DROP TABLE IF EXISTS os_types;
DROP TABLE IF EXISTS incoming_os_types;

DROP TABLE IF EXISTS census_temp_ids;
DROP TABLE IF EXISTS census_agent_types;
DROP TABLE IF EXISTS census_resource_links;
DROP TABLE IF EXISTS census_user_networks;

DROP TABLE IF EXISTS resource_contacts;
DROP TABLE IF EXISTS resource_locations;
DROP TABLE IF EXISTS resource_resources;
DROP TABLE IF EXISTS resource_tags;
DROP TABLE IF EXISTS resource_org_units;
DROP TABLE IF EXISTS targets;
DROP TABLE IF EXISTS resources;
DROP TABLE IF EXISTS resource_types;

DROP TABLE IF EXISTS incoming_resource_contacts;
DROP TABLE IF EXISTS incoming_resource_locations;
DROP TABLE IF EXISTS incoming_resource_resources;
DROP TABLE IF EXISTS incoming_resource_tags;
DROP TABLE IF EXISTS incoming_resource_org_units;
DROP TABLE IF EXISTS incoming_resources;

-- добавляем столбец для сырого события
ALTER TABLE public.facts ADD COLUMN IF NOT EXISTS raw_event json NULL;


-- таблица для возможного бэкапа ресурсов
CREATE TABLE IF NOT EXISTS public.ws_targets_backup(
    wsid uuid NOT NULL, -- идентификатор воркспейса
    rid uuid NOT NULL, -- идентификатор ресурса
    type_id uuid NOT NULL, -- тип ресурса, для восстановления
    attrs json NOT NULL, -- атрибуты ресурса для восстановления
    way_to_use text NULL, -- способ использования
    created_at int8 NOT NULL, -- дата создания
    is_threat bool DEFAULT false NOT NULL, -- флаг угрозы
    CONSTRAINT ws_targets_backup_pkey PRIMARY KEY (wsid, rid),
    CONSTRAINT ws_targets_backup_res_types_fk FOREIGN KEY (type_id) REFERENCES public.res_types(id) ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT ws_targets_backup_workspaces_fk FOREIGN KEY (wsid) REFERENCES public.workspaces(id) ON DELETE CASCADE ON UPDATE CASCADE
);

ALTER TABLE public.dashboards
ADD IF NOT EXISTS version int4 NOT NULL DEFAULT 1,
ADD IF NOT EXISTS vendor text NULL;

-- таблица связей с инцидентами MP SIEM
CREATE TABLE IF NOT EXISTS public.ws_mp_ids (
	wsid uuid NOT NULL, -- идентификатор воркспейса
	mpid uuid NULL, -- идентификатор инцидента (возможен null, если добавили у себя, но не синхронизировали)
	"update" int8 NULL, -- время обновления воркспейса
	CONSTRAINT ws_mp_ids_pk PRIMARY KEY (wsid),
	CONSTRAINT ws_mp_ids_unique UNIQUE (mpid)
);

-- добавляем mp siem в интеграции
INSERT INTO integrations_encrypted (name, service, enabled, type) VALUES
('mpsiem', 'mpsiem', false, 'notify')
ON CONFLICT DO NOTHING;


-- Триггеры для отслеживания потока
CREATE TABLE IF NOT EXISTS public.watchdog_flow (
    id uuid NOT NULL DEFAULT gen_random_uuid(), -- идентификатор
    observer_name text NOT NULL, -- имя обсервера
    hosts citext[] NULL, -- хосты
    enabled boolean NOT NULL DEFAULT false, -- флаг включения/выключения (отслеживания)
    activity text NOT NULL DEFAULT '3d', -- период активности для проверки
    CONSTRAINT watchdog_flow_pk PRIMARY KEY (id),
    CONSTRAINT watchdog_flow_observer_hosts_uq UNIQUE (observer_name, hosts)
);
COMMENT ON TABLE public.watchdog_flow IS 'Таблица триггеров для отслеживания активности потока';


-- Аномалии для отслеживания потока
CREATE TABLE IF NOT EXISTS public.watchdog_flow_anomalies (
    id uuid NOT NULL DEFAULT gen_random_uuid(), -- идентификатор
    observer_name text NOT NULL, -- имя обсервера
    hosts citext[] NULL, -- хосты
    deviation_down int4 NOT NULL, -- отклонение вниз
    deviation_up int4 NOT NULL, -- отклонение вверх
    CONSTRAINT watchdog_flow_anomalies_pk PRIMARY KEY (id),
    CONSTRAINT watchdog_flow_anomalies_observer_hosts_uq UNIQUE (observer_name, hosts)
);
COMMENT ON TABLE public.watchdog_flow_anomalies IS 'Таблица аномалий для потока';

-- добавляем тип (системный/пользовательский)
ALTER TABLE public.watchdog_triggers ADD COLUMN IF NOT EXISTS "system" bool DEFAULT false NOT NULL;

-- обновляем пользовательские
UPDATE public.watchdog_triggers SET system = true WHERE blocked = true;

-- обновление атрибутов для аномалий
DO $$
BEGIN
  IF EXISTS(SELECT * FROM information_schema.columns
    WHERE table_name = 'watchdog_anomalies' and column_name  = 'threshold')
  THEN
    ALTER TABLE public.watchdog_anomalies ADD COLUMN IF NOT EXISTS deviation_up int4 NULL;
    ALTER TABLE public.watchdog_anomalies ADD COLUMN IF NOT EXISTS deviation_down int4 NULL;

    UPDATE watchdog_anomalies SET
    deviation_up = CASE
        WHEN ABS(threshold) = 1 THEN 30
        WHEN ABS(threshold) = 2 THEN 60
        WHEN ABS(threshold) > 2 THEN 90
        ELSE 0
    END,
    deviation_down = CASE
        WHEN ABS(threshold) = 1 THEN 30
        WHEN ABS(threshold) = 2 THEN 60
        WHEN ABS(threshold) > 2 THEN 90
        ELSE 0
    END;

    -- удаляем дубликаты
    DELETE FROM watchdog_anomalies
    WHERE id IN (
        SELECT id FROM (
                SELECT id,
                ROW_NUMBER() OVER (PARTITION BY component_type, component_name, component_host, metric_name, alternate_name, priority, message, deviation_up, deviation_down ORDER BY id) as rn
                FROM watchdog_anomalies
        ) t
    WHERE rn > 1
);

    ALTER TABLE public.watchdog_anomalies DROP COLUMN IF EXISTS threshold;

  END IF;
END $$;

INSERT INTO public.dataset_storages (id, type, config) VALUES
('bc7e8d80-c9b4-40ac-9047-48699f038677'::uuid, 'opensearch', '{"index": "*:alertix-*"}'),
('08689f60-d66e-40b7-8608-855569e469d5'::uuid, 'opensearch', '{"index": "*:alertix-winlogbeat-*"}'),
('5620cd6e-c300-406e-a0b1-e11608a038b1'::uuid, 'opensearch', '{"index": "*:alertix-agent-*"}'),
('0675d1cb-819b-45da-8e98-16cf51b60ff9'::uuid, 'opensearch', '{"index": "*:alertix-census-*"}'),
('b6461af6-81c8-4811-b3cb-4b17a0f19340'::uuid, 'opensearch', '{"index": "*:alertix-ioc-detections-*"}'),
('e3b503e7-5480-4a9e-9db3-a5a6d22e6cbd'::uuid, 'opensearch', '{"index": "*:alertix-signal-*"}'),
('3b3ffc39-97e3-491a-b196-56ccf87991c4'::uuid, 'opensearch', '{"index": "*:alertix-ueba-*"}')
ON CONFLICT DO NOTHING;

INSERT INTO public.datasets (
    id,
    name,
    description,
    storage_id,
    local,
    is_raw,
    raw_query,
    gen_settings,
    content,
    tags,
    timefield,
    mapping,
    published,
    opened,
    created_from,
    author
) VALUES
('1f6bda15-fe7e-42f9-8b6a-d3b2efa1b5f0'::uuid, 'События Sysmon', '', '08689f60-d66e-40b7-8608-855569e469d5'::uuid, false, false, NULL, '{"filter_list": [{"field": "alertix.observer.product.name", "value": "sysmon", "action": "=="}]}', '{"sort": [{"name": "@timestamp", "order": "desc"}], "time": {"zone": "Europe/Istanbul", "field": "@timestamp", "interval": {"to": "now", "from": "now-1d"}}, "search": {"query": "", "language": "dql"}, "columns": ["winlog.computer_name", "winlog.event_data.ProcessBareName", "alertix.event.action"], "filters": [{"meta": {"mode": "common", "alias": null, "isPinned": false, "isDisabled": false}, "filter": {"field": {"name": "alertix.observer.product.name", "type": "keyword", "parameters": {}}, "value": {"value": "sysmon", "parameters": {}}, "condition": {"type": "equally", "parameters": {}}}}], "indices": ["*:alertix-winlogbeat-*"], "settings": {"search": "index", "variant": "card", "histogram": true, "pagination": "pagination"}, "histogram": {"interval": "auto"}, "observers": ["*"]}', '{Обзор}', '@timestamp', '{}', true, true, 'overview', get_default_author()),
('60553524-cbdb-4333-923f-7916cf5d2fde'::uuid, 'Активность процессов (Sysmon)', '', '08689f60-d66e-40b7-8608-855569e469d5'::uuid, false, false, NULL, '{"filter_list": [{"field": "alertix.observer.product.name", "value": "sysmon", "action": "=="}, {"field": "alertix.event.code", "value": ["1", "4", "5", "6", "7", "8", "10", "16"], "action": "IN"}]}', '{"sort": [{"name": "@timestamp", "order": "desc"}], "time": {"zone": "Europe/Istanbul", "field": "@timestamp", "interval": {"to": "now", "from": "now-1d"}}, "search": {"query": "", "language": "dql"}, "columns": ["winlog.computer_name", "winlog.event_data.ProcessBareName", "alertix.event.action", "winlog.event_data.TargetImage"], "filters": [{"meta": {"mode": "common", "alias": null, "isPinned": false, "isDisabled": false}, "filter": {"field": {"name": "alertix.observer.product.name", "type": "keyword", "parameters": {}}, "value": {"value": "sysmon", "parameters": {}}, "condition": {"type": "equally", "parameters": {}}}}, {"meta": {"mode": "common", "alias": null, "isPinned": false, "isDisabled": false}, "filter": {"field": {"name": "alertix.event.code", "type": "keyword", "parameters": {}}, "value": {"value": ["1", "4", "5", "6", "7", "8", "10", "16"], "parameters": {}}, "condition": {"type": "one_of", "parameters": {}}}}], "indices": ["*:alertix-winlogbeat-*"], "settings": {"search": "index", "variant": "card", "histogram": true, "pagination": "pagination"}, "histogram": {"interval": "auto"}, "observers": ["*"]}', '{Обзор}', '@timestamp', '{}', true, true, 'overview', get_default_author()),
('2ecc54e4-8429-41b2-998a-824e43504607'::uuid, 'Сетевые соединения (Sysmon)', '', '08689f60-d66e-40b7-8608-855569e469d5'::uuid, false, false, NULL, '{"filter_list": [{"field": "alertix.observer.product.name", "value": "sysmon", "action": "=="}, {"field": "alertix.event.code", "value": ["3", "22"], "action": "IN"}]}', '{"sort": [{"name": "@timestamp", "order": "desc"}], "time": {"zone": "Europe/Istanbul", "field": "@timestamp", "interval": {"to": "now", "from": "now-1d"}}, "search": {"query": "", "language": "dql"}, "columns": ["winlog.computer_name", "winlog.event_data.ProcessBareName", "alertix.event.action", "winlog.event_data.DestinationHostname"], "filters": [{"meta": {"mode": "common", "alias": null, "isPinned": false, "isDisabled": false}, "filter": {"field": {"name": "alertix.observer.product.name", "type": "keyword", "parameters": {}}, "value": {"value": "sysmon", "parameters": {}}, "condition": {"type": "equally", "parameters": {}}}}, {"meta": {"mode": "common", "alias": null, "isPinned": false, "isDisabled": false}, "filter": {"field": {"name": "alertix.event.code", "type": "keyword", "parameters": {}}, "value": {"value": ["3", "22"], "parameters": {}}, "condition": {"type": "one_of", "parameters": {}}}}], "indices": ["*:alertix-winlogbeat-*"], "settings": {"search": "index", "variant": "card", "histogram": true, "pagination": "pagination"}, "histogram": {"interval": "auto"}, "observers": ["*"]}', '{Обзор}', '@timestamp', '{}', true, true, 'overview', get_default_author()),
('a39dd19c-8f6e-4d79-9b1b-e00e296f884c'::uuid, 'Именованные каналы (Sysmon)', '', '08689f60-d66e-40b7-8608-855569e469d5'::uuid, false, false, NULL, '{"filter_list": [{"field": "alertix.observer.product.name", "value": "sysmon", "action": "=="}, {"field": "alertix.event.code", "value": ["17", "18"], "action": "IN"}]}', '{"sort": [{"name": "@timestamp", "order": "desc"}], "time": {"zone": "Europe/Istanbul", "field": "@timestamp", "interval": {"to": "now", "from": "now-1d"}}, "search": {"query": "", "language": "dql"}, "columns": ["winlog.computer_name", "winlog.event_data.ProcessBareName", "alertix.event.action", "winlog.event_data.PipeName"], "filters": [{"meta": {"mode": "common", "alias": null, "isPinned": false, "isDisabled": false}, "filter": {"field": {"name": "alertix.observer.product.name", "type": "keyword", "parameters": {}}, "value": {"value": "sysmon", "parameters": {}}, "condition": {"type": "equally", "parameters": {}}}}, {"meta": {"mode": "common", "alias": null, "isPinned": false, "isDisabled": false}, "filter": {"field": {"name": "alertix.event.code", "type": "keyword", "parameters": {}}, "value": {"value": ["17", "18"], "parameters": {}}, "condition": {"type": "one_of", "parameters": {}}}}], "indices": ["*:alertix-winlogbeat-*"], "settings": {"search": "index", "variant": "card", "histogram": true, "pagination": "pagination"}, "histogram": {"interval": "auto"}, "observers": ["*"]}', '{Обзор}', '@timestamp', '{}', true, true, 'overview', get_default_author()),
('50b85e5f-5c23-4dcf-bb9c-56b2809c26d4'::uuid, 'Операции с реестром (Sysmon)', '', '08689f60-d66e-40b7-8608-855569e469d5'::uuid, false, false, NULL, '{"filter_list": [{"field": "alertix.observer.product.name", "value": "sysmon", "action": "=="}, {"field": "alertix.event.code", "value": ["12", "13", "14"], "action": "IN"}]}', '{"sort": [{"name": "@timestamp", "order": "desc"}], "time": {"zone": "Europe/Istanbul", "field": "@timestamp", "interval": {"to": "now", "from": "now-1d"}}, "search": {"query": "", "language": "dql"}, "columns": ["winlog.computer_name", "winlog.event_data.ProcessBareName", "alertix.event.action", "winlog.event_data.TargetObject"], "filters": [{"meta": {"mode": "common", "alias": null, "isPinned": false, "isDisabled": false}, "filter": {"field": {"name": "alertix.observer.product.name", "type": "keyword", "parameters": {}}, "value": {"value": "sysmon", "parameters": {}}, "condition": {"type": "equally", "parameters": {}}}}, {"meta": {"mode": "common", "alias": null, "isPinned": false, "isDisabled": false}, "filter": {"field": {"name": "alertix.event.code", "type": "keyword", "parameters": {}}, "value": {"value": ["12", "13", "14"], "parameters": {}}, "condition": {"type": "one_of", "parameters": {}}}}], "indices": ["*:alertix-winlogbeat-*"], "settings": {"search": "index", "variant": "card", "histogram": true, "pagination": "pagination"}, "histogram": {"interval": "auto"}, "observers": ["*"]}', '{Обзор}', '@timestamp', '{}', true, true, 'overview', get_default_author()),
('2a445a26-9d50-4692-90ed-71713adf2cef'::uuid, 'Операции с файлами (Sysmon)', '', '08689f60-d66e-40b7-8608-855569e469d5'::uuid, false, false, NULL, '{"filter_list": [{"field": "alertix.observer.product.name", "value": "sysmon", "action": "=="}, {"field": "alertix.event.code", "value": ["2", "9", "11", "15", "23"], "action": "IN"}]}', '{"sort": [{"name": "@timestamp", "order": "desc"}], "time": {"zone": "Europe/Istanbul", "field": "@timestamp", "interval": {"to": "now", "from": "now-1d"}}, "search": {"query": "", "language": "dql"}, "columns": ["winlog.computer_name", "winlog.event_data.ProcessBareName", "alertix.event.action", "winlog.event_data.TargetFilename"], "filters": [{"meta": {"mode": "common", "alias": null, "isPinned": false, "isDisabled": false}, "filter": {"field": {"name": "alertix.observer.product.name", "type": "keyword", "parameters": {}}, "value": {"value": "sysmon", "parameters": {}}, "condition": {"type": "equally", "parameters": {}}}}, {"meta": {"mode": "common", "alias": null, "isPinned": false, "isDisabled": false}, "filter": {"field": {"name": "alertix.event.code", "type": "keyword", "parameters": {}}, "value": {"value": ["2", "9", "11", "15", "23"], "parameters": {}}, "condition": {"type": "one_of", "parameters": {}}}}], "indices": ["*:alertix-winlogbeat-*"], "settings": {"search": "index", "variant": "card", "histogram": true, "pagination": "pagination"}, "histogram": {"interval": "auto"}, "observers": ["*"]}', '{Обзор}', '@timestamp', '{}', true, true, 'overview', get_default_author()),
('f43022ec-f505-4418-a793-02c834b15dca'::uuid, 'Регистрации в системе (логон/логофф)', '', 'bc7e8d80-c9b4-40ac-9047-48699f038677'::uuid, false, false, NULL, '{"filter_list": [{"field": "alertix.event.action", "value": ["logon", "logoff"], "action": "IN"}]}', '{"sort": [{"name": "@timestamp", "order": "desc"}], "time": {"zone": "Europe/Istanbul", "field": "@timestamp", "interval": {"to": "now", "from": "now-1d"}}, "search": {"query": "", "language": "dql"}, "columns": ["user.name", "host.hostname", "alertix.observer.product.name", "alertix.event.name", "message"], "filters": [{"meta": {"mode": "common", "alias": null, "isPinned": false, "isDisabled": false}, "filter": {"field": {"name": "alertix.event.action", "type": "keyword", "parameters": {}}, "value": {"value": ["logon", "logoff"], "parameters": {}}, "condition": {"type": "one_of", "parameters": {}}}}], "indices": ["*:alertix-*"], "settings": {"search": "index", "variant": "card", "histogram": true, "pagination": "pagination"}, "histogram": {"interval": "auto"}, "observers": ["*"]}', '{Обзор}', '@timestamp', '{}', true, true, 'overview', get_default_author()),
('ff3a055a-8ab7-4a59-8f86-8b04817fc422'::uuid, 'Сетевые потоки', '', 'bc7e8d80-c9b4-40ac-9047-48699f038677'::uuid, false, false, NULL, '{"filter_list": [{"field": "alertix.event.name", "value": ["traffic", "netflow message"], "action": "IN"}]}', '{"sort": [{"name": "@timestamp", "order": "desc"}], "time": {"zone": "Europe/Istanbul", "field": "@timestamp", "interval": {"to": "now", "from": "now-1d"}}, "search": {"query": "", "language": "dql"}, "columns": ["network.bytes", "source.ip", "destination.ip", "alertix.observer.product.name", "alertix.source.tags", "alertix.event.name", "message"], "filters": [{"meta": {"mode": "common", "alias": null, "isPinned": false, "isDisabled": false}, "filter": {"field": {"name": "alertix.event.name", "type": "keyword", "parameters": {}}, "value": {"value": ["traffic", "netflow message"], "parameters": {}}, "condition": {"type": "one_of", "parameters": {}}}}], "indices": ["*:alertix-*"], "settings": {"search": "index", "variant": "card", "histogram": true, "pagination": "pagination"}, "histogram": {"interval": "auto"}, "observers": ["*"]}', '{Обзор}', '@timestamp', '{}', true, true, 'overview', get_default_author()),
('a9cc1e7d-ac59-4fd8-9e27-42b50017826d'::uuid, 'Активность процессов (Linux Log)', '', 'bc7e8d80-c9b4-40ac-9047-48699f038677'::uuid, false, false, NULL, '{"filter_list": [{"field": "alertix.event.category", "value": "process", "action": "=="}]}', '{"sort": [{"name": "@timestamp", "order": "desc"}], "time": {"zone": "Europe/Istanbul", "field": "@timestamp", "interval": {"to": "now", "from": "now-1d"}}, "search": {"query": "", "language": "dql"}, "columns": ["host.name", "user.name", "alertix.event.action", "process.name"], "filters": [{"meta": {"mode": "common", "alias": null, "isPinned": false, "isDisabled": false}, "filter": {"field": {"name": "alertix.event.category", "type": "keyword", "parameters": {}}, "value": {"value": "process", "parameters": {}}, "condition": {"type": "equally", "parameters": {}}}}], "indices": ["*:alertix-*"], "settings": {"search": "index", "variant": "card", "histogram": true, "pagination": "pagination"}, "histogram": {"interval": "auto"}, "observers": ["*"]}', '{Обзор}', '@timestamp', '{}', true, true, 'overview', get_default_author()),
('fb11c1ee-f089-468b-b59d-a6373c88c622'::uuid, 'Сетевые соединения (Linux Log)', '', 'bc7e8d80-c9b4-40ac-9047-48699f038677'::uuid, false, false, NULL, '{"filter_list": [{"field": "destination.ip", "value": "", "action": "EXISTS"}, {"field": "source.ip", "value": "", "action": "EXISTS"}, {"field": "alertix.event.category", "value": "network", "action": "=="}]}', '{"sort": [{"name": "@timestamp", "order": "desc"}], "time": {"zone": "Europe/Istanbul", "field": "@timestamp", "interval": {"to": "now", "from": "now-1d"}}, "search": {"query": "", "language": "dql"}, "columns": ["source.ip", "source.port", "destination.ip", "destination.port", "message"], "filters": [{"meta": {"mode": "common", "alias": null, "isPinned": false, "isDisabled": false}, "filter": {"field": {"name": "destination.ip", "type": "ip", "parameters": {}}, "value": {"value": "", "parameters": {}}, "condition": {"type": "exists", "parameters": {}}}}, {"meta": {"mode": "common", "alias": null, "isPinned": false, "isDisabled": false}, "filter": {"field": {"name": "source.ip", "type": "ip", "parameters": {}}, "value": {"value": "", "parameters": {}}, "condition": {"type": "exists", "parameters": {}}}}, {"meta": {"mode": "common", "alias": null, "isPinned": false, "isDisabled": false}, "filter": {"field": {"name": "alertix.event.category", "type": "keyword", "parameters": {}}, "value": {"value": "network", "parameters": {}}, "condition": {"type": "equally", "parameters": {}}}}], "indices": ["*:alertix-*"], "settings": {"search": "index", "variant": "card", "histogram": true, "pagination": "pagination"}, "histogram": {"interval": "auto"}, "observers": ["*"]}', '{Обзор}', '@timestamp', '{}', true, true, 'overview', get_default_author()),
('ed6a170e-8575-4f71-b634-06266435dadb'::uuid, 'Агенты Alertix', '', '5620cd6e-c300-406e-a0b1-e11608a038b1'::uuid, false, false, NULL, '{"filter_list": [{"field": "alertix.observer.product.name", "value": "alertix agent", "action": "=="}]}', '{"sort": [{"name": "@timestamp", "order": "desc"}], "time": {"zone": "Europe/Istanbul", "field": "@timestamp", "interval": {"to": "now", "from": "now-1d"}}, "search": {"query": "", "language": "dql"}, "columns": ["host.name", "host.ip", "host.os.type", "alertix.observer.product.version", "alertix.event.name", "message"], "filters": [{"meta": {"mode": "common", "alias": null, "isPinned": false, "isDisabled": false}, "filter": {"field": {"name": "alertix.observer.product.name", "type": "keyword", "parameters": {}}, "value": {"value": "alertix agent", "parameters": {}}, "condition": {"type": "equally", "parameters": {}}}}], "indices": ["*:alertix-agent-*"], "settings": {"search": "index", "variant": "card", "histogram": true, "pagination": "pagination"}, "histogram": {"interval": "auto"}, "observers": ["*"]}', '{Обзор}', '@timestamp', '{}', true, true, 'overview', get_default_author()),
('f6c75a35-a6ec-45d5-8dfb-03e2cdbf3121'::uuid, 'Инвентаризация и контроль трафика Census', '', '0675d1cb-819b-45da-8e98-16cf51b60ff9'::uuid, false, false, NULL, '{"filter_list": [{"field": "alertix.observer.product.name", "value": "census", "action": "=="}]}', '{"sort": [{"name": "@timestamp", "order": "desc"}], "time": {"zone": "Europe/Istanbul", "field": "@timestamp", "interval": {"to": "now", "from": "now-1d"}}, "search": {"query": "", "language": "dql"}, "columns": ["host.name", "alertix.event.name", "census.activity_status", "census.activity_type", "census.source_type", "message"], "filters": [{"meta": {"mode": "common", "alias": null, "isPinned": false, "isDisabled": false}, "filter": {"field": {"name": "alertix.observer.product.name", "type": "keyword", "parameters": {}}, "value": {"value": "census", "parameters": {}}, "condition": {"type": "equally", "parameters": {}}}}], "indices": ["*:alertix-census-*"], "settings": {"search": "index", "variant": "card", "histogram": true, "pagination": "pagination"}, "histogram": {"interval": "auto"}, "observers": ["*"]}', '{Обзор}', '@timestamp', '{}', true, true, 'overview', get_default_author()),
('e9074c4a-588e-41e3-9d05-c8fb49c5d267'::uuid, 'Обнаружение индикаторов компрометации', '', 'b6461af6-81c8-4811-b3cb-4b17a0f19340'::uuid, false, false, NULL, '{"filter_list": [{"field": "alertix.observer.product.name", "value": "ioc-watcher", "action": "=="}]}', '{"sort": [{"name": "@timestamp", "order": "desc"}], "time": {"zone": "Europe/Istanbul", "field": "@timestamp", "interval": {"to": "now", "from": "now-1d"}}, "search": {"query": "", "language": "dql"}, "columns": ["alertix.event.risk_score_norm", "host.name", "user.name", "ioc_watcher.ioc", "message"], "filters": [{"meta": {"mode": "common", "alias": null, "isPinned": false, "isDisabled": false}, "filter": {"field": {"name": "alertix.observer.product.name", "type": "keyword", "parameters": {}}, "value": {"value": "ioc-watcher", "parameters": {}}, "condition": {"type": "equally", "parameters": {}}}}], "indices": ["*:alertix-ioc-detections-*"], "settings": {"search": "index", "variant": "card", "histogram": true, "pagination": "pagination"}, "histogram": {"interval": "auto"}, "observers": ["*"]}', '{Обзор}', '@timestamp', '{}', true, true, 'overview', get_default_author()),
('d84c73a3-2f8e-4375-ab0a-294ea761bcf2'::uuid, 'Сработки Signal', '', 'e3b503e7-5480-4a9e-9db3-a5a6d22e6cbd'::uuid, false, false, NULL, '{"filter_list": [{"field": "alertix.observer.product.name", "value": "signal", "action": "=="}]}', '{"sort": [{"name": "@timestamp", "order": "desc"}], "time": {"zone": "Europe/Istanbul", "field": "@timestamp", "interval": {"to": "now", "from": "now-1d"}}, "search": {"query": "", "language": "dql"}, "columns": ["alertix.event.risk_score_norm", "host.name", "user.name", "process.name", "alertix.signal.category", "alertix.signal.description"], "filters": [{"meta": {"mode": "common", "alias": null, "isPinned": false, "isDisabled": false}, "filter": {"field": {"name": "alertix.observer.product.name", "type": "keyword", "parameters": {}}, "value": {"value": "signal", "parameters": {}}, "condition": {"type": "equally", "parameters": {}}}}], "indices": ["*:alertix-signal-*"], "settings": {"search": "index", "variant": "card", "histogram": true, "pagination": "pagination"}, "histogram": {"interval": "auto"}, "observers": ["*"]}', '{Обзор}', '@timestamp', '{}', true, true, 'overview', get_default_author()),
('5dd9091e-abd0-4aa5-aced-855ca94b65e2'::uuid, 'Поведенческие аномалии', '', '3b3ffc39-97e3-491a-b196-56ccf87991c4'::uuid, false, false, NULL, '{"filter_list": [{"field": "alertix.observer.product.name", "value": "ueba", "action": "=="}]}', '{"sort": [{"name": "@timestamp", "order": "desc"}], "time": {"zone": "Europe/Istanbul", "field": "@timestamp", "interval": {"to": "now", "from": "now-1d"}}, "search": {"query": "", "language": "dql"}, "columns": ["alertix.event.risk_score_norm", "host.name", "user.name", "alertix.event.code", "alertix.event.name", "message"], "filters": [{"meta": {"mode": "common", "alias": null, "isPinned": false, "isDisabled": false}, "filter": {"field": {"name": "alertix.observer.product.name", "type": "keyword", "parameters": {}}, "value": {"value": "ueba", "parameters": {}}, "condition": {"type": "equally", "parameters": {}}}}], "indices": ["*:alertix-ueba-*"], "settings": {"search": "index", "variant": "card", "histogram": true, "pagination": "pagination"}, "histogram": {"interval": "auto"}, "observers": ["*"]}', '{Обзор}', '@timestamp', '{}', true, true, 'overview', get_default_author())
ON CONFLICT DO NOTHING;

-- меняем индексы для источников ресиверов
ALTER TABLE public.receiver_sources_encrypted DROP CONSTRAINT IF exists receiver_sources_un;

CREATE UNIQUE INDEX IF NOT EXISTS receiver_sources_host_un
ON public.receiver_sources_encrypted (host, observer_id, receiver_id)
WHERE connect_id IS NULL;

CREATE UNIQUE INDEX IF NOT EXISTS receiver_sources_connect_un
ON public.receiver_sources_encrypted (connect_id, observer_id, receiver_id)
WHERE connect_id IS not NULL;
----------------------------------------------------------------
-- Представления данных для таблиц, связанных с личным кабинетом
----------------------------------------------------------------

CREATE OR REPLACE VIEW public.cabinet_versions_view AS
SELECT
    s.id,
    s.version,
    'signal_rules' AS type -- noqa: RF04
FROM signal_rules AS s
UNION ALL
SELECT
    s.id,
    s.version,
    'signal_lists' AS type -- noqa: RF04
FROM signal_lists AS s
UNION ALL
SELECT
    s.id,
    s.version,
    'signal_autofill_rules' AS type -- noqa: RF04
FROM signal_autofill_rules AS s
UNION ALL
SELECT
    c.id,
    c.version,
    'connectors' AS type -- noqa: RF04
FROM connectors AS c
UNION ALL
SELECT
    s.id,
    s.version,
    'scripts' AS type -- noqa: RF04
FROM scripts_encrypted AS s
UNION ALL
SELECT
    d.id,
    d.version,
    'dashboards' AS type -- noqa: RF04
FROM dashboards AS d;
-----------------------------------
-- Представления для конфигурация платформы
-----------------------------------


--- представление для доступа к данным
CREATE OR REPLACE VIEW configs AS
SELECT
    name,
    decrypt(config)::json AS config,
    type
FROM configs_encrypted;

--- функции вставки/обновления с шифрованием
CREATE OR REPLACE FUNCTION configs_insert()
RETURNS trigger AS $$
BEGIN
    INSERT INTO configs_encrypted (name, config, type)
    VALUES (NEW.name, encrypt(NEW.config::text), NEW.type)
    ON CONFLICT (name) DO UPDATE SET
        config = CASE
            WHEN EXCLUDED.config IS NOT NULL THEN EXCLUDED.config ELSE configs_encrypted.config END,
        type = CASE
            WHEN EXCLUDED.type IS NOT NULL THEN EXCLUDED.type ELSE configs_encrypted.type END;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION configs_update()
RETURNS trigger AS $$
BEGIN
    UPDATE configs_encrypted
    SET config = encrypt(NEW.config::text),
        type = NEW.type
    WHERE name = OLD.name;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

--- триггеры на операции
CREATE OR REPLACE TRIGGER configs_insert_trigger
INSTEAD OF INSERT ON configs
FOR EACH ROW EXECUTE FUNCTION configs_insert();

CREATE OR REPLACE TRIGGER configs_update_trigger
INSTEAD OF UPDATE ON configs
FOR EACH ROW EXECUTE FUNCTION configs_update();


--- представление для доступа к данным
CREATE OR REPLACE VIEW ldap_servers AS
SELECT
    id,
    decrypt(config)::json AS config,
    domain
FROM ldap_servers_encrypted;

--- функции вставки/обновления с шифрованием
CREATE OR REPLACE FUNCTION ldap_servers_insert()
RETURNS trigger AS $$
BEGIN
    INSERT INTO ldap_servers_encrypted (id, config, domain)
    VALUES (NEW.id, encrypt(NEW.config::text), NEW.domain)
    ON CONFLICT (id) DO UPDATE SET
        config = CASE
            WHEN EXCLUDED.config IS NOT NULL THEN EXCLUDED.config ELSE ldap_servers_encrypted.config END,
        domain = CASE
            WHEN EXCLUDED.domain IS NOT NULL THEN EXCLUDED.domain ELSE ldap_servers_encrypted.domain END;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION ldap_servers_update()
RETURNS trigger AS $$
BEGIN
    UPDATE ldap_servers_encrypted
    SET config = encrypt(NEW.config::text),
        domain = NEW.domain
    WHERE id = OLD.id;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

--- триггеры на операции
CREATE OR REPLACE TRIGGER ldap_servers_insert_trigger
INSTEAD OF INSERT ON ldap_servers
FOR EACH ROW EXECUTE FUNCTION ldap_servers_insert();

CREATE OR REPLACE TRIGGER ldap_servers_update_trigger
INSTEAD OF UPDATE ON ldap_servers
FOR EACH ROW EXECUTE FUNCTION ldap_servers_update();
--------------------------------------------------------------
-- Представления данных для таблиц инвентаризации
--------------------------------------------------------------

CREATE OR REPLACE VIEW public.census_hosts_view
AS SELECT
    ch.id,
    ch.hostname,
    ch.domain,
    ch.dynamic_ip_list,
    ch.zone_match,
    ch.created_at,
    ch.active_at,
    ch.activity_lost,
    ch.created_by,
    rh.id as linked_resource_id,
    rt.id as linked_resource_type,
    rt.name as linked_resource_type_name,
    (ch.id IN (
        SELECT ca.host_id
        FROM census_agent_activity AS ca
        WHERE ca.host_id = ch.id
    )) AS has_agent,
    (
        SELECT max(ca.observed) AS max
        FROM census_agent_activity AS ca
        WHERE ca.host_id = ch.id
        GROUP BY ca.host_id
    ) AS agent_activity,
    array(
        SELECT ca.agent_type
        FROM census_agent_activity AS ca
        WHERE ca.host_id = ch.id
    ) AS modules
FROM census_hosts ch
LEFT JOIN census_res_hosts crh on (ch.id = crh.hid)
LEFT JOIN res_hosts rh on (crh.rhid = rh.id)
LEFT JOIN res_types rt on (rh.type_id = rt.id);


CREATE OR REPLACE VIEW public.contacts_view
AS SELECT contacts.id,
    contacts.name,
    contacts.info,
    contacts.office_phone,
    contacts.mobile_phone,
    contacts.email,
    contacts.textsearchable_index_col,
    contacts.parent_id,
    contacts.created_at,
    ( SELECT parent.name
           FROM contacts AS parent
          WHERE contacts.parent_id = parent.id) AS parent_name,
    ( SELECT count(*) AS count
           FROM contact_deputies
          WHERE contacts.id = contact_deputies.cid) AS deputies_count,
    ( SELECT count(*) AS count
           FROM contact_org_units
          WHERE contacts.id = contact_org_units.cid) AS org_units_count
   FROM contacts;


CREATE OR REPLACE VIEW public.org_units_view
AS
SELECT
    org_units.id,
    org_units.name,
    org_units.info,
    org_units.textsearchable_index_col,
    org_units.parent_id,
    org_units.created_at,
    (
        SELECT parent.name
        FROM org_units AS parent
        WHERE (org_units.parent_id = parent.id)
    ) AS parent_name,
    (
        SELECT count(*) AS count
        FROM org_unit_tags
        WHERE org_unit_tags.ouid = org_units.id
    ) AS tags_count,
    (
        SELECT count(*) AS count
        FROM contact_org_units
        WHERE org_units.id = contact_org_units.ouid) AS contacts_count
FROM org_units;


CREATE OR REPLACE VIEW public.contact_deputies_view
AS
SELECT
    contact_deputies.cid AS contact_id,
    contacts_view.id,
    contacts_view.name,
    contacts_view.info,
    contacts_view.office_phone,
    contacts_view.mobile_phone,
    contacts_view.email,
    contacts_view.textsearchable_index_col,
    contacts_view.parent_id,
    contacts_view.parent_name
FROM contact_deputies
INNER JOIN contacts_view ON (contact_deputies.did = contacts_view.id);


CREATE OR REPLACE VIEW public.contact_org_units_view
AS
SELECT
    contact_org_units.cid AS contact_id,
    contact_org_units.job_title AS contact_role,
    org_units_view.id,
    org_units_view.name,
    org_units_view.info,
    org_units_view.textsearchable_index_col,
    org_units_view.parent_id,
    org_units_view.parent_name
FROM contact_org_units
INNER JOIN org_units_view ON (contact_org_units.ouid = org_units_view.id);


CREATE OR REPLACE VIEW public.org_unit_contacts_view
AS
SELECT
    contact_org_units.ouid,
    contact_org_units.job_title AS contact_role,
    contacts_view.id,
    contacts_view.name,
    contacts_view.info,
    contacts_view.email,
    contacts_view.office_phone,
    contacts_view.mobile_phone,
    contacts_view.textsearchable_index_col,
    contacts_view.parent_id,
    contacts_view.parent_name
FROM contact_org_units
INNER JOIN contacts_view ON (contact_org_units.cid = contacts_view.id);

-- представление со всеми типами ресурсов, с общими полями
CREATE OR REPLACE VIEW public.resources_view
AS SELECT r.id,
    r.name,
    r.description,
    r.type_id,
    r.author,
    r.created,
    r.updated,
    ( SELECT rt.name
           FROM res_types rt
          WHERE r.type_id = rt.id) AS type_name,
    ( SELECT array_to_string(ARRAY( SELECT t.name
                   FROM ( SELECT rtg.rid,
                            tags.name
                           FROM res_hosts_tags rtg
                             JOIN tags ON rtg.tid::text = tags.name::text) t
                  WHERE t.rid = r.id), ','::text) AS array_to_string) AS tags,
    ( SELECT max(t.priority) AS max
           FROM ( SELECT rtg.rid,
                    tags.priority
                   FROM res_hosts_tags rtg
                     JOIN tags ON rtg.tid::text = tags.name::text) t
          WHERE t.rid = r.id) AS priority,
    ( SELECT count(*) AS count
           FROM scaner_detection
          WHERE scaner_detection.id_res_host = r.id) AS vulnes_count,
    ( SELECT count(*) AS count
           FROM res_hosts_tags
          WHERE res_hosts_tags.rid = r.id) AS tags_count,
    ( SELECT count(*) AS count
           FROM res_hosts_contacts
          WHERE res_hosts_contacts.rid = r.id) AS contacts_count,
    ( SELECT count(*) AS count
           FROM res_hosts_locations
          WHERE res_hosts_locations.rid = r.id) AS locations_count,
    ( SELECT count(*) AS count
           FROM res_hosts_org_units
          WHERE res_hosts_org_units.rid = r.id) AS org_units_count,
    ( SELECT count(*) AS count
           FROM ws_targets_hosts
          WHERE ws_targets_hosts.rid = r.id) AS ws_count,
    ( SELECT count(*) AS count
           FROM res_hosts_accounts
          WHERE res_hosts_accounts.rid = r.id) AS accounts_count,
    ( SELECT json_agg(ro) AS os
		FROM res_os ro
		JOIN res_hosts_os rho ON ro.id = rho.osid
		WHERE rho.rid = r.id) AS os,
	( SELECT json_agg(rh) AS os
		FROM res_software rh
		JOIN res_hosts_software rhs ON rh.id = rhs.sfid
		WHERE rhs.rid = r.id) AS software,
	( SELECT json_agg(rh) AS os
		FROM res_hardware rh
		JOIN res_hosts_hardware rhh ON rh.id = rhh.hfid
		WHERE rhh.rid = r.id) AS hardware
   FROM res_hosts r
UNION ALL
 SELECT r.id,
    r.name,
    r.description,
    r.type_id,
    r.author,
    r.created,
    r.updated,
    ( SELECT rt.name
           FROM res_types rt
          WHERE r.type_id = rt.id) AS type_name,
    ( SELECT array_to_string(ARRAY( SELECT t.name
                   FROM ( SELECT rtg.rid,
                            tags.name
                           FROM res_accounts_tags rtg
                             JOIN tags ON rtg.tid::text = tags.name::text) t
                  WHERE t.rid = r.id), ','::text) AS array_to_string) AS tags,
    ( SELECT max(t.priority) AS max
           FROM ( SELECT rtg.rid,
                    tags.priority
                   FROM res_accounts_tags rtg
                     JOIN tags ON rtg.tid::text = tags.name::text) t
          WHERE t.rid = r.id) AS priority,
    0 AS vulnes_count,
    ( SELECT count(*) AS count
           FROM res_accounts_tags
          WHERE res_accounts_tags.rid = r.id) AS tags_count,
    ( SELECT count(*) AS count
           FROM res_accounts_contacts
          WHERE res_accounts_contacts.rid = r.id) AS contacts_count,
    ( SELECT count(*) AS count
           FROM res_accounts_locations
          WHERE res_accounts_locations.rid = r.id) AS locations_count,
    ( SELECT count(*) AS count
           FROM res_accounts_org_units
          WHERE res_accounts_org_units.rid = r.id) AS org_units_count,
    ( SELECT count(*) AS count
           FROM ws_targets_accounts
          WHERE ws_targets_accounts.rid = r.id) AS ws_count,
    0 AS accounts_count,
    '[]'::json AS os,
    '[]'::json AS software,
    '[]'::json AS hardware
   FROM res_accounts r
UNION ALL
 SELECT r.id,
    r.name,
    r.description,
    r.type_id,
    r.author,
    r.created,
    r.updated,
    ( SELECT rt.name
           FROM res_types rt
          WHERE r.type_id = rt.id) AS type_name,
    ( SELECT array_to_string(ARRAY( SELECT t.name
                   FROM ( SELECT rtg.rid,
                            tags.name
                           FROM res_devices_tags rtg
                             JOIN tags ON rtg.tid::text = tags.name::text) t
                  WHERE t.rid = r.id), ','::text) AS array_to_string) AS tags,
    ( SELECT max(t.priority) AS max
           FROM ( SELECT rtg.rid,
                    tags.priority
                   FROM res_devices_tags rtg
                     JOIN tags ON rtg.tid::text = tags.name::text) t
          WHERE t.rid = r.id) AS priority,
    0 AS vulnes_count,
    ( SELECT count(*) AS count
           FROM res_devices_tags
          WHERE res_devices_tags.rid = r.id) AS tags_count,
    ( SELECT count(*) AS count
           FROM res_devices_contacts
          WHERE res_devices_contacts.rid = r.id) AS contacts_count,
    ( SELECT count(*) AS count
           FROM res_devices_locations
          WHERE res_devices_locations.rid = r.id) AS locations_count,
    ( SELECT count(*) AS count
           FROM res_devices_org_units
          WHERE res_devices_org_units.rid = r.id) AS org_units_count,
    0 AS ws_count,
    ( SELECT count(*) AS count
           FROM res_devices_accounts
          WHERE res_devices_accounts.rid = r.id) AS accounts_count,
    ( SELECT json_agg(ro) AS os
		FROM res_os ro
		JOIN res_devices_os rho ON ro.id = rho.osid
		WHERE rho.rid = r.id) AS os,
    '[]'::json AS software,
    '[]'::json AS hardware
   FROM res_devices r
UNION ALL
 SELECT r.id,
    r.name,
    r.description,
    r.type_id,
    r.author,
    r.created,
    r.updated,
    ( SELECT rt.name
           FROM res_types rt
          WHERE r.type_id = rt.id) AS type_name,
    ( SELECT array_to_string(ARRAY( SELECT t.name
                   FROM ( SELECT rtg.rid,
                            tags.name
                           FROM res_services_tags rtg
                             JOIN tags ON rtg.tid::text = tags.name::text) t
                  WHERE t.rid = r.id), ','::text) AS array_to_string) AS tags,
    ( SELECT max(t.priority) AS max
           FROM ( SELECT rtg.rid,
                    tags.priority
                   FROM res_services_tags rtg
                     JOIN tags ON rtg.tid::text = tags.name::text) t
          WHERE t.rid = r.id) AS priority,
    0 AS vulnes_count,
    ( SELECT count(*) AS count
           FROM res_services_tags
          WHERE res_services_tags.rid = r.id) AS tags_count,
    ( SELECT count(*) AS count
           FROM res_services_contacts
          WHERE res_services_contacts.rid = r.id) AS contacts_count,
    ( SELECT count(*) AS count
           FROM res_services_locations
          WHERE res_services_locations.rid = r.id) AS locations_count,
    ( SELECT count(*) AS count
           FROM res_services_org_units
          WHERE res_services_org_units.rid = r.id) AS org_units_count,
    0 AS ws_count,
    ( SELECT count(*) AS count
           FROM res_services_accounts
          WHERE res_services_accounts.rid = r.id) AS accounts_count,
    '[]'::json AS os,
    '[]'::json AS software,
    '[]'::json AS hardware
   FROM res_services r
UNION ALL
 SELECT r.id,
    r.name,
    r.description,
    r.type_id,
    r.author,
    r.created,
    r.updated,
    ( SELECT rt.name
           FROM res_types rt
          WHERE r.type_id = rt.id) AS type_name,
    ( SELECT array_to_string(ARRAY( SELECT t.name
                   FROM ( SELECT rtg.rid,
                            tags.name
                           FROM res_iss_tags rtg
                             JOIN tags ON rtg.tid::text = tags.name::text) t
                  WHERE t.rid = r.id), ','::text) AS array_to_string) AS tags,
    ( SELECT max(t.priority) AS max
           FROM ( SELECT rtg.rid,
                    tags.priority
                   FROM res_iss_tags rtg
                     JOIN tags ON rtg.tid::text = tags.name::text) t
          WHERE t.rid = r.id) AS priority,
    0 AS vulnes_count,
    ( SELECT count(*) AS count
           FROM res_iss_tags
          WHERE res_iss_tags.rid = r.id) AS tags_count,
    ( SELECT count(*) AS count
           FROM res_iss_contacts
          WHERE res_iss_contacts.rid = r.id) AS contacts_count,
    ( SELECT count(*) AS count
           FROM res_iss_locations
          WHERE res_iss_locations.rid = r.id) AS locations_count,
    ( SELECT count(*) AS count
           FROM res_iss_org_units
          WHERE res_iss_org_units.rid = r.id) AS org_units_count,
    ( SELECT count(*) AS count
           FROM ws_targets_iss
          WHERE ws_targets_iss.rid = r.id) AS ws_count,
    ( SELECT count(*) AS count
           FROM res_iss_accounts
          WHERE res_iss_accounts.rid = r.id) AS accounts_count,
    '[]'::json AS os,
    '[]'::json AS software,
    '[]'::json AS hardware
   FROM res_iss r
UNION ALL
 SELECT r.id,
    r.name,
    r.description,
    r.type_id,
    r.author,
    r.created,
    r.updated,
    ( SELECT rt.name
           FROM res_types rt
          WHERE r.type_id = rt.id) AS type_name,
    ( SELECT array_to_string(ARRAY( SELECT t.name
                   FROM ( SELECT rtg.rid,
                            tags.name
                           FROM res_equipment_tags rtg
                             JOIN tags ON rtg.tid::text = tags.name::text) t
                  WHERE t.rid = r.id), ','::text) AS array_to_string) AS tags,
    ( SELECT max(t.priority) AS max
           FROM ( SELECT rtg.rid,
                    tags.priority
                   FROM res_equipment_tags rtg
                     JOIN tags ON rtg.tid::text = tags.name::text) t
          WHERE t.rid = r.id) AS priority,
    0 AS vulnes_count,
    ( SELECT count(*) AS count
           FROM res_equipment_tags
          WHERE res_equipment_tags.rid = r.id) AS tags_count,
    ( SELECT count(*) AS count
           FROM res_equipment_contacts
          WHERE res_equipment_contacts.rid = r.id) AS contacts_count,
    ( SELECT count(*) AS count
           FROM res_equipment_locations
          WHERE res_equipment_locations.rid = r.id) AS locations_count,
    ( SELECT count(*) AS count
           FROM res_equipment_org_units
          WHERE res_equipment_org_units.rid = r.id) AS org_units_count,
    0 AS ws_count,
    ( SELECT count(*) AS count
           FROM res_equipment_accounts
          WHERE res_equipment_accounts.rid = r.id) AS accounts_count,
    '[]'::json AS os,
    '[]'::json AS software,
    '[]'::json AS hardware
   FROM res_equipment r;

-- все связи контактов и ресурсов
CREATE OR REPLACE VIEW public.res_contacts_view
AS
SELECT
    rc.rid,
    rc.cid,
    rc.relation AS contact_role,
    cv.name AS c_name,
    cv.info AS c_info,
    cv.email AS c_email,
    cv.office_phone AS c_office_phone,
    cv.mobile_phone AS c_modile_phone,
    cv.textsearchable_index_col AS c_textsearchable_index_col,
    cv.parent_id AS c_parent_id,
    cv.parent_name AS c_parent_name,
    cv.created_at AS c_created_at,
    rv.name AS r_name,
    rv.description AS r_description,
    rv.type_id AS r_type_id,
    rv.type_name AS r_type_name,
    rv.author AS r_author,
    rv.created AS r_created,
    rv.updated AS r_updated
FROM res_hosts_contacts AS rc
INNER JOIN contacts_view AS cv ON (rc.cid = cv.id)
INNER JOIN resources_view AS rv ON (rc.rid = rv.id)
UNION ALL
SELECT
    rc.rid,
    rc.cid,
    rc.relation AS contact_role,
    cv.name AS c_name,
    cv.info AS c_info,
    cv.email AS c_email,
    cv.office_phone AS c_office_phone,
    cv.mobile_phone AS c_modile_phone,
    cv.textsearchable_index_col AS c_textsearchable_index_col,
    cv.parent_id AS c_parent_id,
    cv.parent_name AS c_parent_name,
    cv.created_at AS c_created_at,
    rv.name AS r_name,
    rv.description AS r_description,
    rv.type_id AS r_type_id,
    rv.type_name AS r_type_name,
    rv.author AS r_author,
    rv.created AS r_created,
    rv.updated AS r_updated
FROM res_accounts_contacts AS rc
INNER JOIN contacts_view AS cv ON (rc.cid = cv.id)
INNER JOIN resources_view AS rv ON (rc.rid = rv.id)
UNION ALL
SELECT
    rc.rid,
    rc.cid,
    rc.relation AS contact_role,
    cv.name AS c_name,
    cv.info AS c_info,
    cv.email AS c_email,
    cv.office_phone AS c_office_phone,
    cv.mobile_phone AS c_modile_phone,
    cv.textsearchable_index_col AS c_textsearchable_index_col,
    cv.parent_id AS c_parent_id,
    cv.parent_name AS c_parent_name,
    cv.created_at AS c_created_at,
    rv.name AS r_name,
    rv.description AS r_description,
    rv.type_id AS r_type_id,
    rv.type_name AS r_type_name,
    rv.author AS r_author,
    rv.created AS r_created,
    rv.updated AS r_updated
FROM res_devices_contacts AS rc
INNER JOIN contacts_view AS cv ON (rc.cid = cv.id)
INNER JOIN resources_view AS rv ON (rc.rid = rv.id)
UNION ALL
SELECT
    rc.rid,
    rc.cid,
    rc.relation AS contact_role,
    cv.name AS c_name,
    cv.info AS c_info,
    cv.email AS c_email,
    cv.office_phone AS c_office_phone,
    cv.mobile_phone AS c_modile_phone,
    cv.textsearchable_index_col AS c_textsearchable_index_col,
    cv.parent_id AS c_parent_id,
    cv.parent_name AS c_parent_name,
    cv.created_at AS c_created_at,
    rv.name AS r_name,
    rv.description AS r_description,
    rv.type_id AS r_type_id,
    rv.type_name AS r_type_name,
    rv.author AS r_author,
    rv.created AS r_created,
    rv.updated AS r_updated
FROM res_services_contacts AS rc
INNER JOIN contacts_view AS cv ON (rc.cid = cv.id)
INNER JOIN resources_view AS rv ON (rc.rid = rv.id)
UNION ALL
SELECT
    rc.rid,
    rc.cid,
    rc.relation AS contact_role,
    cv.name AS c_name,
    cv.info AS c_info,
    cv.email AS c_email,
    cv.office_phone AS c_office_phone,
    cv.mobile_phone AS c_modile_phone,
    cv.textsearchable_index_col AS c_textsearchable_index_col,
    cv.parent_id AS c_parent_id,
    cv.parent_name AS c_parent_name,
    cv.created_at AS c_created_at,
    rv.name AS r_name,
    rv.description AS r_description,
    rv.type_id AS r_type_id,
    rv.type_name AS r_type_name,
    rv.author AS r_author,
    rv.created AS r_created,
    rv.updated AS r_updated
FROM res_iss_contacts AS rc
INNER JOIN contacts_view AS cv ON (rc.cid = cv.id)
INNER JOIN resources_view AS rv ON (rc.rid = rv.id)
UNION ALL
SELECT
    rc.rid,
    rc.cid,
    rc.relation AS contact_role,
    cv.name AS c_name,
    cv.info AS c_info,
    cv.email AS c_email,
    cv.office_phone AS c_office_phone,
    cv.mobile_phone AS c_modile_phone,
    cv.textsearchable_index_col AS c_textsearchable_index_col,
    cv.parent_id AS c_parent_id,
    cv.parent_name AS c_parent_name,
    cv.created_at AS c_created_at,
    rv.name AS r_name,
    rv.description AS r_description,
    rv.type_id AS r_type_id,
    rv.type_name AS r_type_name,
    rv.author AS r_author,
    rv.created AS r_created,
    rv.updated AS r_updated
FROM res_equipment_contacts AS rc
INNER JOIN contacts_view AS cv ON (rc.cid = cv.id)
INNER JOIN resources_view AS rv ON (rc.rid = rv.id);


-- все связи локаций и ресурсов
CREATE OR REPLACE VIEW public.res_locations_view
AS
SELECT
    rl.rid,
    rl.lid,
    lv.name AS l_name,
    lv.info AS l_info,
    lv.address AS l_address,
    lv.critical AS l_critical,
    lv.internet AS l_internet,
    lv.category AS l_category,
    lv.function AS l_function,
    lv.city AS l_city,
    lv.geo_point::text AS l_geo_point,
    lv.textsearchable_index_col AS l_textsearchable_index_col,
    lv.parent_id AS l_parent_id,
    lv.created_at AS l_created_at,
    rv.name AS r_name,
    rv.description AS r_description,
    rv.type_id AS r_type_id,
    rv.type_name AS r_type_name,
    rv.author AS r_author,
    rv.created AS r_created,
    rv.updated AS r_updated
FROM res_hosts_locations AS rl
INNER JOIN locations AS lv ON (rl.lid = lv.id)
INNER JOIN resources_view AS rv ON (rl.rid = rv.id)
UNION ALL
SELECT
    rl.rid,
    rl.lid,
    lv.name AS l_name,
    lv.info AS l_info,
    lv.address AS l_address,
    lv.critical AS l_critical,
    lv.internet AS l_internet,
    lv.category AS l_category,
    lv.function AS l_function,
    lv.city AS l_city,
    lv.geo_point::text AS l_geo_point,
    lv.textsearchable_index_col AS l_textsearchable_index_col,
    lv.parent_id AS l_parent_id,
    lv.created_at AS l_created_at,
    rv.name AS r_name,
    rv.description AS r_description,
    rv.type_id AS r_type_id,
    rv.type_name AS r_type_name,
    rv.author AS r_author,
    rv.created AS r_created,
    rv.updated AS r_updated
FROM res_accounts_locations AS rl
INNER JOIN locations AS lv ON (rl.lid = lv.id)
INNER JOIN resources_view AS rv ON (rl.rid = rv.id)
UNION ALL
SELECT
    rl.rid,
    rl.lid,
    lv.name AS l_name,
    lv.info AS l_info,
    lv.address AS l_address,
    lv.critical AS l_critical,
    lv.internet AS l_internet,
    lv.category AS l_category,
    lv.function AS l_function,
    lv.city AS l_city,
    lv.geo_point::text AS l_geo_point,
    lv.textsearchable_index_col AS l_textsearchable_index_col,
    lv.parent_id AS l_parent_id,
    lv.created_at AS l_created_at,
    rv.name AS r_name,
    rv.description AS r_description,
    rv.type_id AS r_type_id,
    rv.type_name AS r_type_name,
    rv.author AS r_author,
    rv.created AS r_created,
    rv.updated AS r_updated
FROM res_devices_locations AS rl
INNER JOIN locations AS lv ON (rl.lid = lv.id)
INNER JOIN resources_view AS rv ON (rl.rid = rv.id)
UNION ALL
SELECT
    rl.rid,
    rl.lid,
    lv.name AS l_name,
    lv.info AS l_info,
    lv.address AS l_address,
    lv.critical AS l_critical,
    lv.internet AS l_internet,
    lv.category AS l_category,
    lv.function AS l_function,
    lv.city AS l_city,
    lv.geo_point::text AS l_geo_point,
    lv.textsearchable_index_col AS l_textsearchable_index_col,
    lv.parent_id AS l_parent_id,
    lv.created_at AS l_created_at,
    rv.name AS r_name,
    rv.description AS r_description,
    rv.type_id AS r_type_id,
    rv.type_name AS r_type_name,
    rv.author AS r_author,
    rv.created AS r_created,
    rv.updated AS r_updated
FROM res_services_locations AS rl
INNER JOIN locations AS lv ON (rl.lid = lv.id)
INNER JOIN resources_view AS rv ON (rl.rid = rv.id)
UNION ALL
SELECT
    rl.rid,
    rl.lid,
    lv.name AS l_name,
    lv.info AS l_info,
    lv.address AS l_address,
    lv.critical AS l_critical,
    lv.internet AS l_internet,
    lv.category AS l_category,
    lv.function AS l_function,
    lv.city AS l_city,
    lv.geo_point::text AS l_geo_point,
    lv.textsearchable_index_col AS l_textsearchable_index_col,
    lv.parent_id AS l_parent_id,
    lv.created_at AS l_created_at,
    rv.name AS r_name,
    rv.description AS r_description,
    rv.type_id AS r_type_id,
    rv.type_name AS r_type_name,
    rv.author AS r_author,
    rv.created AS r_created,
    rv.updated AS r_updated
FROM res_iss_locations AS rl
INNER JOIN locations AS lv ON (rl.lid = lv.id)
INNER JOIN resources_view AS rv ON (rl.rid = rv.id)
UNION ALL
SELECT
    rl.rid,
    rl.lid,
    lv.name AS l_name,
    lv.info AS l_info,
    lv.address AS l_address,
    lv.critical AS l_critical,
    lv.internet AS l_internet,
    lv.category AS l_category,
    lv.function AS l_function,
    lv.city AS l_city,
    lv.geo_point::text AS l_geo_point,
    lv.textsearchable_index_col AS l_textsearchable_index_col,
    lv.parent_id AS l_parent_id,
    lv.created_at AS l_created_at,
    rv.name AS r_name,
    rv.description AS r_description,
    rv.type_id AS r_type_id,
    rv.type_name AS r_type_name,
    rv.author AS r_author,
    rv.created AS r_created,
    rv.updated AS r_updated
FROM res_equipment_locations AS rl
INNER JOIN locations AS lv ON (rl.lid = lv.id)
INNER JOIN resources_view AS rv ON (rl.rid = rv.id);


-- представление с локациями
CREATE OR REPLACE VIEW public.locations_view
AS SELECT locations.id,
    locations.name,
    locations.info,
    locations.address,
    locations.critical,
    locations.internet,
    locations.category,
    locations.function,
    regions.name AS region_name,
    regions.geocode AS region_geocode,
    locations.city,
    locations.geo_point,
    locations.textsearchable_index_col,
    locations.parent_id,
    locations.created_at,
    ( SELECT parent.name
           FROM locations parent
          WHERE locations.parent_id = parent.id) AS parent_name,
    ( SELECT count(*) AS count
           FROM res_locations_view rlv
          WHERE rlv.lid = locations.id) AS res_count
   FROM locations
     LEFT JOIN regions ON locations.region = regions.id;

-- все связи подразделений и ресурсов
CREATE OR REPLACE VIEW public.res_org_units_view
AS
SELECT
    ro.rid,
    ro.ouid,
    ov.name AS o_name,
    ov.info AS o_info,
    ov.textsearchable_index_col AS o_textsearchable_index_col,
    ov.parent_id AS o_parent_id,
    ov.parent_name AS o_parent_name,
    ov.created_at AS o_created_at,
    rv.name AS r_name,
    rv.description AS r_description,
    rv.type_id AS r_type_id,
    rv.type_name AS r_type_name,
    rv.author AS r_author,
    rv.created AS r_created,
    rv.updated AS r_updated
FROM res_hosts_org_units AS ro
INNER JOIN org_units_view AS ov ON (ro.ouid = ov.id)
INNER JOIN resources_view AS rv ON (ro.rid = rv.id)
UNION ALL
SELECT
    ro.rid,
    ro.ouid,
    ov.name AS o_name,
    ov.info AS o_info,
    ov.textsearchable_index_col AS o_textsearchable_index_col,
    ov.parent_id AS o_parent_id,
    ov.parent_name AS o_parent_name,
    ov.created_at AS o_created_at,
    rv.name AS r_name,
    rv.description AS r_description,
    rv.type_id AS r_type_id,
    rv.type_name AS r_type_name,
    rv.author AS r_author,
    rv.created AS r_created,
    rv.updated AS r_updated
FROM res_accounts_org_units AS ro
INNER JOIN org_units_view AS ov ON (ro.ouid = ov.id)
INNER JOIN resources_view AS rv ON (ro.rid = rv.id)
UNION ALL
SELECT
    ro.rid,
    ro.ouid,
    ov.name AS o_name,
    ov.info AS o_info,
    ov.textsearchable_index_col AS o_textsearchable_index_col,
    ov.parent_id AS o_parent_id,
    ov.parent_name AS o_parent_name,
    ov.created_at AS o_created_at,
    rv.name AS r_name,
    rv.description AS r_description,
    rv.type_id AS r_type_id,
    rv.type_name AS r_type_name,
    rv.author AS r_author,
    rv.created AS r_created,
    rv.updated AS r_updated
FROM res_devices_org_units AS ro
INNER JOIN org_units_view AS ov ON (ro.ouid = ov.id)
INNER JOIN resources_view AS rv ON (ro.rid = rv.id)
UNION ALL
SELECT
    ro.rid,
    ro.ouid,
    ov.name AS o_name,
    ov.info AS o_info,
    ov.textsearchable_index_col AS o_textsearchable_index_col,
    ov.parent_id AS o_parent_id,
    ov.parent_name AS o_parent_name,
    ov.created_at AS o_created_at,
    rv.name AS r_name,
    rv.description AS r_description,
    rv.type_id AS r_type_id,
    rv.type_name AS r_type_name,
    rv.author AS r_author,
    rv.created AS r_created,
    rv.updated AS r_updated
FROM res_services_org_units AS ro
INNER JOIN org_units_view AS ov ON (ro.ouid = ov.id)
INNER JOIN resources_view AS rv ON (ro.rid = rv.id)
UNION ALL
SELECT
    ro.rid,
    ro.ouid,
    ov.name AS o_name,
    ov.info AS o_info,
    ov.textsearchable_index_col AS o_textsearchable_index_col,
    ov.parent_id AS o_parent_id,
    ov.parent_name AS o_parent_name,
    ov.created_at AS o_created_at,
    rv.name AS r_name,
    rv.description AS r_description,
    rv.type_id AS r_type_id,
    rv.type_name AS r_type_name,
    rv.author AS r_author,
    rv.created AS r_created,
    rv.updated AS r_updated
FROM res_iss_org_units AS ro
INNER JOIN org_units_view AS ov ON (ro.ouid = ov.id)
INNER JOIN resources_view AS rv ON (ro.rid = rv.id)
UNION ALL
SELECT
    ro.rid,
    ro.ouid,
    ov.name AS o_name,
    ov.info AS o_info,
    ov.textsearchable_index_col AS o_textsearchable_index_col,
    ov.parent_id AS o_parent_id,
    ov.parent_name AS o_parent_name,
    ov.created_at AS o_created_at,
    rv.name AS r_name,
    rv.description AS r_description,
    rv.type_id AS r_type_id,
    rv.type_name AS r_type_name,
    rv.author AS r_author,
    rv.created AS r_created,
    rv.updated AS r_updated
FROM res_equipment_org_units AS ro
INNER JOIN org_units_view AS ov ON (ro.ouid = ov.id)
INNER JOIN resources_view AS rv ON (ro.rid = rv.id);

-- все связи тегов и ресурсов
CREATE OR REPLACE VIEW public.res_tags_view
AS
SELECT
    rt.rid,
    rt.tid,
    t.name AS t_name,
    t.info AS t_info,
    t.priority AS t_priority,
    t.textsearchable_index_col AS t_textsearchable_index_col,
    t.created_at AS t_created_at,
    rv.name AS r_name,
    rv.description AS r_description,
    rv.type_id AS r_type_id,
    rv.type_name AS r_type_name,
    rv.author AS r_author,
    rv.created AS r_created,
    rv.updated AS r_updated
FROM res_hosts_tags AS rt
INNER JOIN tags AS t ON ((rt.tid)::text = (t.name)::text)
INNER JOIN resources_view AS rv ON (rt.rid = rv.id)
UNION ALL
SELECT
    rt.rid,
    rt.tid,
    t.name AS t_name,
    t.info AS t_info,
    t.priority AS t_priority,
    t.textsearchable_index_col AS t_textsearchable_index_col,
    t.created_at AS t_created_at,
    rv.name AS r_name,
    rv.description AS r_description,
    rv.type_id AS r_type_id,
    rv.type_name AS r_type_name,
    rv.author AS r_author,
    rv.created AS r_created,
    rv.updated AS r_updated
FROM res_accounts_tags AS rt
INNER JOIN tags AS t ON ((rt.tid)::text = (t.name)::text)
INNER JOIN resources_view AS rv ON (rt.rid = rv.id)
UNION ALL
SELECT
    rt.rid,
    rt.tid,
    t.name AS t_name,
    t.info AS t_info,
    t.priority AS t_priority,
    t.textsearchable_index_col AS t_textsearchable_index_col,
    t.created_at AS t_created_at,
    rv.name AS r_name,
    rv.description AS r_description,
    rv.type_id AS r_type_id,
    rv.type_name AS r_type_name,
    rv.author AS r_author,
    rv.created AS r_created,
    rv.updated AS r_updated
FROM res_devices_tags AS rt
INNER JOIN tags AS t ON ((rt.tid)::text = (t.name)::text)
INNER JOIN resources_view AS rv ON (rt.rid = rv.id)
UNION ALL
SELECT
    rt.rid,
    rt.tid,
    t.name AS t_name,
    t.info AS t_info,
    t.priority AS t_priority,
    t.textsearchable_index_col AS t_textsearchable_index_col,
    t.created_at AS t_created_at,
    rv.name AS r_name,
    rv.description AS r_description,
    rv.type_id AS r_type_id,
    rv.type_name AS r_type_name,
    rv.author AS r_author,
    rv.created AS r_created,
    rv.updated AS r_updated
FROM res_services_tags AS rt
INNER JOIN tags AS t ON ((rt.tid)::text = (t.name)::text)
INNER JOIN resources_view AS rv ON (rt.rid = rv.id)
UNION ALL
SELECT
    rt.rid,
    rt.tid,
    t.name AS t_name,
    t.info AS t_info,
    t.priority AS t_priority,
    t.textsearchable_index_col AS t_textsearchable_index_col,
    t.created_at AS t_created_at,
    rv.name AS r_name,
    rv.description AS r_description,
    rv.type_id AS r_type_id,
    rv.type_name AS r_type_name,
    rv.author AS r_author,
    rv.created AS r_created,
    rv.updated AS r_updated
FROM res_iss_tags AS rt
INNER JOIN tags AS t ON ((rt.tid)::text = (t.name)::text)
INNER JOIN resources_view AS rv ON (rt.rid = rv.id)
UNION ALL
SELECT
    rt.rid,
    rt.tid,
    t.name AS t_name,
    t.info AS t_info,
    t.priority AS t_priority,
    t.textsearchable_index_col AS t_textsearchable_index_col,
    t.created_at AS t_created_at,
    rv.name AS r_name,
    rv.description AS r_description,
    rv.type_id AS r_type_id,
    rv.type_name AS r_type_name,
    rv.author AS r_author,
    rv.created AS r_created,
    rv.updated AS r_updated
FROM res_equipment_tags AS rt
INNER JOIN tags AS t ON ((rt.tid)::text = (t.name)::text)
INNER JOIN resources_view AS rv ON (rt.rid = rv.id);

-- представление для тегов
CREATE OR REPLACE VIEW public.tags_view
AS SELECT tags.name,
    tags.info,
    tags.priority,
    tags.created_at,
    tags.textsearchable_index_col,
    ( SELECT count(*) AS count
           FROM res_tags_view rtv
          WHERE rtv.tid::text = tags.name::text) AS res_count
   FROM tags;

-- все связи подразделений и ресурсов
CREATE OR REPLACE VIEW public.res_accounts_view
AS
SELECT
    ra.rid,
    ra.raid,
    rv1.name AS ra_name,
    rv1.description AS ra_description,
    rv1.type_id AS ra_type_id,
    rv1.type_name AS ra_type_name,
    rv1.author AS ra_author,
    rv1.created AS ra_created,
    rv1.updated AS ra_updated,
    rv2.name AS r_name,
    rv2.description AS r_description,
    rv2.type_id AS r_type_id,
    rv2.type_name AS r_type_name,
    rv2.author AS r_author,
    rv2.created AS r_created,
    rv2.updated AS r_updated
FROM res_hosts_accounts AS ra
INNER JOIN resources_view AS rv1 ON (ra.raid = rv1.id)
INNER JOIN resources_view AS rv2 ON (ra.rid = rv2.id)
UNION ALL
SELECT
    ra.rid,
    ra.raid,
    rv1.name AS ra_name,
    rv1.description AS ra_description,
    rv1.type_id AS ra_type_id,
    rv1.type_name AS ra_type_name,
    rv1.author AS ra_author,
    rv1.created AS ra_created,
    rv1.updated AS ra_updated,
    rv2.name AS r_name,
    rv2.description AS r_description,
    rv2.type_id AS r_type_id,
    rv2.type_name AS r_type_name,
    rv2.author AS r_author,
    rv2.created AS r_created,
    rv2.updated AS r_updated
FROM res_devices_accounts AS ra
INNER JOIN resources_view AS rv1 ON (ra.raid = rv1.id)
INNER JOIN resources_view AS rv2 ON (ra.rid = rv2.id)
UNION ALL
SELECT
    ra.rid,
    ra.raid,
    rv1.name AS ra_name,
    rv1.description AS ra_description,
    rv1.type_id AS ra_type_id,
    rv1.type_name AS ra_type_name,
    rv1.author AS ra_author,
    rv1.created AS ra_created,
    rv1.updated AS ra_updated,
    rv2.name AS r_name,
    rv2.description AS r_description,
    rv2.type_id AS r_type_id,
    rv2.type_name AS r_type_name,
    rv2.author AS r_author,
    rv2.created AS r_created,
    rv2.updated AS r_updated
FROM res_services_accounts AS ra
INNER JOIN resources_view AS rv1 ON (ra.raid = rv1.id)
INNER JOIN resources_view AS rv2 ON (ra.rid = rv2.id)
UNION ALL
SELECT
    ra.rid,
    ra.raid,
    rv1.name AS ra_name,
    rv1.description AS ra_description,
    rv1.type_id AS ra_type_id,
    rv1.type_name AS ra_type_name,
    rv1.author AS ra_author,
    rv1.created AS ra_created,
    rv1.updated AS ra_updated,
    rv2.name AS r_name,
    rv2.description AS r_description,
    rv2.type_id AS r_type_id,
    rv2.type_name AS r_type_name,
    rv2.author AS r_author,
    rv2.created AS r_created,
    rv2.updated AS r_updated
FROM res_iss_accounts AS ra
INNER JOIN resources_view AS rv1 ON (ra.raid = rv1.id)
INNER JOIN resources_view AS rv2 ON (ra.rid = rv2.id)
UNION ALL
SELECT
    ra.rid,
    ra.raid,
    rv1.name AS ra_name,
    rv1.description AS ra_description,
    rv1.type_id AS ra_type_id,
    rv1.type_name AS ra_type_name,
    rv1.author AS ra_author,
    rv1.created AS ra_created,
    rv1.updated AS ra_updated,
    rv2.name AS r_name,
    rv2.description AS r_description,
    rv2.type_id AS r_type_id,
    rv2.type_name AS r_type_name,
    rv2.author AS r_author,
    rv2.created AS r_created,
    rv2.updated AS r_updated
FROM res_equipment_accounts AS ra
INNER JOIN resources_view AS rv1 ON (ra.raid = rv1.id)
INNER JOIN resources_view AS rv2 ON (ra.rid = rv2.id);


CREATE OR REPLACE VIEW public.org_unit_tags_view
AS
SELECT
    org_unit_tags.ouid,
    tags.name,
    tags.info,
    tags.priority,
    tags.textsearchable_index_col
FROM org_unit_tags
INNER JOIN tags ON ((org_unit_tags.tid)::text = (tags.name)::text);


CREATE OR REPLACE VIEW public.ip_tags_view
AS
SELECT
    ip,
    array_agg(tid) AS tags
FROM (
    SELECT
        t.ip,
        res_hosts_tags.tid
    FROM (
        SELECT
            id,
            unnest(fixed_ips) AS ip
        FROM res_hosts
    ) AS t
    INNER JOIN res_hosts_tags ON t.id = res_hosts_tags.rid
) AS joined_data
GROUP BY ip
UNION ALL
SELECT
    ip,
    array_agg(tid) AS tags
FROM (
    SELECT
        t.ip,
        res_devices_tags.tid
    FROM (
        SELECT
            id,
            unnest(fixed_ips) AS ip
        FROM res_devices
    ) AS t
    INNER JOIN res_devices_tags ON t.id = res_devices_tags.rid
) AS joined_data
GROUP BY ip
UNION ALL
SELECT
    ip,
    array_agg(tid) AS tags
FROM (
    SELECT
        t.ip,
        res_iss_tags.tid
    FROM (
        SELECT
            id,
            unnest(fixed_ips) AS ip
        FROM res_iss
    ) AS t
    INNER JOIN res_iss_tags ON t.id = res_iss_tags.rid
) AS joined_data
GROUP BY ip
UNION ALL
SELECT
    ip,
    array_agg(tid) AS tags
FROM (
    SELECT
        t.ip,
        res_equipment_tags.tid
    FROM (
        SELECT
            id,
            unnest(fixed_ips) AS ip
        FROM res_equipment
    ) AS t
    INNER JOIN res_equipment_tags ON t.id = res_equipment_tags.rid
) AS joined_data
GROUP BY ip;


CREATE OR REPLACE VIEW public.domain_tags_view
AS
SELECT
    domain,
    array_agg(tid) AS tags
FROM (
    SELECT
        t.domain,
        res_hosts_tags.tid
    FROM (
        SELECT
            id,
            unnest(ARRAY[domain] || ARRAY[fqdn] || fqdn_list) AS domain  -- noqa: disable=RF04
        FROM res_hosts
    ) AS t
    INNER JOIN res_hosts_tags ON t.id = res_hosts_tags.rid
) AS joined_data
GROUP BY domain
UNION ALL
SELECT
    domain,
    array_agg(tid) AS tags
FROM (
    SELECT
        t.domain,
        res_accounts_tags.tid
    FROM (
        SELECT
            id,
            unnest(ARRAY[domain]) AS domain  -- noqa: disable=RF04
        FROM res_accounts
    ) AS t
    INNER JOIN res_accounts_tags ON t.id = res_accounts_tags.rid
) AS joined_data
GROUP BY domain
UNION ALL
SELECT
    domain,
    array_agg(tid) AS tags
FROM (
    SELECT
        t.domain,
        res_devices_tags.tid
    FROM (
        SELECT
            id,
            unnest(ARRAY[domain] || ARRAY[fqdn]) AS domain  -- noqa: disable=RF04
        FROM res_devices
    ) AS t
    INNER JOIN res_devices_tags ON t.id = res_devices_tags.rid
) AS joined_data
GROUP BY domain
UNION ALL
SELECT
    domain,
    array_agg(tid) AS tags
FROM (
    SELECT
        t.domain,
        res_iss_tags.tid
    FROM (
        SELECT
            id,
            unnest(ARRAY[domain] || ARRAY[fqdn]) AS domain  -- noqa: disable=RF04
        FROM res_iss
    ) AS t
    INNER JOIN res_iss_tags ON t.id = res_iss_tags.rid
) AS joined_data
GROUP BY domain
UNION ALL
SELECT
    domain,
    array_agg(tid) AS tags
FROM (
    SELECT
        t.domain,
        res_equipment_tags.tid
    FROM (
        SELECT
            id,
            unnest(ARRAY[domain] || ARRAY[fqdn]) AS domain  -- noqa: disable=RF04
        FROM res_equipment
    ) AS t
    INNER JOIN res_equipment_tags ON t.id = res_equipment_tags.rid
) AS joined_data
GROUP BY domain
UNION ALL
SELECT
    domain,
    array_agg(tid) AS tags
FROM (
    SELECT
        t.domain,
        res_services_tags.tid
    FROM (
        SELECT
            id,
            unnest(ARRAY[domain] || ARRAY[fqdn]) AS domain  -- noqa: disable=RF04
        FROM res_services
    ) AS t
    INNER JOIN res_services_tags ON t.id = res_services_tags.rid
) AS joined_data
GROUP BY domain;


CREATE OR REPLACE VIEW public.username_tags_view
AS
SELECT
    username,
    array_agg(tid) AS tags
FROM (
    SELECT
        t.username,
        res_accounts_tags.tid
    FROM (
        SELECT
            id,
            username
        FROM res_accounts
        WHERE username IS NOT NULL
    ) AS t
    INNER JOIN res_accounts_tags ON t.id = res_accounts_tags.rid
) AS joined_data
GROUP BY username;


CREATE OR REPLACE VIEW public.org_unit_username_tags_view
AS
WITH RECURSIVE rec_t AS (
    SELECT
        ouid,
        tid
    FROM org_unit_tags
    UNION ALL
    SELECT
        join_t.id,
        rec_t.tid
    FROM org_units AS join_t
    INNER JOIN rec_t ON join_t.parent_id = rec_t.ouid
)

SELECT
    ra.username,
    array_agg(DISTINCT rec_t.tid) AS tags
FROM rec_t
INNER JOIN res_accounts_org_units AS rou ON rec_t.ouid = rou.ouid
INNER JOIN res_accounts AS ra ON rou.rid = ra.id
GROUP BY ra.username;


CREATE OR REPLACE VIEW public.email_tags_view
AS
SELECT
    email,
    array_agg(tid) AS tags
FROM (
    SELECT
        t.email,
        res_accounts_tags.tid
    FROM (
        SELECT
            id,
            email
        FROM res_accounts
        WHERE email IS NOT NULL
    ) AS t
    INNER JOIN res_accounts_tags ON t.id = res_accounts_tags.rid
) AS joined_data
GROUP BY email;


CREATE OR REPLACE VIEW public.agentless_full_view
AS
WITH filtered_census_hosts AS (
    SELECT * FROM census_hosts_view
    WHERE hostname IS NOT NULL
)

SELECT
    ah.id,
    ah.id_census_host,
    ah.id_res_host,
    ah.id_ldap_record,
    ah.id_exception,
    chv.dynamic_ip_list AS census_ips,
    chv.created_at AS census_create,
    chv.active_at AS census_update,
    chv.modules AS census_modules,
    chv.created_by AS census_create_by,
    rh.type_name AS resource_type,
    rh.fixed_ips AS resource_ips,
    rh.created AS resource_create,
    rh.author AS resource_create_by,
    lr.body AS ldap_body,
    ae.name AS exception_name,
    a.guid AS id_agent,
    a.group AS agent_group,
    a.system AS agent_system,
    a.config AS agent_config,
    a.heartbeat AS agent_heartbeat,
    replace(lower(lr.account_name::text), '$'::text, ''::text) AS ldap_hostname,
    lower(a.name) AS agent_name,
    lower(lr.hostname::text) AS ldap_fqdn,
    lower(rh.name::text) AS resource_hostname,
    lower(rh.domain::text) AS resource_fqdn,
    lower(chv.hostname::text) AS census_hostname
FROM agentless_hosts AS ah
LEFT JOIN filtered_census_hosts AS chv ON ah.id_census_host = chv.id
LEFT JOIN (select rh.*, rt.name as type_name from res_hosts AS rh inner join res_types AS rt on rh.type_id = rt.id) rh ON ah.id_res_host = rh.id   -- noqa
LEFT JOIN ldap_records AS lr ON ah.id_ldap_record::text = lr.id::text
LEFT JOIN agentless_exceptions AS ae ON ah.id_exception = ae.id
LEFT JOIN agents AS a ON ah.id_agent = a.guid;

-- вьюха для ос
CREATE OR REPLACE VIEW public.res_os_view
AS
SELECT
    *,
    (SELECT count(*) FROM res_hosts_os rho WHERE rho.osid = ro.id) AS hosts_count,
    (SELECT count(*) FROM res_devices_os rdo WHERE rdo.osid = ro.id) AS devices_count,
    (SELECT count(*) FROM res_hosts_os rho WHERE rho.osid = ro.id) + 
    (SELECT count(*) FROM res_devices_os rdo WHERE rdo.osid = ro.id) as total
FROM res_os ro;

-- вьюха для связей ос с ресурсами
CREATE OR REPLACE VIEW public.res_os_to_resources_view
AS
SELECT ro.rid,
    ro.osid,
    o.name AS o_name,
    o.type AS o_type,
    o.version AS o_version,
    o.hold AS o_hold,
    o.author AS o_author,
    o.created AS o_created,
    o.updated AS o_updated,
    r.name AS r_name,
    r.description AS r_description,
    r.type_id AS r_type_id,
    r.type_name AS r_type_name,
    r.author AS r_author,
    r.created AS r_created,
    r.updated AS r_updated
   FROM res_hosts_os ro
INNER JOIN res_os o ON ro.osid = o.id
INNER JOIN resources_view r ON ro.rid = r.id
UNION ALL
SELECT ro.rid,
    ro.osid,
    o.name AS o_name,
    o.type AS o_type,
    o.version AS o_version,
    o.hold AS o_hold,
    o.author AS o_author,
    o.created AS o_created,
    o.updated AS o_updated,
    r.name AS r_name,
    r.description AS r_description,
    r.type_id AS r_type_id,
    r.type_name AS r_type_name,
    r.author AS r_author,
    r.created AS r_created,
    r.updated AS r_updated
   FROM res_devices_os ro
INNER JOIN res_os o ON ro.osid = o.id
INNER JOIN resources_view r ON ro.rid = r.id;

-- вьюха для по
CREATE OR REPLACE VIEW public.res_software_view
AS
SELECT
    *,
    (SELECT count(*) FROM res_hosts_software rhs WHERE rhs.sfid = rs.id) AS hosts_count
FROM res_software rs;


-- вьюха для связей по с ресурсами
CREATE OR REPLACE VIEW public.res_software_to_resources_view
AS
SELECT rhs.rid,
    rhs.sfid,
    rs.name AS s_name,
    rs.version AS s_version,
    rs.vendor AS s_hold,
    rs.author AS s_author,
    rs.created AS s_created,
    rs.updated AS s_updated,
    r.name AS r_name,
    r.description AS r_description,
    r.type_id AS r_type_id,
    r.type_name AS r_type_name,
    r.author AS r_author,
    r.created AS r_created,
    r.updated AS r_updated
   FROM res_hosts_software rhs
INNER JOIN res_software rs ON rhs.sfid = rs.id
INNER JOIN resources_view r ON rhs.rid = r.id;

-- вьюха для ао
CREATE OR REPLACE VIEW public.res_hardware_view
AS
SELECT
    *,
    (SELECT count(*) FROM res_hosts_hardware rhh WHERE rhh.hfid = rh.id) AS hosts_count
FROM res_hardware rh;

-- вьюха для связей ао с ресурсами
CREATE OR REPLACE VIEW public.res_hardware_to_resources_view
AS
SELECT rhs.rid,
    rhs.hfid,
    rs.name AS h_name,
    rs.type AS h_type,
    rs.vendor AS h_vendor,
    rs.hwind AS h_hwind,
    rs.virtual AS h_virtual,
    rs.author AS h_author,
    rs.created AS h_created,
    rs.updated AS h_updated,
    r.name AS r_name,
    r.description AS r_description,
    r.type_id AS r_type_id,
    r.type_name AS r_type_name,
    r.author AS r_author,
    r.created AS r_created,
    r.updated AS r_updated
   FROM res_hosts_hardware rhs
INNER JOIN res_hardware rs ON rhs.hfid = rs.id
INNER JOIN resources_view r ON rhs.rid = r.id;
---------------------------------------------------------------
-- Представления данных для таблиц ресиверов, коннекторов и тд
---------------------------------------------------------------


--- представление для доступа к данным
CREATE OR REPLACE VIEW receivers_sources_connects AS
SELECT
    id,
    decrypt(config)::json AS config,
    transport_id
FROM receivers_sources_connects_encrypted;

--- функции вставки/обновления с шифрованием
CREATE OR REPLACE FUNCTION receivers_sources_connects_insert()
RETURNS trigger AS $$
BEGIN
    IF NEW.id IS NOT NULL THEN
    INSERT INTO receivers_sources_connects_encrypted (id, config, transport_id)
        VALUES (NEW.id, encrypt(NEW.config::text), NEW.transport_id)
        ON CONFLICT (id) DO UPDATE SET
            config = CASE
            WHEN EXCLUDED.config IS NOT NULL THEN EXCLUDED.config ELSE receivers_sources_connects_encrypted.config END,
        transport_id = CASE
            WHEN EXCLUDED.transport_id IS NOT NULL THEN EXCLUDED.transport_id ELSE receivers_sources_connects_encrypted.transport_id END;
    RETURN NEW;
    ELSE
    INSERT INTO receivers_sources_connects_encrypted (config, transport_id)
        VALUES (encrypt(NEW.config::text), NEW.transport_id)
        RETURNING id INTO NEW.id;
    RETURN NEW;
    END IF;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION receivers_sources_connects_update()
RETURNS trigger AS $$
BEGIN
    UPDATE receivers_sources_connects_encrypted
    SET config = encrypt(NEW.config::text),
        transport_id = NEW.transport_id
    WHERE id = OLD.id;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

--- триггеры на операции
CREATE OR REPLACE TRIGGER receivers_sources_connects_insert_trigger
INSTEAD OF INSERT ON receivers_sources_connects
FOR EACH ROW EXECUTE FUNCTION receivers_sources_connects_insert();

CREATE OR REPLACE TRIGGER receivers_sources_connects_update_trigger
INSTEAD OF UPDATE ON receivers_sources_connects
FOR EACH ROW EXECUTE FUNCTION receivers_sources_connects_update();


--- представление для доступа к данным
CREATE OR REPLACE VIEW receiver_sources AS
SELECT
    id,
    host,
    decrypt(config)::json AS config,
    receiver_id,
    tags,
    observer_id,
    connect_id
FROM receiver_sources_encrypted;

--- функции вставки/обновления с шифрованием
CREATE OR REPLACE FUNCTION receiver_sources_insert()
RETURNS trigger AS $$
BEGIN
    INSERT INTO receiver_sources_encrypted (id, host, config, receiver_id, tags, observer_id, connect_id)
    VALUES (
        COALESCE(NEW.id, gen_random_uuid()),
        NEW.host,
        CASE WHEN NEW.config IS NOT NULL THEN encrypt(NEW.config::text) ELSE NULL END,
        NEW.receiver_id,
        NEW.tags,
        NEW.observer_id,
        NEW.connect_id
    )
    ON CONFLICT (id) DO UPDATE SET
    host = CASE
        WHEN EXCLUDED.host IS NOT NULL THEN EXCLUDED.host ELSE receiver_sources_encrypted.host END,
    config = CASE
        WHEN EXCLUDED.config IS NOT NULL THEN EXCLUDED.config ELSE receiver_sources_encrypted.config END,
    receiver_id = EXCLUDED.receiver_id,
    tags = CASE
        WHEN EXCLUDED.tags IS NOT NULL THEN EXCLUDED.tags ELSE receiver_sources_encrypted.tags END,
    observer_id = CASE
        WHEN EXCLUDED.observer_id IS NOT NULL THEN EXCLUDED.observer_id ELSE receiver_sources_encrypted.observer_id END,
    connect_id = CASE
        WHEN EXCLUDED.connect_id IS NOT NULL THEN EXCLUDED.connect_id ELSE receiver_sources_encrypted.connect_id END;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION receiver_sources_update()
RETURNS trigger AS $$
BEGIN
    UPDATE receiver_sources_encrypted
    SET config = encrypt(NEW.config::text),
        host = NEW.host,
        receiver_id = NEW.receiver_id,
        tags = NEW.tags,
        observer_id = NEW.observer_id,
        connect_id = NEW.connect_id
    WHERE id = OLD.id;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

--- триггеры на операции
CREATE OR REPLACE TRIGGER receiver_sources_insert_trigger
INSTEAD OF INSERT ON receiver_sources
FOR EACH ROW EXECUTE FUNCTION receiver_sources_insert();

CREATE OR REPLACE TRIGGER receiver_sources_update_trigger
INSTEAD OF UPDATE ON receiver_sources
FOR EACH ROW EXECUTE FUNCTION receiver_sources_update();


CREATE OR REPLACE VIEW public.connectors_full_view
AS SELECT
    c.id,
    c.name,
    c.description,
    c.local,
    c.production,
    c.body,
    c.version,
    c.created,
    c.updated,
    st.id AS observer_id,
    st.name AS observer_name,
    st.namespace AS observer_namespace,
    st.vendor AS observer_vendor,
    st.options AS observer_options,
    sc.id AS observer_type_id,
    sc.name AS observer_type_name,
    sc.class AS observer_type_class,
    uc.id AS creator_id,
    uc.username AS creator_name,
    uc.domain AS creator_domain,
    uu.id AS updater_id,
    uu.username AS updater_name,
    uu.domain AS updater_domain,
    c.vendor,
    CASE
        WHEN uc.username = 'admin' AND uc.domain = 'local' THEN uc.first_name
        ELSE uc.username
    END AS author,
    array(
        SELECT t.id
        FROM transports AS t
        INNER JOIN connector_transports AS ct ON (t.id = ct.transport_id)
        WHERE (c.id = ct.connector_id)
    ) AS transport_id,
    array(
        SELECT t.name
        FROM transports AS t
        INNER JOIN connector_transports AS ct ON (t.id = ct.transport_id)
        WHERE (c.id = ct.connector_id)
    ) AS transports
FROM connectors AS c
LEFT JOIN users AS uc ON (c.author = uc.id)
LEFT JOIN users AS uu ON (c.editor = uu.id)
INNER JOIN observers AS st ON (c.observer_id = st.id)
INNER JOIN observer_types AS sc ON (st.type_id = sc.id);

CREATE OR REPLACE VIEW public.receivers_view
AS SELECT
    r.id,
    r.host,
    r.host_config,
    r.vars,
    r.transport_id,
    t.name AS transport_name
FROM receivers AS r
INNER JOIN transports AS t ON r.transport_id = t.id;


CREATE OR REPLACE VIEW public.receiver_sources_view
AS SELECT
    rs.id,
    rs.host,
    rs.config,
    rs.tags,
    r.id AS receiver_id,
    r.host AS receiver_host,
    r.host_config AS receiver_host_config,
    r.vars AS receiver_vars,
    r.transport_name,
    o.id AS observer_id,
    o.name AS observer_name,
    o.namespace AS observer_namespace,
    o.vendor AS observer_vendor,
    o.options AS observer_options,
    rsc.id AS connect_id,
    rsc.config AS connect_config
FROM receiver_sources AS rs
INNER JOIN receivers_view AS r ON rs.receiver_id = r.id
LEFT JOIN observers AS o ON rs.observer_id = o.id
LEFT JOIN receivers_sources_connects AS rsc ON rs.connect_id = rsc.id;


CREATE OR REPLACE VIEW public.connectors_receivers_view AS
WITH r AS (
    WITH r AS (
        SELECT
            r.id AS receiver_id,
            r.host,
            r.transport_id,
            t.connector_id
        FROM receivers AS r
        INNER JOIN connector_transports AS t ON r.transport_id = t.transport_id
    )

    SELECT
        r.*,
        t.*
    FROM r INNER JOIN transports AS t ON r.transport_id = t.id
    WHERE NOT t.name = any(ARRAY['syslog', 'snmp', 'jdbc', 'kafka', 'custom'])
)

SELECT
    c.id,
    r.id AS receiver_id,
    r.host,
    r.name
FROM connectors AS c INNER JOIN r ON c.id = r.connector_id

UNION

(
    WITH r AS (
        SELECT
            s.id,
            t.host,
            s.receiver_id,
            c.id AS connector_id,
            t.transport_id
        FROM receiver_sources AS s
        INNER JOIN receivers AS t ON s.receiver_id = t.id INNER JOIN connectors AS c ON s.observer_id = c.observer_id
    )

    SELECT
        r.connector_id AS id,
        r.receiver_id,
        r.host,
        c.name
    FROM r INNER JOIN transports AS c ON r.transport_id = c.id
    WHERE c.name = any(ARRAY['syslog', 'snmp', 'jdbc', 'kafka', 'custom']) AND r.connector_id IS NOT NULL
);


CREATE OR REPLACE VIEW public.connectors_receivers_stats_view AS
SELECT
    d.id,
    array_agg(json_build_object('id', d.receiver_id, 'host', d.host, 'name', d.name)) AS receivers
FROM
    connectors_receivers_view
    AS d
GROUP BY d.id;


-- подключения для источников
CREATE OR REPLACE VIEW public.receivers_sources_connects_view
AS SELECT
    c.id,
    c.config,
    t.id AS transport_id,
    t.name AS transport_name,
    (
        SELECT count(*) AS count
        FROM receiver_sources AS rs
        WHERE rs.connect_id = c.id
    ) AS sources_count
FROM receivers_sources_connects AS c INNER JOIN transports AS t ON (c.transport_id = t.id);
----------------------------------------------------------------
-- Представления данных для таблиц, связанных с ролевой моделью
----------------------------------------------------------------

CREATE OR REPLACE FUNCTION has_role_object_access(
    role_name text,
    object_type text,
    content_type text,
    object_name text,
    read_flag boolean DEFAULT true
)
RETURNS boolean AS $$
BEGIN
    RETURN
        role_name = 'Администратор ИБ'
        -- Дашборды
        OR (role_name = 'Аналитик' AND object_type = 'dashboard')
        -- Датасеты
        OR (role_name = 'Аналитик' AND object_type = 'dataset')
        -- Чарты
        OR (role_name = 'Аналитик' AND object_type = 'chart')
        -- Воркспейсы
        OR (role_name = 'Аналитик' AND object_type = 'workspace')
        OR (role_name = 'СОПКА'    AND object_type = 'workspace')
        -- Скрипты
        OR (role_name = 'Аналитик' AND object_type = 'script'
                                   AND content_type != 'grabber'
                                   AND content_type != 'integration')
        OR (role_name = 'Оператор' AND object_type = 'script'
                                   AND content_type != 'data_query')
        -- Коннекторы
        OR (role_name = 'Аналитик' AND object_type = 'connector')
        OR (role_name = 'Оператор' AND object_type = 'connector')
        -- Листы блокнота
        OR (role_name = 'Аналитик' AND object_type = 'notepad_list')
        OR (role_name = 'Оператор' AND object_type = 'notepad_list')
        -- Агенты
        OR (role_name = 'Оператор' AND object_type = 'agent')
        -- Группы агентов
        OR (role_name = 'Оператор' AND object_type = 'agent_group'
            AND (read_flag = true OR (read_flag = false AND object_name != 'default')));
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE VIEW public.objects_list_view AS
SELECT
    d.id,
    d.name,
    d.author AS author_id,
    d.editor,
    d.created,
    d.updated,
    'dashboard' AS type, -- noqa: RF04
    jsonb_strip_nulls(jsonb_build_object(
        'id', u.id,
        'first_name', u.first_name,
        'last_name', u.last_name,
        'username', u.username,
        'domain', u.domain,
        'is_deleted', u.is_deleted
    )) AS author,
    '' AS content_type
FROM dashboards AS d
LEFT JOIN users AS u ON d.author = u.id
UNION ALL
SELECT
    d.id,
    d.name,
    d.author AS author_id,
    d.editor,
    d.created,
    d.updated,
    'dataset' AS type, -- noqa: RF04
    jsonb_strip_nulls(jsonb_build_object(
        'id', u.id,
        'first_name', u.first_name,
        'last_name', u.last_name,
        'username', u.username,
        'domain', u.domain,
        'is_deleted', u.is_deleted
    )) AS author,
    '' AS content_type
FROM datasets AS d
LEFT JOIN users AS u ON d.author = u.id
UNION ALL
SELECT
    c.id,
    c.name,
    c.author AS author_id,
    c.editor,
    c.created,
    c.updated,
    'chart' AS type, -- noqa: RF04
    jsonb_strip_nulls(jsonb_build_object(
        'id', u.id,
        'first_name', u.first_name,
        'last_name', u.last_name,
        'username', u.username,
        'domain', u.domain,
        'is_deleted', u.is_deleted
    )) AS author,
    '' AS content_type
FROM charts AS c
LEFT JOIN users AS u ON c.author = u.id
UNION ALL
SELECT
    t.id,
    t.name,
    t.author AS author_id,
    t.author AS editor,
    t.created,
    t.updated,
    'index_pattern' AS type, -- noqa: RF04
    jsonb_strip_nulls(jsonb_build_object(
        'id', u.id,
        'first_name', u.first_name,
        'last_name', u.last_name,
        'username', u.username,
        'domain', u.domain,
        'is_deleted', u.is_deleted
    )) AS author,
    '' AS content_type
FROM indices_templates AS t
LEFT JOIN users AS u ON t.author = u.id
UNION ALL
SELECT
    w.id,
    w.name,
    w.creator AS author_id,
    w.analyst AS editor,
    w.created_at AS created,
    w.changed_at AS updated,
    'workspace' AS type, -- noqa: RF04
    jsonb_strip_nulls(jsonb_build_object(
        'id', u.id,
        'first_name', u.first_name,
        'last_name', u.last_name,
        'username', u.username,
        'domain', u.domain,
        'is_deleted', u.is_deleted
    )) AS author,
    '' AS content_type
FROM workspaces AS w
LEFT JOIN users AS u ON w.creator = u.id
UNION ALL
SELECT
    s.id,
    s.name,
    s.author AS author_id,
    s.editor,
    s.created,
    s.updated,
    'script' AS type, -- noqa: RF04
    jsonb_strip_nulls(jsonb_build_object(
        'id', u.id,
        'first_name', u.first_name,
        'last_name', u.last_name,
        'username', u.username,
        'domain', u.domain,
        'is_deleted', u.is_deleted
    )) AS author,
    s.type AS content_type
FROM scripts_encrypted AS s
LEFT JOIN users AS u ON s.author = u.id
UNION ALL
SELECT
    c.id,
    c.name,
    c.author AS author_id,
    c.editor,
    c.created,
    c.updated,
    'connector' AS type, -- noqa: RF04
    jsonb_strip_nulls(jsonb_build_object(
        'id', u.id,
        'first_name', u.first_name,
        'last_name', u.last_name,
        'username', u.username,
        'domain', u.domain,
        'is_deleted', u.is_deleted
    )) AS author,
    '' AS content_type
FROM connectors AS c
LEFT JOIN users AS u ON c.author = u.id
UNION ALL
SELECT
    nl.id,
    nl.name,
    nl.author AS author_id,
    nl.author AS editor,
    nl.created,
    nl.edited AS updated,
    'notepad_list' AS type, -- noqa: RF04
    jsonb_strip_nulls(jsonb_build_object(
        'id', u.id,
        'first_name', u.first_name,
        'last_name', u.last_name,
        'username', u.username,
        'domain', u.domain,
        'is_deleted', u.is_deleted
    )) AS author,
    '' AS content_type
FROM notepad_lists AS nl
LEFT JOIN users AS u ON nl.author = u.id
UNION ALL
SELECT
    a.guid,
    a.name,
    get_default_author() AS author_id,
    get_default_author() AS editor,
    a.created,
    a.created AS updated,
    'agent' AS type, -- noqa: RF04
    jsonb_strip_nulls(jsonb_build_object(
        'id', u.id,
        'first_name', u.first_name,
        'last_name', u.last_name,
        'username', u.username,
        'domain', u.domain,
        'is_deleted', u.is_deleted
    )) AS author,
    '' AS content_type
FROM agents AS a
LEFT JOIN users AS u ON get_default_author() = u.id
UNION ALL
SELECT
    ag.id,
    ag.name,
    ag.author AS author_id,
    ag.editor,
    ag.created,
    ag.updated,
    'agent_group' AS type, -- noqa: RF04
    jsonb_strip_nulls(jsonb_build_object(
        'id', u.id,
        'first_name', u.first_name,
        'last_name', u.last_name,
        'username', u.username,
        'domain', u.domain,
        'is_deleted', u.is_deleted
    )) AS author,
    '' AS content_type
FROM "agentGroups" AS ag
LEFT JOIN users AS u ON ag.author = u.id;


CREATE OR REPLACE VIEW public.objects_permission_view AS
SELECT
    u.id,
    u.username,
    u.domain,
    u.first_name,
    u.last_name,
    o.id AS object_id,
    o.type AS object_type,
    o.name AS object_name,
    o.author,
    o.updated,
    bool_or(
        CASE WHEN
            o.author_id = u.id
            OR has_role_object_access(r.name, o.type, o.content_type, o.name, true)
            THEN true
        ELSE coalesce(p.read, false) END
    ) AS read, -- noqa: RF04
    bool_or(
        CASE WHEN
            o.author_id = u.id
            OR has_role_object_access(r.name, o.type, o.content_type, o.name, false)
            THEN true
        ELSE coalesce(p.write, false) END
    ) AS write -- noqa: RF04
FROM users AS u
LEFT OUTER JOIN users_roles AS ur ON u.id = ur.user_id
LEFT OUTER JOIN usergroups_users AS uu ON u.id = uu.user_id
LEFT JOIN usergroups AS ug ON uu.usergroup_id = ug.id
LEFT OUTER JOIN usergroups_roles AS ugr ON ug.id = ugr.usergroup_id
LEFT JOIN roles AS r ON r.id IN (ur.role_id, ugr.role_id)
LEFT OUTER JOIN roles_permissions AS rp ON r.id = rp.role_id
LEFT OUTER JOIN users_permissions AS up ON u.id = up.user_id
LEFT OUTER JOIN usergroups_permissions AS gp ON ug.id = gp.usergroup_id
LEFT OUTER JOIN permissions AS p
    ON p.id IN (
        rp.permission_id,
        up.permission_id,
        gp.permission_id
    )
LEFT OUTER JOIN dashboards_permissions AS dp ON p.id = dp.permission_id
LEFT OUTER JOIN datasets_permissions AS dtp ON p.id = dtp.permission_id
LEFT OUTER JOIN charts_permissions AS cp ON p.id = cp.permission_id
LEFT OUTER JOIN indices_templates_permissions AS tp ON p.id = tp.permission_id
LEFT OUTER JOIN workspaces_permissions AS wp ON p.id = wp.permission_id
LEFT OUTER JOIN scripts_permissions AS sp ON p.id = sp.permission_id
LEFT OUTER JOIN connectors_permissions AS cnp ON p.id = cnp.permission_id
LEFT OUTER JOIN notepad_lists_permissions AS nlp ON p.id = nlp.permission_id
LEFT OUTER JOIN agents_permissions AS ap ON p.id = ap.permission_id
LEFT OUTER JOIN agent_groups_permissions AS agp ON p.id = agp.permission_id
LEFT JOIN objects_list_view AS o
    ON
        has_role_object_access(r.name, o.type, o.content_type, o.name, true)
        OR u.id = o.author_id
        OR o.id IN (
            dp.dashboard_id,
            dtp.dataset_id,
            cp.chart_id,
            tp.template_id,
            wp.workspace_id,
            sp.script_id,
            cnp.connector_id,
            nlp.notepad_list_id,
            ap.agent_id,
            agp.agent_group_id
        )
WHERE u.is_deleted = false AND o.id IS NOT null
GROUP BY u.id, o.id, o.name, o.type, o.updated, o.author;


CREATE OR REPLACE VIEW public.users_profile_view AS
SELECT
    u.id,
    u.username,
    u.first_name,
    u.last_name,
    u.email,
    u.phone,
    u.domain,
    u.ldap,
    u.active,
    coalesce(jsonb_agg(DISTINCT jsonb_build_object(
        'id', opv.object_id,
        'name', opv.object_name,
        'type', opv.object_type,
        'permissions', jsonb_build_object(
            'read', opv.read,
            'write', opv.write
        ),
        'updated', opv.updated,
        'author', opv.author
    )) FILTER (WHERE opv.object_id IS NOT null), '[]') AS objects, -- noqa: RF04
    coalesce(json_agg(DISTINCT jsonb_build_object(
        'id', r.id,
        'name', r.name,
        'is_system', r.is_system
    )) FILTER (WHERE r.id IS NOT null), '[]') AS roles, -- noqa: RF04
    coalesce(json_agg(DISTINCT s.*) FILTER (WHERE s.id IS NOT null), '[]') AS scopes
FROM users AS u
LEFT JOIN objects_permission_view AS opv ON u.id = opv.id
LEFT OUTER JOIN users_roles AS ur ON u.id = ur.user_id
LEFT OUTER JOIN usergroups_users AS uu ON u.id = uu.user_id
LEFT JOIN usergroups AS ug ON uu.usergroup_id = ug.id
LEFT OUTER JOIN usergroups_roles AS ugr ON ug.id = ugr.usergroup_id
LEFT JOIN roles AS r ON r.id IN (ur.role_id, ugr.role_id)
LEFT OUTER JOIN scopes_roles AS sr ON r.id = sr.role_id
LEFT JOIN scopes AS s ON sr.scope_id = s.id
WHERE u.is_deleted = false
GROUP BY u.id;


CREATE OR REPLACE VIEW public.users_view AS
SELECT
    u.id,
    u.username,
    u.first_name,
    u.last_name,
    u.email,
    u.phone,
    u.domain,
    u.ldap,
    u.active,
    u.lock_until,
    u.bad_logons,
    coalesce(json_agg(DISTINCT jsonb_build_object(
        'id', r.id,
        'name', r.name,
        'is_system', r.is_system
    )) FILTER (WHERE r.id IS NOT null), '[]') AS roles, -- noqa: RF04
    coalesce(jsonb_agg(DISTINCT s.*) FILTER (WHERE s.id IS NOT null), '[]') AS scopes
FROM users AS u
LEFT OUTER JOIN users_roles AS ur ON u.id = ur.user_id
LEFT OUTER JOIN usergroups_users AS uu ON u.id = uu.user_id
LEFT JOIN usergroups AS ug ON uu.usergroup_id = ug.id
LEFT OUTER JOIN usergroups_roles AS ugr ON ug.id = ugr.usergroup_id
LEFT JOIN roles AS r ON r.id IN (ur.role_id, ugr.role_id)
LEFT OUTER JOIN scopes_roles AS sr ON r.id = sr.role_id
LEFT JOIN scopes AS s ON sr.scope_id = s.id
WHERE u.is_deleted = false
GROUP BY u.id;


CREATE OR REPLACE VIEW public.roles_objects_view AS
WITH
cte_objects_permissions AS (
    SELECT
        t.dashboard_id AS object_id,
        t.permission_id,
        t.updated
    FROM dashboards_permissions AS t
    UNION ALL
    SELECT
        t.dataset_id AS object_id,
        t.permission_id,
        t.updated
    FROM datasets_permissions AS t
    UNION ALL
    SELECT
        t.chart_id AS object_id,
        t.permission_id,
        t.updated
    FROM charts_permissions AS t
    UNION ALL
    SELECT
        t.template_id AS object_id,
        t.permission_id,
        t.updated
    FROM indices_templates_permissions AS t
    UNION ALL
    SELECT
        t.workspace_id AS object_id,
        t.permission_id,
        t.updated
    FROM workspaces_permissions AS t
    UNION ALL
    SELECT
        t.script_id AS object_id,
        t.permission_id,
        t.updated
    FROM scripts_permissions AS t
    UNION ALL
    SELECT
        t.connector_id AS object_id,
        t.permission_id,
        t.updated
    FROM connectors_permissions AS t
    UNION ALL
    SELECT
        t.notepad_list_id AS object_id,
        t.permission_id,
        t.updated
    FROM notepad_lists_permissions AS t
    UNION ALL
    SELECT
        t.agent_id AS object_id,
        t.permission_id,
        t.updated
    FROM agents_permissions AS t
    UNION ALL
    SELECT
        t.agent_group_id AS object_id,
        t.permission_id,
        t.updated
    FROM agent_groups_permissions AS t
),

cte_roles_scopes AS (
    SELECT
        r.id AS role_id,
        jsonb_agg(s.* ORDER BY s.name) AS scopes  -- noqa: LT14
    FROM roles AS r
    INNER JOIN scopes_roles AS sr ON r.id = sr.role_id
    INNER JOIN scopes AS s ON sr.scope_id = s.id
    GROUP BY r.id
)

SELECT
    r.id,
    r.name,
    r.os_name,
    r.is_system,
    r.workspace_closing,
    coalesce(
        json_agg(
            jsonb_build_object(
                'id', o.id,
                'name', o.name,
                'type', o.type,
                'updated', op.updated,
                'author', o.author,
                'permissions', jsonb_build_object(
                    'id', p.id,
                    'read', true,
                    'write', has_role_object_access(r.name, o.type, o.content_type, o.name, false) OR coalesce(p.write, false),
                    'attrs', p.attrs
                )
            ) ORDER BY o.name  -- noqa: LT14
        ) FILTER (WHERE o.id IS NOT NULL),
        '[]'::json
    ) AS objects,  -- noqa: RF04
    coalesce((
        SELECT rs.scopes FROM cte_roles_scopes AS rs
        WHERE rs.role_id = r.id
    ), '[]'::jsonb) AS scopes
FROM roles AS r
LEFT JOIN roles_permissions AS rp ON r.id = rp.role_id
LEFT JOIN permissions AS p ON rp.permission_id = p.id
LEFT JOIN cte_objects_permissions AS op ON p.id = op.permission_id
LEFT JOIN objects_list_view AS o ON has_role_object_access(r.name, o.type, o.content_type, o.name, true) OR op.object_id = o.id
GROUP BY r.id;
--- представление для доступа к данным
CREATE OR REPLACE VIEW scripts AS
SELECT
    id,
    name,
    description,
    local,
    protect,
    type,
    content,
    entrypoint,
    args,
    decrypt(secrets)::jsonb AS secrets,
    limits,
    host,
    version,
    created,
    updated,
    author,
    editor,
    vendor
FROM scripts_encrypted;

--- функции вставки/обновления с шифрованием
CREATE OR REPLACE FUNCTION scripts_insert()
RETURNS trigger AS $$
BEGIN
  INSERT INTO scripts_encrypted (id, name, description, local, protect, type, content, entrypoint, args, secrets, limits,
                                          host, version, created, updated, author, editor, vendor)
  VALUES (
    COALESCE(NEW.id, gen_random_uuid()),
    NEW.name,
      NEW.description,
      CASE WHEN NEW.local IS NOT NULL THEN NEW.local ELSE true END,
      CASE WHEN NEW.protect IS NOT NULL THEN NEW.protect ELSE false END,
      NEW.type,
      NEW.content,
      NEW.entrypoint,
      NEW.args,
    CASE WHEN NEW.secrets IS NOT NULL THEN encrypt(NEW.secrets::text) ELSE NULL END,
      NEW.limits,
      NEW.host,
      CASE WHEN NEW.version IS NOT NULL THEN NEW.version ELSE 1 END,
      CASE WHEN NEW.created IS NOT NULL THEN NEW.created ELSE (date_part('epoch'::text, now()) * 1000::double precision) END,
      CASE WHEN NEW.updated IS NOT NULL THEN NEW.updated ELSE (date_part('epoch'::text, now()) * 1000::double precision) END,
      CASE WHEN NEW.author IS NOT NULL THEN NEW.author ELSE get_default_author() END,
      NEW.editor,
      NEW.vendor
  )
  ON CONFLICT (id) DO UPDATE SET
    name = EXCLUDED.name,
    description = EXCLUDED.description,
    local = EXCLUDED.local,
    protect = EXCLUDED.protect,
    type = EXCLUDED.type,
    content = EXCLUDED.content,
    entrypoint = EXCLUDED.entrypoint,
    args = CASE WHEN EXCLUDED.args IS NOT NULL THEN EXCLUDED.args ELSE scripts_encrypted.args END,
    secrets = CASE WHEN EXCLUDED.secrets IS NOT NULL THEN EXCLUDED.secrets ELSE scripts_encrypted.secrets END,
    limits = CASE WHEN EXCLUDED.limits IS NOT NULL THEN EXCLUDED.limits ELSE scripts_encrypted.limits END,
    host = EXCLUDED.host,
    version = EXCLUDED.version,
    created = EXCLUDED.created,
    updated = EXCLUDED.updated,
    author = EXCLUDED.author,
  editor = CASE WHEN EXCLUDED.editor IS NOT NULL THEN EXCLUDED.editor ELSE scripts_encrypted.editor END,
  vendor = CASE WHEN EXCLUDED.vendor IS NOT NULL THEN EXCLUDED.vendor ELSE scripts_encrypted.vendor END
  RETURNING id INTO NEW.id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION scripts_update()
RETURNS trigger AS $$
BEGIN
    UPDATE scripts_encrypted
    SET secrets = encrypt(NEW.secrets::text),
        name = CASE WHEN NEW.name IS NOT NULL THEN NEW.name ELSE OLD.name END,
        description = CASE WHEN NEW.description IS NOT NULL THEN NEW.description ELSE OLD.description END,
        local = CASE WHEN NEW.local IS NOT NULL THEN NEW.local ELSE OLD.local END,
        protect = CASE WHEN NEW.protect IS NOT NULL THEN NEW.protect ELSE OLD.protect END,
        type = CASE WHEN NEW.type IS NOT NULL THEN NEW.type ELSE OLD.type END,
        content = CASE WHEN NEW.content IS NOT NULL THEN NEW.content ELSE OLD.content END,
        entrypoint = CASE WHEN NEW.entrypoint IS NOT NULL THEN NEW.entrypoint ELSE OLD.entrypoint END,
        args = NEW.args,
        limits = NEW.limits,
        host = CASE WHEN NEW.host IS NOT NULL THEN NEW.host ELSE OLD.host END,
        version = CASE WHEN NEW.version IS NOT NULL THEN NEW.version ELSE OLD.version END,
        created = CASE WHEN NEW.created IS NOT NULL THEN NEW.created ELSE OLD.created END,
        updated = CASE WHEN NEW.updated IS NOT NULL THEN NEW.updated ELSE OLD.updated END,
        author = CASE WHEN NEW.author IS NOT NULL THEN NEW.author ELSE OLD.author END,
        editor = NEW.editor,
        vendor = NEW.vendor
    WHERE id = OLD.id
    RETURNING id INTO NEW.id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

--- триггеры на операции
CREATE OR REPLACE TRIGGER scripts_insert_trigger
INSTEAD OF INSERT ON scripts
FOR EACH ROW EXECUTE FUNCTION scripts_insert();

CREATE OR REPLACE TRIGGER scripts_update_trigger
INSTEAD OF UPDATE ON scripts
FOR EACH ROW EXECUTE FUNCTION scripts_update();



--- представление для доступа к данным
CREATE OR REPLACE VIEW scripts_schedule AS
SELECT
    id,
    name,
    args,
    decrypt(secrets)::jsonb AS secrets,
    limits,
    enabled,
    host,
    script_id,
    period,
    result,
    last_run,
    next_run,
    created,
    updated,
    author,
    editor
FROM scripts_schedule_encrypted;

--- функции вставки/обновления с шифрованием
CREATE OR REPLACE FUNCTION scripts_schedule_insert()
RETURNS trigger AS $$
BEGIN
  INSERT INTO scripts_schedule_encrypted (id, name, args, secrets, limits, enabled, host, script_id, period, result,
    last_run, next_run, created, updated, author, editor)
  VALUES (
    COALESCE(NEW.id, gen_random_uuid()),
    NEW.name,
      NEW.args,
    CASE WHEN NEW.secrets IS NOT NULL THEN encrypt(NEW.secrets::text) ELSE NULL END,
      NEW.limits,
      CASE WHEN NEW.enabled IS NOT NULL THEN NEW.enabled ELSE false END,
      NEW.host,
      NEW.script_id,
      NEW.period,
      NEW.result,
      NEW.last_run,
      NEW.next_run,
      CASE WHEN NEW.created IS NOT NULL THEN NEW.created ELSE (date_part('epoch'::text, now()) * 1000::double precision) END,
      CASE WHEN NEW.updated IS NOT NULL THEN NEW.updated ELSE (date_part('epoch'::text, now()) * 1000::double precision) END,
      CASE WHEN NEW.author IS NOT NULL THEN NEW.author ELSE get_default_author() END,
      NEW.editor
  )
  ON CONFLICT (id) DO UPDATE SET
    name = EXCLUDED.name,
    args = CASE WHEN EXCLUDED.args IS NOT NULL THEN EXCLUDED.args ELSE scripts_schedule_encrypted.args END,
    secrets = CASE WHEN EXCLUDED.secrets IS NOT NULL THEN EXCLUDED.secrets ELSE scripts_schedule_encrypted.secrets END,
    limits = CASE WHEN EXCLUDED.limits IS NOT NULL THEN EXCLUDED.limits ELSE scripts_schedule_encrypted.limits END,
    enabled = EXCLUDED.enabled,
    host = EXCLUDED.host,
    script_id = EXCLUDED.script_id,
    period = CASE WHEN EXCLUDED.period IS NOT NULL THEN EXCLUDED.period ELSE scripts_schedule_encrypted.period END,
    result = CASE WHEN EXCLUDED.result IS NOT NULL THEN EXCLUDED.result ELSE scripts_schedule_encrypted.result END,
    last_run = EXCLUDED.last_run,
    next_run = EXCLUDED.next_run,
    created = EXCLUDED.created,
    updated = EXCLUDED.updated,
    author = EXCLUDED.author,
  editor = CASE WHEN EXCLUDED.editor IS NOT NULL THEN EXCLUDED.editor ELSE scripts_schedule_encrypted.editor END
  RETURNING id INTO NEW.id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION scripts_schedule_update()
RETURNS trigger AS $$
BEGIN
    UPDATE scripts_schedule_encrypted
    SET secrets = encrypt(NEW.secrets::text),
        name = CASE WHEN NEW.name IS NOT NULL THEN NEW.name ELSE OLD.name END,
        args = NEW.args,
        limits = NEW.limits,
        enabled = CASE WHEN NEW.enabled IS NOT NULL THEN NEW.enabled ELSE OLD.enabled END,
        host = CASE WHEN NEW.host IS NOT NULL THEN NEW.host ELSE OLD.host END,
        script_id = CASE WHEN NEW.script_id IS NOT NULL THEN NEW.script_id ELSE OLD.script_id END,
        period = CASE WHEN NEW.period IS NOT NULL THEN NEW.period ELSE OLD.period END,
        result = CASE WHEN NEW.result IS NOT NULL THEN NEW.result ELSE OLD.result END,
        last_run = CASE WHEN NEW.last_run IS NOT NULL THEN NEW.last_run ELSE OLD.last_run END,
        next_run = NEW.next_run,
        created = CASE WHEN NEW.created IS NOT NULL THEN NEW.created ELSE OLD.created END,
        updated = CASE WHEN NEW.updated IS NOT NULL THEN NEW.updated ELSE OLD.updated END,
        author = CASE WHEN NEW.author IS NOT NULL THEN NEW.author ELSE OLD.author END,
        editor = NEW.editor
    WHERE id = OLD.id
    RETURNING id INTO NEW.id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

--- триггеры на операции
CREATE OR REPLACE TRIGGER scripts_schedule_insert_trigger
INSTEAD OF INSERT ON scripts_schedule
FOR EACH ROW EXECUTE FUNCTION scripts_schedule_insert();

CREATE OR REPLACE TRIGGER scripts_schedule_update_trigger
INSTEAD OF UPDATE ON scripts_schedule
FOR EACH ROW EXECUTE FUNCTION scripts_schedule_update();
--------------------------------------------------------------
-- Представления данных для таблиц связанных с сервисами
--------------------------------------------------------------

CREATE OR REPLACE VIEW public.signal_lists_view AS
SELECT
    sl.id,
    sl.installaition_id,
    sl.name,
    sl.category,
    sl.description,
    sl.local,
    sl.version,
    sl.created,
    sl.updated,
    sl.author AS author_id,
    sl.editor,
    u.first_name AS author_first_name,
    u.last_name AS author_last_name,
    u.username AS author_username,
    u.domain AS author_domain,
    sl.vendor,
    (
        SELECT count(*) AS count
        FROM signal_lists_values AS slv
        WHERE slv.list_id = sl.id
    ) AS total
FROM signal_lists AS sl INNER JOIN users AS u ON sl.author = u.id;

--- представление для доступа к данным
CREATE OR REPLACE VIEW integrations AS
SELECT
    id,
    name,
    service,
    enabled,
    type,
    decrypt(settings)::json AS settings -- noqa: RF04
FROM integrations_encrypted;

--- функции вставки/обновления с шифрованием
CREATE OR REPLACE FUNCTION integrations_insert()
RETURNS trigger AS $$
BEGIN
    INSERT INTO integrations_encrypted (name, service, enabled, type, settings)
    VALUES (NEW.name, NEW.service, NEW.enabled, NEW.type, encrypt(NEW.settings::text)) ON CONFLICT (name, service) DO NOTHING;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION integrations_update()
RETURNS trigger AS $$
BEGIN
    UPDATE integrations_encrypted
    SET settings = encrypt(NEW.settings::text),
        service = NEW.service,
        enabled = NEW.enabled,
        type = NEW.type
    WHERE name = OLD.name;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

--- триггеры на операции
CREATE OR REPLACE TRIGGER integrations_insert_trigger
INSTEAD OF INSERT ON integrations
FOR EACH ROW EXECUTE FUNCTION integrations_insert();

CREATE OR REPLACE TRIGGER integrations_update_trigger
INSTEAD OF UPDATE ON integrations
FOR EACH ROW EXECUTE FUNCTION integrations_update();
--------------------------------------------------------------------
-- Представления данных для таблиц воркспейсов и блокнота аналитика
--------------------------------------------------------------------

CREATE OR REPLACE VIEW public.attacks_view
AS
SELECT
    attacks.id,
    attacks.type,
    attacks.start_time,
    attacks.end_time,
    attacks.need_to_be_watched,
    attacks.way_to_detect,
    (
        SELECT row_to_json(t.*) AS json_obj
        FROM (SELECT
            sources.id,
            sources.type,
            sources.info,
            sources.ip,
            sources.domain,
            sources.url,
            sources.email,
            sources.network_protocol,
            sources.asn,
            sources.as_org,
            sources.country,
            sources.location,
            (
                coalesce(
                    sources.url,
                    sources.email,
                    sources.domain,
                    sources.ip::text,
                    ''
                )
            ) AS address,
            (
                SELECT row_to_json(b.*) FROM botnets AS b
                WHERE sources.botnet = b.name
            ) AS botnet
        FROM attack_sources AS sources
        WHERE attacks.id = sources.id) AS t
    ) AS source,
    (
        SELECT json_agg(row_to_json(p.*)) AS json_agg_p
        FROM (SELECT
            payloads.name,
            payloads.info,
            payloads.file_name,
            payloads.md5,
            payloads.sha1,
            payloads.sha256,
            payloads.sha512,
            payloads.av_signature,
            payloads.av_lab,
            payloads.printable,
            payloads.base64_encoded,
            payloads.cves
        FROM payloads
        WHERE attacks.id = payloads.attack_id) AS p
    ) AS payloads
FROM attacks;


CREATE OR REPLACE VIEW public.workspace_children_view
AS
SELECT
    workspace_to_workspace.parent AS ws_id,
    workspaces.id,
    workspaces.name,
    workspaces.type,
    workspace_to_workspace.created_at,
    workspace_to_workspace.info
FROM workspace_to_workspace
INNER JOIN workspaces ON (workspace_to_workspace.child = workspaces.id);


CREATE OR REPLACE VIEW public.workspace_parents_view
AS
SELECT
    workspace_to_workspace.child AS ws_id,
    workspaces.id,
    workspaces.name,
    workspaces.type,
    workspace_to_workspace.created_at,
    workspace_to_workspace.info
FROM workspace_to_workspace
INNER JOIN workspaces ON (workspace_to_workspace.parent = workspaces.id);


CREATE OR REPLACE VIEW public.workspaces_report
AS
SELECT
    workspaces.created_at,
    workspaces.status,
    workspaces.type,
    workspaces.severity,
    workspaces.killchain_stage,
    workspaces.killchain_case,
    creator.username || '@' || creator.domain as creator,
    analyst.username || '@' || analyst.domain as analyst,
    (NOT (EXISTS (
        SELECT 1
        FROM workspace_to_workspace
        WHERE (workspace_to_workspace.child = workspaces.id)
    ))) AS is_root

FROM workspaces
LEFT JOIN users AS creator ON workspaces.creator = creator.id
LEFT JOIN users AS analyst ON workspaces.analyst = analyst.id;


--- представление для доступа к данным
CREATE OR REPLACE VIEW workspaces_scripts AS
SELECT
    wid,
    sid,
    args,
    decrypt(secrets)::jsonb AS secrets,
    limits,
    host,
    priority
FROM workspaces_scripts_encrypted;

--- функции вставки/обновления с шифрованием
CREATE OR REPLACE FUNCTION workspaces_scripts_insert()
RETURNS trigger AS $$
BEGIN
  INSERT INTO workspaces_scripts_encrypted (wid, sid, args, secrets, limits, host, priority)
  VALUES (
    NEW.wid,
    NEW.sid,
    NEW.args,
    CASE WHEN NEW.secrets IS NOT NULL THEN encrypt(NEW.secrets::text) ELSE NULL END,
    NEW.limits,
    NEW.host,
    NEW.priority
  )
  ON CONFLICT ON CONSTRAINT workspaces_scripts_pkey DO UPDATE SET
    args = CASE WHEN EXCLUDED.args IS NOT NULL THEN EXCLUDED.args ELSE (SELECT args FROM scripts_encrypted WHERE id = EXCLUDED.sid) END,
    secrets = CASE WHEN EXCLUDED.secrets IS NOT NULL THEN EXCLUDED.secrets ELSE (SELECT secrets FROM scripts_encrypted WHERE id = EXCLUDED.sid) END,
    limits = CASE WHEN EXCLUDED.limits IS NOT NULL THEN EXCLUDED.limits ELSE (SELECT limits FROM scripts_encrypted WHERE id = EXCLUDED.sid) END,
    host = EXCLUDED.host,
    priority = EXCLUDED.priority
    RETURNING wid, sid INTO NEW.wid, NEW.sid;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION workspaces_scripts_update()
RETURNS trigger AS $$
BEGIN
    UPDATE workspaces_scripts_encrypted
    SET secrets = encrypt(NEW.secrets::text),
        args = NEW.args,
        limits = NEW.limits,
        host = CASE WHEN NEW.host IS NOT NULL THEN NEW.host ELSE OLD.host END,
        priority = NEW.priority
    WHERE wid = OLD.wid and sid = OLD.sid
    RETURNING wid, sid INTO NEW.wid, NEW.sid;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

--- триггеры на операции
CREATE OR REPLACE TRIGGER workspaces_scripts_insert_trigger
INSTEAD OF INSERT ON workspaces_scripts
FOR EACH ROW EXECUTE FUNCTION workspaces_scripts_insert();

CREATE OR REPLACE TRIGGER workspaces_scripts_update_trigger
INSTEAD OF UPDATE ON workspaces_scripts
FOR EACH ROW EXECUTE FUNCTION workspaces_scripts_update();


--- представление для доступа к данным
CREATE OR REPLACE VIEW notepad_lists_scripts AS
SELECT
    nid,
    sid,
    args,
    decrypt(secrets)::jsonb AS secrets,
    limits,
    host,
    priority
FROM notepad_lists_scripts_encrypted;

--- функции вставки/обновления с шифрованием
CREATE OR REPLACE FUNCTION notepad_lists_scripts_insert()
RETURNS trigger AS $$
BEGIN
  INSERT INTO notepad_lists_scripts_encrypted (nid, sid, args, secrets, limits, host, priority)
  VALUES (
    NEW.nid,
    NEW.sid,
    NEW.args,
    CASE WHEN NEW.secrets IS NOT NULL THEN encrypt(NEW.secrets::text) ELSE NULL END,
    NEW.limits,
    NEW.host,
    NEW.priority
  )
  ON CONFLICT ON CONSTRAINT notepad_lists_scripts_pkey DO UPDATE SET
    args = CASE WHEN EXCLUDED.args IS NOT NULL THEN EXCLUDED.args ELSE (SELECT args FROM scripts_encrypted WHERE id = EXCLUDED.sid) END,
    secrets = CASE WHEN EXCLUDED.secrets IS NOT NULL THEN EXCLUDED.secrets ELSE (SELECT secrets FROM scripts_encrypted WHERE id = EXCLUDED.sid) END,
    limits = CASE WHEN EXCLUDED.limits IS NOT NULL THEN EXCLUDED.limits ELSE (SELECT limits FROM scripts_encrypted WHERE id = EXCLUDED.sid) END,
    host = EXCLUDED.host,
    priority = EXCLUDED.priority
    RETURNING nid, sid INTO NEW.nid, NEW.sid;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION notepad_lists_scripts_update()
RETURNS trigger AS $$
BEGIN
    UPDATE notepad_lists_scripts_encrypted
    SET secrets = encrypt(NEW.secrets::text),
        args = NEW.args,
        limits = NEW.limits,
        host = CASE WHEN NEW.host IS NOT NULL THEN NEW.host ELSE OLD.host END,
        priority = NEW.priority
    WHERE nid = OLD.nid and sid = OLD.sid
    RETURNING nid, sid INTO NEW.nid, NEW.sid;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

--- триггеры на операции
CREATE OR REPLACE TRIGGER notepad_lists_scripts_insert_trigger
INSTEAD OF INSERT ON notepad_lists_scripts
FOR EACH ROW EXECUTE FUNCTION notepad_lists_scripts_insert();

CREATE OR REPLACE TRIGGER notepad_lists_scripts_update_trigger
INSTEAD OF UPDATE ON notepad_lists_scripts
FOR EACH ROW EXECUTE FUNCTION notepad_lists_scripts_update();


--- Список листов с базовыми атрибутами
CREATE OR REPLACE VIEW public.notepad_lists_view
AS
WITH workspace_data AS (
    SELECT
        notepad_lists.id,
        jsonb_build_object(
            'id', workspaces.id,
            'name', workspaces.name
        ) AS workspace
    FROM public.notepad_lists
    LEFT JOIN public.workspaces ON (notepad_lists.workspace = workspaces.id)
    WHERE notepad_lists.workspace IS NOT NULL
),

author_data AS (
    SELECT
        notepad_lists.id,
        jsonb_build_object(
            'id', users.id,
            'first_name', users.first_name,
            'last_name', users.last_name,
            'email', users.email
        ) AS author
    FROM public.notepad_lists
    LEFT JOIN public.users ON (notepad_lists.author = users.id)
    WHERE notepad_lists.author IS NOT NULL
)

SELECT
    nl.id,
    nl.name,
    nl.created,
    nl.edited,
    nl.clear_days,
    workspace.workspace,
    author.author
FROM public.notepad_lists AS nl
LEFT JOIN workspace_data AS workspace ON (nl.id = workspace.id)
LEFT JOIN author_data AS author ON (nl.id = author.id);


--- Список листов с базовыми атрибутами и связанными объектами
CREATE OR REPLACE VIEW public.notepad_list_full_view
AS
WITH workspace_data AS (
    SELECT
        notepad_lists.id,
        jsonb_build_object(
            'id', workspaces.id,
            'name', workspaces.name
        ) AS workspace
    FROM public.notepad_lists
    LEFT JOIN public.workspaces ON (notepad_lists.workspace = workspaces.id)
    WHERE notepad_lists.workspace IS NOT NULL
),

author_data AS (
    SELECT
        notepad_lists.id,
        jsonb_build_object(
            'id', users.id,
            'first_name', users.first_name,
            'last_name', users.last_name,
            'email', users.email
        ) AS author
    FROM public.notepad_lists
    LEFT JOIN public.users ON (notepad_lists.author = users.id)
    WHERE notepad_lists.author IS NOT NULL
),

attributes_data AS (
    SELECT
        notepad_lists.id,
        coalesce(json_agg(DISTINCT jsonb_build_object(
            'id', notepad_filters.id,
            'name', notepad_filters.name
        )) FILTER (WHERE notepad_filters.id IS NOT NULL), '[]') AS filters,
        coalesce(json_agg(DISTINCT jsonb_build_object(
            'id', notepad_queries.id,
            'name', notepad_queries.name
        )) FILTER (WHERE notepad_queries.id IS NOT NULL), '[]') AS queries,
        coalesce(json_agg(DISTINCT jsonb_build_object(
            'id', notepad_indicators.id,
            'name', notepad_indicators.name,
            'field', notepad_indicators.field,
            'value', notepad_indicators.value,
            'detects', notepad_indicators.detects
        )) FILTER (WHERE notepad_indicators.id IS NOT NULL), '[]') AS indicators
    FROM public.notepad_lists
    LEFT JOIN
        public.notepad_filters
        ON (notepad_lists.id = notepad_filters.list)
    LEFT JOIN
        public.notepad_queries
        ON (notepad_lists.id = notepad_queries.list)
    LEFT JOIN
        public.notepad_indicators
        ON (notepad_lists.id = notepad_indicators.list)
    GROUP BY notepad_lists.id
),

scripts_data AS (
    SELECT
        nls.nid AS id,
        coalesce(json_agg(jsonb_build_object(
            'id', nls.sid,
            'name', s.name,
            'description', s.description,
            'type', s.type,
            'args', nls.args,
            'secrets', (CASE
                WHEN nls.secrets IS NOT NULL AND jsonb_typeof(nls.secrets) = 'array'
                    THEN (
                        SELECT
                            jsonb_agg(
                                jsonb_build_object(
                                    'key', item ->> 'key',
                                    'value', '* * * * * * * *'
                                )
                            )
                        FROM jsonb_array_elements(nls.secrets) AS item
                    )
                ELSE '[]'::jsonb
            END),
            'state', (
                SELECT st.state
                FROM scripts_tasks AS st
                LEFT JOIN notepad_lists_scripts_tasks AS nlst ON st.id = nlst.tid
                WHERE nlst.nid = nls.nid and nls.sid = st.script_id
                ORDER BY st.updated DESC
                LIMIT 1
            ),
            'limits', nls.limits,
            'host', nls.host,
            'priority', nls.priority
        )) FILTER (WHERE nls.sid IS NOT NULL), '[]') AS scripts_array
    FROM public.notepad_lists_scripts AS nls
    LEFT JOIN public.scripts AS s ON nls.sid = s.id
    GROUP BY nls.nid
)

SELECT
    nl.id,
    nl.name,
    nl.created,
    nl.edited,
    nl.clear_days,
    nl.notes,
    workspace.workspace,
    author.author,
    attributes.filters,
    attributes.queries,
    attributes.indicators,
    coalesce(scripts.scripts_array, '[]'::json) AS scripts
FROM public.notepad_lists AS nl
LEFT JOIN workspace_data AS workspace ON (nl.id = workspace.id)
LEFT JOIN author_data AS author ON (nl.id = author.id)
LEFT JOIN attributes_data AS attributes ON (nl.id = attributes.id)
LEFT JOIN scripts_data AS scripts ON (nl.id = scripts.id);


--- Список воркспейсов без привязанных листов
CREATE OR REPLACE VIEW public.workspaces_without_lists_view
AS
SELECT
    workspaces.id,
    workspaces.name
FROM public.workspaces
LEFT OUTER JOIN
    public.notepad_lists
    ON (workspaces.id = notepad_lists.workspace)
WHERE notepad_lists.workspace IS NULL;


--- Полная информация о всех воркспейсах
CREATE OR REPLACE VIEW public.workspaces_full_view
AS
WITH scripts_data AS (
    SELECT
        ws.wid AS id,
        coalesce(json_agg(jsonb_build_object(
            'id', ws.sid,
            'name', s.name,
            'description', s.description,
            'type', s.type,
            'args', ws.args,
            'secrets', (CASE
                WHEN ws.secrets IS NOT NULL AND jsonb_typeof(ws.secrets) = 'array'
                    THEN (
                        SELECT
                            jsonb_agg(
                                jsonb_build_object(
                                    'key', item ->> 'key',
                                    'value', '* * * * * * * *'
                                )
                            )
                        FROM jsonb_array_elements(ws.secrets) AS item
                    )
                ELSE '[]'::jsonb
            END),
            'state', (
                SELECT st.state
                FROM scripts_tasks AS st
                LEFT JOIN workspaces_scripts_tasks AS wst ON st.id = wst.tid
                WHERE wst.wid = ws.wid and ws.sid = st.script_id
                ORDER BY st.updated DESC
                LIMIT 1
            ),
            'limits', ws.limits,
            'host', ws.host,
            'priority', ws.priority
        )) FILTER (WHERE ws.sid IS NOT NULL), '[]') AS scripts_array
    FROM public.workspaces_scripts AS ws
    LEFT JOIN public.scripts AS s ON ws.sid = s.id
    GROUP BY ws.wid
)

SELECT
    workspaces.changed_at,
    workspaces.closed_at,
    workspaces.created_at,
    workspaces.id,
    workspaces.investigated_at,
    workspaces.solution,
    workspaces.summary,
    workspaces.name,
    workspaces.reason,
    workspaces.status,
    workspaces.assigned_at,
    workspaces.type,
    workspaces.reliability,
    workspaces.severity,
    workspaces.priority,
    workspaces.imho_preferred,
    workspaces.qualified_at,
    workspaces.first_fact_at,
    workspaces.killchain_stage,
    workspaces.killchain_case,
    workspaces.scope,
    workspaces.recovered_at,
    workspaces.availability_damage,
    workspaces.integrity_damage,
    workspaces.confidentiality_damage,
    workspaces.rule_id,
    workspaces.detector,
    (workspaces.closed_at IS NULL) AS is_open,
    jsonb_strip_nulls(jsonb_build_object(
        'id', creator.id,
        'first_name', creator.first_name,
        'last_name', creator.last_name,
        'username', creator.username,
        'domain', creator.domain
    )) AS creator,
    (workspaces.investigated_at IS NOT NULL) AS is_investigated,
    jsonb_strip_nulls(jsonb_build_object(
        'id', analyst.id,
        'first_name', analyst.first_name,
        'last_name', analyst.last_name,
        'username', analyst.username,
        'domain', analyst.domain
    )) AS analyst,
    (workspaces.assigned_at IS NULL) AS not_assigned,
    (NOT (EXISTS (
        SELECT 1
        FROM workspace_to_workspace
        WHERE (workspace_to_workspace.child = workspaces.id)
    ))) AS is_root,
    (
        SELECT json_agg(row_to_json(t.*)) AS json_agg
        FROM (SELECT
            workspace_children_view.id,
            workspace_children_view.name,
            workspace_children_view.type,
            workspace_children_view.created_at,
            workspace_children_view.info
        FROM workspace_children_view
        WHERE workspaces.id = workspace_children_view.ws_id) AS t
    ) AS children,
    (
        SELECT json_agg(row_to_json(t.*)) AS json_agg
        FROM (SELECT
            workspace_parents_view.id,
            workspace_parents_view.name,
            workspace_parents_view.type,
            workspace_parents_view.created_at,
            workspace_parents_view.info
        FROM workspace_parents_view
        WHERE workspaces.id = workspace_parents_view.ws_id) AS t
    ) AS parents,
    (
        SELECT json_agg(row_to_json(t.*)) AS json_agg
        FROM (
            SELECT
                COALESCE(b.rid, r.id) AS id,
                COALESCE(b.attrs->>'name', r.name) AS name,
                COALESCE(b.attrs->>'description', r.description) AS description,
                COALESCE(b.type_id, r.type_id)::varchar AS type,  -- noqa: disable=RF04
                COALESCE(b.attrs->>'type_name', r.type_name) AS type_name,
                COALESCE(b.way_to_use, ws_targets_hosts.way_to_use) AS way_to_use,
                COALESCE(b.is_threat, ws_targets_hosts.is_threat) AS is_threat,
                COALESCE(b.created_at, ws_targets_hosts.created_at) AS created_at,
                b.attrs->'data' AS data
            FROM ws_targets_hosts
            INNER JOIN resources_view AS r ON ws_targets_hosts.rid = r.id
            LEFT JOIN ws_targets_backup AS b
                ON b.wsid = workspaces.id
                AND b.rid = ws_targets_hosts.rid
                AND workspaces.status = 'закрыт'
                AND workspaces.type IN ('атака', 'инцидент')
            WHERE ws_targets_hosts.wid = workspaces.id

            UNION ALL

            SELECT
                COALESCE(b.rid, r.id) AS id,
                COALESCE(b.attrs->>'name', r.name) AS name,
                COALESCE(b.attrs->>'description', r.description) AS description,
                COALESCE(b.type_id, r.type_id)::varchar AS type,  -- noqa: disable=RF04
                COALESCE(b.attrs->>'type_name', r.type_name) AS type_name,
                COALESCE(b.way_to_use, ws_targets_accounts.way_to_use) AS way_to_use,
                COALESCE(b.is_threat, ws_targets_accounts.is_threat) AS is_threat,
                COALESCE(b.created_at, ws_targets_accounts.created_at) AS created_at,
                b.attrs->'data' AS data
            FROM ws_targets_accounts
            INNER JOIN resources_view AS r ON ws_targets_accounts.rid = r.id
            LEFT JOIN ws_targets_backup AS b
                ON b.wsid = workspaces.id
                AND b.rid = ws_targets_accounts.rid
                AND workspaces.status = 'закрыт'
                AND workspaces.type IN ('атака', 'инцидент')
            WHERE ws_targets_accounts.wid = workspaces.id

            UNION ALL

            SELECT
                COALESCE(b.rid, r.id) AS id,
                COALESCE(b.attrs->>'name', r.name) AS name,
                COALESCE(b.attrs->>'description', r.description) AS description,
                COALESCE(b.type_id, r.type_id)::varchar AS type,  -- noqa: disable=RF04
                COALESCE(b.attrs->>'type_name', r.type_name) AS type_name,
                COALESCE(b.way_to_use, ws_targets_iss.way_to_use) AS way_to_use,
                COALESCE(b.is_threat, ws_targets_iss.is_threat) AS is_threat,
                COALESCE(b.created_at, ws_targets_iss.created_at) AS created_at,
                b.attrs->'data' AS data
            FROM ws_targets_iss
            INNER JOIN resources_view AS r ON ws_targets_iss.rid = r.id
            LEFT JOIN ws_targets_backup AS b
                ON b.wsid = workspaces.id
                AND b.rid = ws_targets_iss.rid
                AND workspaces.status = 'закрыт'
                AND workspaces.type IN ('атака', 'инцидент')
            WHERE ws_targets_iss.wid = workspaces.id

            UNION ALL

            SELECT
                b.rid AS id,
                b.attrs->>'name' AS name,
                b.attrs->>'description' AS description,
                b.type_id::varchar AS type,  -- noqa: disable=RF04
                b.attrs->>'type_name' AS type_name,
                b.way_to_use,
                b.is_threat,
                b.created_at,
                b.attrs->'data' AS data
            FROM ws_targets_backup AS b
            WHERE
                b.wsid = workspaces.id
                AND workspaces.status = 'закрыт'
                AND workspaces.type IN ('атака', 'инцидент')
                AND NOT EXISTS (
                    SELECT 1 FROM ws_targets_hosts
                    WHERE ws_targets_hosts.wid = workspaces.id
                    AND ws_targets_hosts.rid = b.rid
                )
                AND NOT EXISTS (
                    SELECT 1 FROM ws_targets_accounts
                    WHERE ws_targets_accounts.wid = workspaces.id
                    AND ws_targets_accounts.rid = b.rid
                )
                AND NOT EXISTS (
                    SELECT 1 FROM ws_targets_iss
                    WHERE ws_targets_iss.wid = workspaces.id
                    AND ws_targets_iss.rid = b.rid
                )

            UNION ALL

            SELECT
                wi.id,
                wi.name,
                NULL AS description,
                i.type,
                i.name AS type_name,
                wi.way_to_use,
                wi.is_threat,
                wi.created_at,
                NULL AS data
            FROM workspace_indicators AS wi
            INNER JOIN indicator_types AS i ON wi.type_id = i.id
            WHERE
                wi.workspace_id = workspaces.id
                AND wi.internal = TRUE
        ) AS t
    ) AS targets,
    (
        SELECT json_agg(row_to_json(t.*)) AS json_agg
        FROM (
            SELECT
                wi.id,
                wi.name,
                i.name AS type_name,
                i.type,
                wi.way_to_use,
                wi.is_threat,
                wi.created_at
            FROM workspace_indicators AS wi
            INNER JOIN indicator_types AS i ON wi.type_id = i.id
            WHERE
                wi.workspace_id = workspaces.id
                AND wi.internal = FALSE
        ) AS t
    ) AS indicators,
    (SELECT json_agg(indicator_types.*) AS json_obj FROM indicator_types
    ) AS indicator_types,
    (
        SELECT row_to_json(t.*) AS json_obj
        FROM (SELECT
            a.id,
            a.type,
            a.start_time,
            a.end_time,
            a.need_to_be_watched,
            a.way_to_detect,
            a.source,
            a.payloads
        FROM attacks_view AS a
        WHERE a.id = workspaces.id) AS t
    ) AS attack,
    (workspaces.recovered_at IS NULL) AS not_recovered,
    (EXISTS (
        SELECT 1
        FROM public.sopka_notifications
        WHERE (public.sopka_notifications.ws_id = workspaces.id)
    )) AS is_sopka,
    (
        SELECT row_to_json(t.*) AS json_obj
        FROM (SELECT
            s.sopka_id AS id,
            s.shipped_at,
            s.ready_at,
            s.last_shipping_error
        FROM sopka_notifications AS s
        WHERE s.ws_id = workspaces.id) AS t
    ) AS sopka,
    (
        SELECT json_agg(row_to_json(t.*)) AS json_agg
        FROM (
            SELECT
                workspace_history.user_id,
                u.first_name,
                u.last_name,
                workspace_history.description,
                workspace_history.timestamp,
                coalesce(
                    u.username || '@' || coalesce(u.domain, 'local'),
                    workspace_history.username
                ) AS username
            FROM workspace_history
            LEFT OUTER JOIN users AS u ON workspace_history.user_id = u.id
            WHERE workspace_history.ws_id = workspaces.id
        ) AS t
    ) AS history,
    (
        SELECT jsonb_build_object('id', notepad_lists.id, 'name', notepad_lists.name)
        FROM public.notepad_lists
        WHERE workspaces.id = notepad_lists.workspace
    ) AS notepad_list,
    ((workspaces.priority * workspaces.reliability * workspaces.severity) * 100)
    / 125 AS risk_score_norm,
    coalesce(scripts.scripts_array, '[]'::json) AS scripts
FROM workspaces
LEFT JOIN users AS creator ON workspaces.creator = creator.id
LEFT JOIN users AS analyst ON workspaces.analyst = analyst.id
LEFT JOIN scripts_data AS scripts ON (workspaces.id = scripts.id);


CREATE OR REPLACE VIEW public.ws_targets_view
AS
SELECT
ws.id,
t.rid,
ws.name,
ws.status,
ws.type,
ws.created_at,
ws.changed_at,
ws.priority,
ws.reliability,
ws.severity,
((ws.priority * ws.reliability * ws.severity) * 100)/125 as risk_score_norm
FROM ws_targets_hosts t JOIN workspaces ws ON(t.wid = ws.id)
UNION ALL
SELECT
ws.id,
t.rid,
ws.name,
ws.status,
ws.type,
ws.created_at,
ws.changed_at,
ws.priority,
ws.reliability,
ws.severity,
((ws.priority * ws.reliability * ws.severity) * 100)/125 as risk_score_norm
FROM ws_targets_accounts t JOIN workspaces ws ON(t.wid = ws.id)
UNION ALL
SELECT
ws.id,
t.rid,
ws.name,
ws.status,
ws.type,
ws.created_at,
ws.changed_at,
ws.priority,
ws.reliability,
ws.severity,
((ws.priority * ws.reliability * ws.severity) * 100)/125 as risk_score_norm
FROM ws_targets_iss t JOIN workspaces ws ON(t.wid = ws.id);;
